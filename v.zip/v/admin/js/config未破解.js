var _0xodD = 'jsjiami.com.v6',
    _0x2cf9 = [_0xodD, 'QCc9NsKR', 'w5gdHsOGw58=', 'wqYYw6LCv8Klw5U=', 'w5TCpBzCs8K3', 'TsKYMcK0Jw==', 'csO4w6HDoGA=', 'aXIdwpc=', 'wrEKwrzChsK3', 'SW88wrUd', 'Xz03DcKe', 'wrjDmn3CnEk=', '5Y6l6YOHcsOt', 'bEbDssK2QA==', 'wrrCl8OjWxw=', 'AnMSEUXCkcKkw7LDvVsuwq3DqSrCrw==', 'fCY8N8KN', 'w5XDtMOiBgY=', 'wrFAwqXClcO2w7Q=', 'E3DDl3s=', 'w6jCgcOOwpYd', 'w7E0CytZ', 'Wh8V', 'w6zCs8OHwrY5', 'wqECwozCvcK0', 'wo4Lw4ZlwqDCsw==', 'c2zDh8KJZg==', 'wotUP8OVwog=', 'wrAbwo/CusK7', 'wo8dw48=', 'MUrDncK7wq0=', 'FSAFw5zCmQ==', 'ZMO9fAVo', 'HEPDhHJw', 'OkgJKWs=', 'w7TDusOA', 'wq1ICsOzwrg=', '576P6LyYwod6SsOWAO+8rw==', 'wrAcw7jCug==', 'w7zCtis=', 'dsK5BcO0Dw==', 'V8OkfBFo', 'w6nDucKeUcKr', 'SsOZYjlv', 'FmXDlQ0=', 'wqLDgcK7Xgg=', 'wovCoV7Ci8Og', 'Qm46wqYg', 'YXdCc8OSw73DosOQwpY=', 'esOdfsKHw5rCr2hEf2fChn3Cs8O8IyLCuMOt', 'w73CgS8=', '6L2Y5YyR5a625oi1', 'wo3ClMOBBSU=', 'aMOGa8Kmwrs=', 'w78fIyxa', 'woEGw41hwr/CiEBiYGUn', 'wpMKwqvCjw==', 'a8OWaQ==', 'AzVp', 'd2fDkMK8ZQ==', 'AcKXw43Ci8OOwqE=', 'GmLDhA==', 'w5/DocKYTMKh', 'fcKNL8O9LQ==', 'f0PDsMKsQA==', 'ElLDsQw6', '57yM6L2Ie8K/O2l9776u', 'EMKnT8Oc', 'BSkuw4rCl8Kh', 'XiQ3PcKS', 'woHCvWTCqsO+ZQ==', 'KsKyw4tww5I=', 'ZnA0wo4j', 'XR1I', 'UhwhGMKI', 'w6rDmsOQNQM=', 'Y8KDw5fDhAU=', 'IXXDuwXCgA==', 'IcKWbw==', 'wqLCgcOiVjE=', 'w77DucOhbEQ=', 'w5s5NjFu', 'e1p1eMOi', 'wpHCt8OhwqnCjg==', 'fgpeVcOO', 'wrNKwpzCkMOG', 'BULDu8K8wp0=', 'DjvDksOBw6luY8Kxwr3DqSccc8KqwrvClXZrG8Oaw5DDpcK0fzp6w4LDhMK6OMKaDRzCs8Kaw4Ujw7LCisOPVMOawqXDjzLDsw1swoI/wqQcH8OVb8OHMcKmDcO5woM0w4h/', 'LlbDj0Jx', 'wrYvw53CssK1', 'wqbCgcOBfQM=', 'w7XDgcO/aXI=', 'acKHw6XCmVo=', 'wrY5w7zCsMKQ', 'VA9bdQ==', 'e1nDsMKwQA==', 'w6Y7MsOGw44=', 'T8Onw5w=', '5p2055+O5pKB5L6G', 'U8KIHMKKFg==', 'w4TCqi7Cm8Kp', 'w6fDucO0KT3Dmzs=', 'aGrDhsKyUg==', 'fRwXOcKZ', 'wrAYw6A=', '6KyF6YK65oiH5Li26KCe', 'woIsw6TCq8KG', 'w77DtsKdVMKp', 'wr8Hw53CucKJ', 'w73CrD/Crg==', 'wp/CjsOawp8=', 'wqptwoofag==', 'PnnDvcKe', 'wpfCpsO9Gh4=', 'VG3DmxvCoQwJElEPwqs9w5DDi8ODwrQa', 'emZddg==', 'HUPDoMK4HcKg', 'HUfDvhnCnQ==', 'w5HCtR7DoA==', 'w5PDi8Kucw==', '5L+w5pSW5b6s5bqL', 'JcOGAxRK', 'dsK2w7jDuRA=', 'w6UXKyRbZw==', 'wrB+LsOeaRAsc2tE', 'Ai8jw47CjA==', 'KkPDucKYFA==', 'w6XCkxvChcO/', 'R8O1fCFT', 'wqvCnMOKBCI=', 'Fy0u', 'wprDkWbCrnE=', 'D8Kiw61jw5A=', 'W8K3Wypn', 'FcKZw7bCmsOg', 'wp7Dr1E=', 'QcKxw5jDhhE=', 'wpsEw4jCs8K1', 'cUQ3wqwe', 'wptNwqXCpMOX', 'YMKlw6jDhgI=', 'OVzDk096', 'w7TDq0lR', 'w6DCpMOcwokv', 'w47DqMODSGo=', 'ZndDbg==', 'wp/DoMKZRxQ=', 'QCQIOsKA', 'aMO9RMKewoc=', 'wr9FO8Otwrg=', 'EmfDhnRI', 'S0PDvsK7WA==', 'ISRrecKN', 'wojCmsOQUjk=', 'MX/DoMKMwqA2Jg==', 'ScK4DMKeIA==', 'ZD0wEsKP', 'VAtD', 'fUPDusKtUQ==', 'woMJw7bCqcK2', 'ecK1NMKXNw==', 'acOdY8KVwp3CrW0=', 'O3XDtygc', 'wpvCqMOlcT0=', 'A3bDvBouw7U=', 'wr0EwqvCpMKV', 'w7xGGMOCUQ==', 'w5rCgwLCocOH', 'wrPDrGTDsw==', 'AkrDmMK5MA==', 'X0hdacOD', 'R8O6TsKQwoE=', 'fMKqL8OqGg==', 'w6/CtcO+woIk', 'NAMAw7XCiw==', 'PwVUW8Ka', 'w7fDm8O4CgY=', 'wojCpsOaWyk=', 'w47DpcOMLQQ=', 'f1ppX8OK', 'w7dvJw==', 'w7bCqwvCtsKj', 'w7PCnifCgcOq', 'RsOzRcKCwpY=', 'w5I+Nw==', 'wph2wofCtsOV', 'J0DDpyE=', 'bcKwCsKGBw==', '5L6P5a2I5ayC5ou6', 'BHrDlhjCrCxEDUQPwqUow5HDq8OZwrMxw5DCgQc1w5cnw7w=', 'HkvDgCXClg==', 'w5TDuGhVNw==', 'VGvDmRnCrCsY', 'RcKvRC9H', 'FyFiZ8Kb', '55e85omK6KOk', 'TsOxw53Duw==', 'WE7DtsK2fA==', '5b+r5bm6wqLClw==', 'DsKXw43CmMOfwrs=', 'wqHDvMKoVTE=', '5b6p5bqn6aOU6IqA', 'wozCqcOAwo7Cng==', 'JMKYw4hJw4c=', 'UnrDmcKGWA==', 'wozCn1nCtMOL', 'GQcTw7fCig==', 'wodjI8Ovwrk=', 'w4fCr8OhwrcY', 'wrnDkMK2UgE=', 'XMKyM8OpJQ==', 'I10TQMKcwpjDgMKcPRPCl0R1w53CvB1rwqEww6gj', 'w5TDqMOMRFU=', 'w5hZJ8OrUA==', 'UBo/L8KA', 'wrhAwqHCu8OU', 'QDl3bsO9', 'IMKrw6vCucOe', 'FnvDgmI=', 'VBwkL8KP', 'WSHCmxHCqDMZUB4Cwql0w5HDosOGw6Eaw5rChABlw5I6wqYdw7kILkg=', 'wpwxw6nCmsKo', 'w6PltIPmjJrmnbnvvYk=', 'HsKrw6/CoMOR', 'QUF7X8Ow', 'QsKVC8KLHQ==', 'w6XCsemjsumciuWLiOi8qOWvtOasuua0juiBmOS4pQ==', 'dMK3AcOSDQ==', 'w7UTJitZZ8OVV8Oya8O2wpE9N8ORP8ODw7DCiTIAQMKKYzLDggAdwo5XL8OJcyMeQMOewqEmw7/DlwvDnWh7VMKNGMO6wrJMGMKSDsKhw7IVJkN4LWDCkcKqNcOYw78hFcKSTlkNw67Dj2/CohnDn8KgwrsFaTs8w7bDnnfCnSHCosOyw5zCoGDCusOUw57DqA8Xw7oww7s=', 'SsO+dxpz', 'Q8OXYMKHwqE=', 'SgIWDMKW', 'LcKdX8Oaeg==', 'RsKLw5XDiQ==', 'BMK8w7fCr8Oj', 'w4LCsz7CosOi', 'w6/DrMOVUkrDnTM=', 'wo/CgsOKciw=', 'w5MiNw==', 'asOfw73DnVM=', 'w7BlJ8OCbwdqP39IfcO6w7XDr8OIw5HCiG/CjAd6w4Q5w73Dqg3Ck0M2Cw7DjibDksOvwrVGOX/Du8O2P8O6N8Ksw4rCo8OHdTBj', 'w759EcO3ag==', 'ecKMMQ==', 'w6ldJcOhWg==', 'DzN6RsKoF8Ksdw==', 'MHspD0k=', 'MsKhb8OPw6c=', 'wovClVPCqcOe', 'VnjDvcKIXg==', 'wpouwpvCgsKy', 'wopAP8O1wro=', 'UwFLcQ==', 'w5c/NcON', '6Kyl6YCm5oii5Luz6KOT', 'QGghSsKmE8K9PcOZw6sgwrxgc8Oxw4I=', 'e8Kgw43CqWfClQ==', '5q265Z+95o265Lmq', 'w6LDu8KvQQ==', 'Zld0a8OA', '6L2P5Y+t5a+J5omQ', 'w4LDp8OJHDA=', 'wqTDlVPCoFM=', 'a3XDpsK8cQ==', 'wqkFWMOowr0=', 'OMKra8O3w4o=', 'QcOxw5XDu3PDig==', '5b+O5bi+5ae45bOh', 'wp8FVsOMwqY=', 'BlA0MkQ=', 'wokvScOFwoE=', 'wrZQCsObwqQ=', 'wr3CncO3wozChw==', 'woc7w6/CksKE', 'JcKAw6nCuMON', 'w7ElEg9U', 'w73DisOfQHA=', 'IHbDgzDCtw==', 'OVnDqx8+', 'WsK8XRBj', 'wovCo8OnwrHCqQ==', 'UMO+w7DDiEU=', '5L+H5a6B5a+X5ou0', 'w7HCny/CpcOk', 'woImaMO1wrU=', '5paX6Za454O7', 'Bykaw4bCuw==', 'YgciDMKI', 'dQ9KXcO1', 'w5vDmMOeUUA=', 'w5XCsCbCq8OB', '5qyU5Zyn5o2k5LuR', 'DyxvVg==', 'MQMRw7s=', 'AVTDrcKYCA==', 'wp/DgMKJ', 'TEHDn8KIRQ==', 'fcO8bSZ1', '55S95ouU6KC+', 'wpfDuXHCikw=', 'TcO/dMK1wpY=', '5b+t5biow6XCvw==', 'w7HDtHd1NQ==', '5b+U5bqN6aKW6Iq/', 'CiJIQ8KS', 'ewMZKMKb', 'woMZw4rCrMKy', 'NcKURcOIeg==', 'wrEewrHCjcKLw5nDjMKewpBcSsOgw5jCmD4RwqUdOivCmMKGw7k=', 'wrXCkMO+', 'w6FvJcOJeE8=', 'wqwPw6jCq8Km', 'wpElwpnCicKc', 'w4LChjnCsMK/', 'DCt7Q8K5', 'Uyx3YcOe', 'w6PCqyTCqsKq', 'QsODZ8Kewp4=', 'w7nCozjCgMKu', '5YyC6YChwogY', '5Y6/6YGH5pe46Zea', 'ARBqXcKl', 'wpPChMOQCzA=', 'wo7CmlLCuMOz', 'woBhK8OMwrk=', 'M0rDnz/Cig==', 'RHIzwrIx', 'AiNgScK/EA==', 'aDEJD8Ku', 'UsKUAcOEBw==', 'wpTDvlzCg24=', 'UsOQTsKkwrU=', 'TsKgWzdk', 'w63DvV0=', 'w4/DnsK5dMKkwrrCusK/wqU=', 'wqNPwrI8MSA0RRbDgmbCvnZMG1XDiyXDicKM', 'VsKWw5nCmEc=', 'BxUMw57Cig==', 'w6bDuXVXMw==', 'Kj8tw67Ckw==', 'wqQbw4ZhwqDCslttPHEmwqXDgcKlEhHCvcOTNMKMwoBxOw==', 'BcKReMO6XA==', 'w5XDk8OrUUU=', 'w5/CtCHCnMKv', 'w43Di1N2Bw==', 'wq7CgsO1', 'w7XCty7CgMOp', 'w6cnOcOmw7E=', 'CnrDp8KnwqM=', 'w7oBIg==', 'ewElLMKw', 'QgAqM8Ky', 'VRkVOMKmIw==', 'w6QRLg5H', 'wozCiMOLGA4=', 'RMOgw7bDlXA=', 'VhwCM8K6', 'wp0CRMOxwpQ=', 'wrnCq8OZVxo=', 'wpENw4NMwq0=', 'IXXDusKjwqcwLsO8w7HCoHQ=', 'wosPw4U=', 'f8OcacKWwpLCtg==', 'PHXDqg==', 'V8KFHMO3EQ==', 'NAd0YsKE', 'LUDDhMKOAg==', 'w7TChMO/wrwd', 'w4jDs8OxYEk=', 'Y8KcbsKcwpnDsXY=', 'ZMK5XxF3', 'fndefcOHw7k=', 'HcKHw5DChA==', 'w4HDocOjZmg=', 'ecKGOMOCH8OY', 'w7LDvcO9S0c=', 'QcOdb08SwpXCisKxwrlBV2XDl8KYwp8Dw4QkATHDnmrDiDXCoxBWwqTCjsOWN2bCtcOePCDDvcKCRcO3b8OkUSnCtkQjw6diDsOUwokXw7fCpGLDr1LDhTfDpXnCjRI=', 'w7jCqyXCrg==', 'w6nDoEpQJA==', 'wqIAaMO9wog=', 'ccK1w5rDmAs=', 'VEbCncK6WA==', 'RDphbcOt', 'd8Osw5PDgn8=', 'woXCnsO2TwY=', 'w7HCtSbCqMOZ', 'TVvCrsKTYw==', 'VsOCw4nDv1Q=', 'w5nCucO+wqsf', 'L8KNacOKYg==', 'w6MXNjQ=', 'wr/CjsOowq3Csw==', 'ZGcLwo8N', 'e0rCkcKdTiPDmcOANnQ7woHCusOaw6Jw', 'XgIbKw==', 'wprDskbCvHQ=', 'wprDssKJXBQ=', 'RcO+w7bDpSLDjU/DijI5OsOaFmXCuTlvDVVzGMO9woQ2w4wpw5Mra3ZYw57CgH5ewrbCtcK/wrXCpERIwpzDg1RGUsKqdMKcD8OKfmxvMMK4wpnCohbCk8K+w7pP', 'EE3DowU9', 'OFzDpMKfwrk=', 'bcKww5nCug==', 'RMOrXMKQwoM=', 'wqPCusOmAQY=', 'woMOwqzCmg==', 'bGXDh8Kddg==', 'wqnCr3zCu8On', 'XcKxI8OsBg==', 'I0YWO38=', 'PT9AYsKb', '55+T55qg5YmP6Zul6KKA5LiE', 'woYWw7jCicKl', 'L8ORLcKywp3CnWxbJ+aSq+aXm+WZocKuw7g=', 'JeW3peaPs+aeoO+9tQ==', 'wqPCvcOrBxpvWMOMw6Auw4fDuMOPw47CmEcQZcOjwrjCi8Kbw7AgfhPDscOAw5DCtA7DgMKPZwNzw5jDkcO1KcKUw7/CiC15Z8Ojwo/DhjBU', 'N3EQ6LS35LuDw5DDosOowp/Ds8Kt5pCp5pWf5ZqUIzPCvlDCmADDj2pSWxgIw7JkwrbDgSNPK8KCwp4=', 'wqjClMKL5o2w5pyq56K9TMKATcO0', 'R8KFw5LDhyESN8KMBcOSwqVcdMKgYcOGbcKMw4pgcjrCn1zCqcOoQDJzw5rDriZfUcO+w7zCo8KGFSbDpi0Mw51EAGLDvMKmTGEYfTZCw6FtEMO9VMK3NHDDvMKqQ2jDux7ColbCiARlwobDu8OmL0TCnGNiw5VFFxzCl8Ocwp0gwqDCqmhZLsO1HsKVwoJ0ZGg0Gw==', 'w6MLBcOww6I9w6bDmsKiMip4woMhDsOpEXrCox05VcK/w6rChMOEwp/CoMKoBcOw', 'wowcQcOIwrtiTB5bwoxjHsO+w7vDrnfCkAFEWcOzw4loOMKtEAlrCMOE', 'wpPDmcKPTg==', 'MQDDt8OwVcKfw5VoWH9Uc3lRBVEvcxgbw7U=', 'ecKqJMOQGg==', 'HsKRw4rCrsOK', 'wqgsw5JRwpA=', 'w5siPcOKw7IV', 'XcKcDw==', 'w6LCmB/CtsOh', 'w5zDhsOxBxo=', 'w6vDsMKsTsKO', 'SxwiCsKH', 'woTCn8OBXjI=', 'AcKdw4Q=', 'UMOBfzlq', 'OWvDnTvCrw==', 'wprCmsOawpbCqSrDpGg=', 'f17CnMKVXTjDmcObeDpdwonCucKWw589wohGwopDw6LDgGNeXcKPDMK5wpDDjFVnScKRw6E=', 'TsO7w5w=', 'SxoEPcK1', 'wofCnsO0UAk=', 'wqHCt8Orex8=', 'woPCt30=', 'wpoYwrg=', 'w7XCg8Obwos/', 'OGLDiXxk', 'VBAzP8Kp', 'ByxHXsKj', 'w6g8FMOuw6M=', 'wpUhcsOCwpc=', 'w5soPA==', 'dkrCscKITg==', 'DsKew4zCn8Of', 'GnzDkw==', '5L6p5a6e5a635oqt', 'w74ZEcOFw6g=', '5q255Z+x5o6L5LmA', 'cEzCmA==', 'fyY+PsKF', 'w7JgKsOV', 'Ql1jTg==', 'TUfDgMKmYA==', 'Ygdkc8Om', 'w6rDrMOVSELDnjRPGQ==', 'bkDDpsKqGsKGw5MpXjBUaCkNAVUyNAYU', 'TsK+A8KWKw==', 'QcKEDsOXEg==', 'cMKFVA==', '5L2K5ayq5a+J5omQ', 'wpbCnMOJ', 'UMOCw5HDn3E=', 'FA8dMcKlOMOgw4LCmMO2w5k=', 'VAMcOcKqI8Oq', 'ZB0BJMKf', 'woUPw6TCssKJ', 'YR4bKMKP', 'wqYcw6l6wpE=', 'UcOxw4nDpnfDlFBZw6g=', 'Hil9WsOlCMKgYsOZw6sgw7U4ZcO9w4U8MA==', 'YQEW', 'FWbDhMKpwoM=', 'AcK1Xg==', 'woHCuXPCqcOrecK8', 'wpsKwqbCnsKew5fDhg==', 'GMKnQsOYw7s=', 'wrTCs8OlBA0=', 'FX0PElLCg8KzwrY=', 'wpcew4RtwrXCvw==', 'aR4UA8KYwp/Dmg==', 'w6QeLCRbZw==', 'ZyMhCw==', 'wrLCpiPCtMKfbAvCgDvCsmk=', 'eQIVD8KJwpQ=', 'w5LCvSDCj8K6', '6K6D6YOP5ouS5Lq96KOF', 'w5nClcOmwpcv', '5Yyp6ICM5ZKe5peM572e6Lyr5LqY5Lq6', 'wokJXcOBwqZk', 'w5XDjsKfVcK1', 'fcOzfQZ0', 'w4vCgsOFwpsdw5UDw4sGwrXDuhvDplFqXMK+w4l8BSDClSI=', 'EMK9B38=', 'cmLDkcKNRQ==', 'VWgYDlPDncKwwrXDq1tvwq3DtC7Ds8Ko', 'aMK+OQ==', 'wqhBAw==', '55yG55mR5YqK6Zqq6KGO5Lqv', 'w5sgNcOPw7IP', 'DsKoXsOqYA==', 'JEDDoVdw', 'woDCsMOAVBo=', '5p6i55+65pGU5L27', 'wqlABsO1', '56aU6ZmC5Lqw5om55Liw', 'FBgXJ8K3NcOiw4nCmA==', 'wqrCuMK1KznDgiNpw7PCkiNpwovDrA4TwpHDnkQ=', '5byr5bmH5Ya15a6j', '5peU6ZWg54CC', 'w7LDp11NJA==', 'EwJGZ8OTCiUN', 'bhMSBcKawoPDgcOYalnDjgs7wpTCvAlkw65zwrtzw6k7OxYwwqhxwpMnK8KrcDxW', 'VhwCM8KqMsOmw5DCnsOrw5oAOMKiehAQw57DnMK6VsO0D1nCmmLDgnUOwpE=', 'OGPDocKE', 'Y2dVaMOK', 'JgkW', 'w7HDuMO+bVA=', '5byn5bm65aay5bOR', 'wqPDqldXNcKTwo58w50=', 'MxHDkMKaVyHDg8KBKT8EwpTDqMKVw442wpxTw5URwrHDhA==', '5b+K5buJX8Kt', '5Lik5om857Cg5Z2v', 'EcOmSiZMw4DDglLCjsOH', 'wqASw6PCt8Kiw4ZZTcOgw7bCv8Okw6lVQw==', 'wofDs1nCpShzwq1dR8KcYFY=', 'w63DpsOITQvDgDhFE3PCiQA=', 'YWdSd8Oaw6XCo8OIwpzDssKuw5sSwoludMK0BMOZ', 'w6zDr0NBMcKXwoQ=', 'w5MsKcOOw6k=', 'w6XCpC7CtsKc', 'wpEEwq3Cgw==', 'G27DjQHCtTQ=', 'VggfNsKt', 'w6nDocOARFc=', '55a75oi96KCj', 'wqDClMO8Ti3DiA==', 'ZsOXa8KH', '5ZCE6K+T772r', '5byr5bmHWX4=', '5b215bqw5YaN5aya', '5pej6ZSX54Ov', 'AmrDihMM', 'woTDhcKAUgc=', 'worDpsKDYSc=', 'PDjQRPszWjGSSxTiami.coNEm.rv6=='];
(function(_0x296464, _0x597b5c, _0x494db8) {
    var _0x33c3d4 = function(_0x1e3a4b, _0x39e024, _0x135130, _0x3087c4, _0x192983) {
        _0x39e024 = _0x39e024 >> 0x8, _0x192983 = 'po', asdfds = 'shift', afew1 = 'push';
        if (_0x39e024 < _0x1e3a4b) {
            while (--_0x1e3a4b) {
                _0x3087c4 = _0x296464[asdfds]();
                if (_0x39e024 === _0x1e3a4b) {
                    _0x39e024 = _0x3087c4;
                    _0x135130 = _0x296464[_0x192983 + 'p']()
                } else if (_0x39e024 && _0x135130['replace'](/[PDQRPzWGSSxTNEr=]/g, '') === _0x39e024) {
                    _0x296464[afew1](_0x3087c4)
                }
            }
            _0x296464[afew1](_0x296464[asdfds]())
        }
        return 0x3294e
    };
    return _0x33c3d4(++_0x597b5c, _0x494db8) >> _0x597b5c ^ _0x494db8
}(_0x2cf9, 0x176, 0x17600));
var _0x5108 = function(_0x2e4c78, _0x4040db) {
    _0x2e4c78 = ~~'0x' ['concat'](_0x2e4c78);
    var _0x57701e = _0x2cf9[_0x2e4c78];
    if (_0x5108['PkGkFo'] === undefined) {
        (function() {
            var _0x36f9ad = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0xf0dc9d = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x36f9ad['atob'] || (_0x36f9ad['atob'] = function(_0x1c33d7) {
                var _0x122366 = String(_0x1c33d7)['replace'](/=+$/, '');
                for (var _0x5963bc = 0x0, _0x277f09, _0x4cfcd5, _0x4e8ef1 = 0x0, _0x23be78 = ''; _0x4cfcd5 = _0x122366['charAt'](_0x4e8ef1++); ~_0x4cfcd5 && (_0x277f09 = _0x5963bc % 0x4 ? _0x277f09 * 0x40 + _0x4cfcd5 : _0x4cfcd5, _0x5963bc++ % 0x4) ? _0x23be78 += String['fromCharCode'](0xff & _0x277f09 >> (-0x2 * _0x5963bc & 0x6)) : 0x0) {
                    _0x4cfcd5 = _0xf0dc9d['indexOf'](_0x4cfcd5)
                }
                return _0x23be78
            })
        }());
        var _0x22c7e4 = function(_0x1e39d9, _0x4040db) {
            var _0x528f89 = [],
                _0x637268 = 0x0,
                _0x4f583b, _0x5035c1 = '',
                _0x517988 = '';
            _0x1e39d9 = atob(_0x1e39d9);
            for (var _0xbe90e3 = 0x0, _0x12bb68 = _0x1e39d9['length']; _0xbe90e3 < _0x12bb68; _0xbe90e3++) {
                _0x517988 += '%' + ('00' + _0x1e39d9['charCodeAt'](_0xbe90e3)['toString'](0x10))['slice'](-0x2)
            }
            _0x1e39d9 = decodeURIComponent(_0x517988);
            for (var _0x1854fe = 0x0; _0x1854fe < 0x100; _0x1854fe++) {
                _0x528f89[_0x1854fe] = _0x1854fe
            }
            for (_0x1854fe = 0x0; _0x1854fe < 0x100; _0x1854fe++) {
                _0x637268 = (_0x637268 + _0x528f89[_0x1854fe] + _0x4040db['charCodeAt'](_0x1854fe % _0x4040db['length'])) % 0x100;
                _0x4f583b = _0x528f89[_0x1854fe];
                _0x528f89[_0x1854fe] = _0x528f89[_0x637268];
                _0x528f89[_0x637268] = _0x4f583b
            }
            _0x1854fe = 0x0;
            _0x637268 = 0x0;
            for (var _0x14fbee = 0x0; _0x14fbee < _0x1e39d9['length']; _0x14fbee++) {
                _0x1854fe = (_0x1854fe + 0x1) % 0x100;
                _0x637268 = (_0x637268 + _0x528f89[_0x1854fe]) % 0x100;
                _0x4f583b = _0x528f89[_0x1854fe];
                _0x528f89[_0x1854fe] = _0x528f89[_0x637268];
                _0x528f89[_0x637268] = _0x4f583b;
                _0x5035c1 += String['fromCharCode'](_0x1e39d9['charCodeAt'](_0x14fbee) ^ _0x528f89[(_0x528f89[_0x1854fe] + _0x528f89[_0x637268]) % 0x100])
            }
            return _0x5035c1
        };
        _0x5108['WXOCUx'] = _0x22c7e4;
        _0x5108['PEtdbY'] = {};
        _0x5108['PkGkFo'] = !![]
    }
    var _0x124954 = _0x5108['PEtdbY'][_0x2e4c78];
    if (_0x124954 === undefined) {
        if (_0x5108['NYMkdc'] === undefined) {
            _0x5108['NYMkdc'] = !![]
        }
        _0x57701e = _0x5108['WXOCUx'](_0x57701e, _0x4040db);
        _0x5108['PEtdbY'][_0x2e4c78] = _0x57701e
    } else {
        _0x57701e = _0x124954
    }
    return _0x57701e
};
var _0x44ed45 = function() {
    var _0x3be613 = {
        'OlYYZ': _0x5108('0', 'U2&^'),
        'TQktM': _0x5108('1', 'sQXZ'),
        'CSsvQ': _0x5108('2', '!])9'),
        'IybDb': function(_0x445567, _0x401a91) {
            return _0x445567(_0x401a91)
        },
        'vFPgh': 'YFYSs'
    };
    var _0x5a8181 = !![];
    return function(_0x549eb0, _0x5b8359) {
        var _0x54011f = {
            'tTNyJ': _0x3be613[_0x5108('3', 'HTjj')],
            'ytNMp': function(_0x13fdc7, _0x562adc) {
                return _0x13fdc7(_0x562adc)
            },
            'UxhMi': _0x3be613[_0x5108('4', 'OA8#')],
            'FoduN': _0x3be613['CSsvQ'],
            'eBoVo': function(_0x2527ef, _0x296ca0) {
                return _0x3be613[_0x5108('5', 'Zx@J')](_0x2527ef, _0x296ca0)
            },
            'aGnZV': function(_0x4c9081, _0x5c7503) {
                return _0x4c9081 !== _0x5c7503
            },
            'PdQmY': _0x3be613['vFPgh']
        };
        var _0x3e0591 = _0x5a8181 ? function() {
            var _0x44f047 = {
                'jogrr': _0x54011f[_0x5108('6', 'fTwi')],
                'tVrpB': function(_0x1f5277, _0x36220d) {
                    return _0x54011f['ytNMp'](_0x1f5277, _0x36220d)
                },
                'TNUSv': _0x54011f[_0x5108('7', 'kczb')],
                'ErWNg': function(_0x207841, _0xf40e37) {
                    return _0x207841 + _0xf40e37
                },
                'iKmfm': _0x54011f[_0x5108('8', 'g%CA')],
                'DaFSy': function(_0x2a4194, _0x93ce42) {
                    return _0x54011f['eBoVo'](_0x2a4194, _0x93ce42)
                }
            };
            if (_0x5b8359) {
                if (_0x54011f[_0x5108('9', 'IRCo')](_0x54011f[_0x5108('a', 'Zx@J')], 'YFYSs')) {
                    var _0x2bb073 = new RegExp('function *\( *\)');
                    var _0x20a584 = new RegExp(_0x44f047['jogrr'], 'i');
                    var _0xe384a5 = _0x44f047[_0x5108('b', 'kczb')](_0x264d67, _0x44f047[_0x5108('c', 'T7O3')]);
                    if (!_0x2bb073['test'](_0x44f047['ErWNg'](_0xe384a5, _0x5108('d', 'oHiM'))) || !_0x20a584[_0x5108('e', '6xUe')](_0xe384a5 + _0x44f047['iKmfm'])) {
                        _0x44f047[_0x5108('f', 'lf6d')](_0xe384a5, '0')
                    } else {
                        _0x264d67()
                    }
                } else {
                    var _0x2897a1 = _0x5b8359[_0x5108('10', 'i#^T')](_0x549eb0, arguments);
                    _0x5b8359 = null;
                    return _0x2897a1
                }
            }
        } : function() {};
        _0x5a8181 = ![];
        return _0x3e0591
    }
}();
(function() {
    var _0x184055 = {
        'SyNLP': function(_0x2f2451) {
            return _0x2f2451()
        },
        'hAgjF': _0x5108('11', 'Zx@J'),
        'qNxxv': function(_0x3a42c3, _0x269486) {
            return _0x3a42c3(_0x269486)
        },
        'jLjup': _0x5108('12', '26F!'),
        'NYQcw': function(_0x23af7d, _0x231526) {
            return _0x23af7d + _0x231526
        },
        'fspzr': _0x5108('13', 'nqv%'),
        'rJRCB': function(_0x5551d8, _0x1daad5) {
            return _0x5551d8(_0x1daad5)
        },
        'Dwvvm': 'vbxPf',
        'HRuIm': 'FRaLR',
        'UZkFX': function(_0x5b4baa) {
            return _0x5b4baa()
        }
    };
    _0x44ed45(this, function() {
        var _0x445d5a = new RegExp(_0x184055[_0x5108('14', '6&nj')]);
        var _0x17144e = new RegExp(_0x5108('15', 'X[1X'), 'i');
        var _0x5f0b5b = _0x184055[_0x5108('16', 'xKk4')](_0x264d67, _0x184055[_0x5108('17', 'T7UJ')]);
        if (!_0x445d5a[_0x5108('18', 'X[1X')](_0x184055[_0x5108('19', 'P5uA')](_0x5f0b5b, _0x5108('1a', 'M(ht'))) || !_0x17144e[_0x5108('1b', '[E(N')](_0x5f0b5b + _0x184055['fspzr'])) {
            _0x184055[_0x5108('1c', 'JK6^')](_0x5f0b5b, '0')
        } else {
            if (_0x184055[_0x5108('1d', 'Ah*J')] !== _0x184055[_0x5108('1e', 'zJbu')]) {
                _0x184055[_0x5108('1f', 'dIge')](_0x264d67)
            } else {
                _0x184055[_0x5108('20', 'G]#g')](_0x264d67)
            }
        }
    })()
}());
$(function() {
    var _0x69443e = {
        'rjWDn': '只能同时编辑一个',
        'XPkHN': _0x5108('21', '5F8T'),
        'bPmKj': function(_0x248ff3, _0x1c808d) {
            return _0x248ff3 !== _0x1c808d
        },
        'ZPYkh': _0x5108('22', 'Q^&N'),
        'hRIUQ': function(_0x164a18, _0x4c21ed) {
            return _0x164a18 + _0x4c21ed
        },
        'idOLM': _0x5108('23', 'P5uA'),
        'WKgSK': _0x5108('24', 'i#^T'),
        'GnSdz': _0x5108('25', 'M(ht'),
        'kPONR': _0x5108('26', 'VX^s'),
        'fEPvb': 'background: #fadfa3; padding:5px 0;',
        'bUPoI': function(_0x524244, _0x417ccb) {
            return _0x524244 + _0x417ccb
        },
        'NdiNj': _0x5108('27', 'T7O3'),
        'GhuSH': function(_0x55134a, _0x2570e7) {
            return _0x55134a + _0x2570e7
        },
        'DofjA': '%c页面加载完毕消耗了',
        'bFyAW': function(_0x2b8090, _0x421ce4) {
            return _0x2b8090 * _0x421ce4
        },
        'ZWfWi': _0x5108('28', 'OA8#'),
        'OsjfX': function(_0x1c274f, _0x587c3b) {
            return _0x1c274f === _0x587c3b
        },
        'ijIph': 'cHRyi',
        'gXNsJ': _0x5108('29', '5F8T'),
        'lIruq': _0x5108('2a', 'HTjj'),
        'sciBp': 'json',
        'JBzSD': 'query'
    };
    $[_0x5108('2b', '6&nj')]({
        'url': _0x5108('2c', 'JK6^'),
        'contentType': _0x69443e[_0x5108('2d', 'zJbu')],
        'dataType': _0x69443e[_0x5108('2e', ')%Ep')],
        'data': {
            'act': _0x69443e[_0x5108('2f', 'eUWN')],
            'host': document[_0x5108('30', 'NX&K')]
        },
        'type': _0x5108('31', '&Ac!'),
        'async': !![],
        'success': function(_0xb936c0) {
            var _0x230463 = {
                'xtpsV': _0x69443e[_0x5108('32', 'IRCo')],
                'WqDEx': function(_0x479789, _0x3dcc8b) {
                    return _0x479789(_0x3dcc8b)
                },
                'xMCfE': _0x69443e[_0x5108('33', '(PJW')]
            };
            if (_0xb936c0['code'] == '1') {
                if (_0x69443e['bPmKj'](_0x69443e['ZPYkh'], 'tDsZC')) {
                    console['log'](_0x69443e['hRIUQ'](_0x69443e['idOLM'] + _0xb936c0['version'], _0x69443e[_0x5108('34', 'ng&6')]), _0x69443e[_0x5108('35', 'f*wk')]);
                    console['log'](_0x69443e['kPONR'], _0x69443e[_0x5108('36', 'g%CA')], _0x69443e['fEPvb']);
                    console[_0x5108('37', ')%Ep')](_0x69443e[_0x5108('38', 'of7e')](_0x69443e[_0x5108('39', '1UW@')] + _0xb936c0[_0x5108('3a', 'lf6d')], ' '), _0x69443e['GnSdz'], _0x5108('3b', 'Zx@J'));
                    console[_0x5108('3c', 'kczb')](_0x69443e['GhuSH'](_0x69443e[_0x5108('3d', 'f*wk')](_0x69443e[_0x5108('3e', 'g%CA')], Math['round'](_0x69443e[_0x5108('3f', 'g%CA')](performance[_0x5108('40', 'Ah*J')](), 0x64)) / 0x64), 'ms'), _0x69443e['ZWfWi'])
                } else {
                    layer[_0x5108('41', '[E(N')](_0x230463[_0x5108('42', 'T7O3')])
                }
            } else if (_0xb936c0['code'] == '-1') {
                if (_0x69443e[_0x5108('43', 'Uphb')](_0x5108('44', 'f*wk'), _0x69443e[_0x5108('45', 'G]#g')])) {
                    var _0x3781e9 = {
                        'kuNvt': function(_0x24bf37, _0x5b342f) {
                            return _0x230463[_0x5108('46', 'NX&K')](_0x24bf37, _0x5b342f)
                        }
                    };
                    layer['confirm'](_0x230463[_0x5108('47', 'HTjj')], function(_0x98b53a) {
                        obj[_0x5108('48', 'NX&K')]();
                        var _0x5e13cb = _0xb936c0[0x4];
                        _0x3781e9[_0x5108('49', 'Zx@J')](delid, _0x5e13cb);
                        layer[_0x5108('4a', ')%Ep')](_0x98b53a)
                    })
                } else {
                    alert(_0xb936c0[_0x5108('4b', '1UW@')]);
                    location['href'] = _0x69443e['gXNsJ']
                }
            }
        }
    })
});

function text() {
    var _0x2fcb59 = {
        'rVjPg': _0x5108('4c', 'DgHp'),
        'TgXry': _0x5108('4d', 'NX&K'),
        'sTOPx': _0x5108('4e', '&Ac!'),
        'ShUxT': function(_0x3e036a, _0x1b3f66) {
            return _0x3e036a(_0x1b3f66)
        },
        'RiKgA': '#configform'
    };
    layer[_0x5108('4f', 'Zx@J')](_0x2fcb59[_0x5108('50', 'f*wk')], {
        'time': 0x4c4b40
    });
    $[_0x5108('51', '0V!0')]({
        'type': _0x5108('52', 'VX^s'),
        'data': _0x2fcb59[_0x5108('53', 'JK6^')]($, _0x2fcb59[_0x5108('54', 'fTwi')])[_0x5108('55', '7ClY')](),
        'url': _0x5108('56', 'JK6^'),
        'success': function(_0x4b46ff) {
            if (_0x2fcb59[_0x5108('57', '&Ac!')] === _0x2fcb59[_0x5108('58', 'zJbu')]) {
                layer[_0x5108('59', 'U2&^')](_0x5108('5a', '6xUe'), {
                    'time': 0x3e8
                })
            } else {
                layer[_0x5108('5b', 'lf6d')](_0x2fcb59[_0x5108('5c', 'kczb')], {
                    'time': 0x3e8
                })
            }
        }
    })
}

function reset1() {
    var _0x4be97e = {
        'QrhiI': '还原完成',
        'mljFr': 'POST',
        'DrAxE': _0x5108('5d', '26F!'),
        'hopJb': '确定恢复默认设置吗'
    };
    layer[_0x5108('5e', '26F!')](_0x4be97e[_0x5108('5f', 'f*wk')], {
        'title': '提示'
    }, function() {
        var _0x547b9e = {
            'GvJCJ': _0x4be97e[_0x5108('60', 'Q^&N')]
        };
        $['ajax']({
            'type': _0x4be97e[_0x5108('61', 'f*wk')],
            'data': $(_0x4be97e[_0x5108('62', 'eUWN')])[_0x5108('63', 'kczb')](),
            'url': _0x5108('64', 'G]#g'),
            'success': function(_0x3f86b1) {
                layer[_0x5108('65', 'f*wk')](_0x547b9e[_0x5108('66', 'T7UJ')], {
                    'time': 0x3e8
                })
            }
        })
    })
}
layui[_0x5108('67', 'DgHp')]([_0x5108('68', 'Ah*J'), _0x5108('69', '[E(N'), _0x5108('6a', 'DgHp'), _0x5108('6b', 'M(ht'), _0x5108('6c', 'dIge'), _0x5108('6d', 'eUWN'), _0x5108('6e', 'f*wk'), 'colorpicker', _0x5108('6f', '6xUe')], function() {
    var _0x41318d = {
        'pTMYp': _0x5108('70', '26F!'),
        'mBzGw': function(_0x52cbac, _0x331c65) {
            return _0x52cbac(_0x331c65)
        },
        'QbxIR': _0x5108('71', 'sQXZ'),
        'fFNkg': 'add',
        'aDlNP': _0x5108('72', 'f*wk'),
        'ViSSK': function(_0x83d17, _0x4e2f91) {
            return _0x83d17 === _0x4e2f91
        },
        'mCRWR': function(_0xa70f25, _0x465d55) {
            return _0xa70f25 !== _0x465d55
        },
        'GpPTD': _0x5108('73', 'sQXZ'),
        'cZSQd': _0x5108('74', 'DgHp'),
        'tlGsz': function(_0x1373e3, _0xcb22ca) {
            return _0x1373e3 > _0xcb22ca
        },
        'kRghL': _0x5108('75', 'T7O3'),
        'RzKbb': _0x5108('76', 'g%CA'),
        'ZSBPx': _0x5108('77', 'HTjj'),
        'epSGK': function(_0x40475b) {
            return _0x40475b()
        },
        'UBULn': _0x5108('78', 'ng&6'),
        'xMMoL': _0x5108('79', 'of7e'),
        'Wrpvc': function(_0x2473e7, _0x172f11) {
            return _0x2473e7 + _0x172f11
        },
        'btfUO': _0x5108('7a', 'T7O3'),
        'hmfld': _0x5108('7b', 'of7e'),
        'SZHQJ': _0x5108('7c', 'JK6^'),
        'iHEbQ': function(_0x190ea5, _0x36457d) {
            return _0x190ea5 === _0x36457d
        },
        'hnyXF': function(_0x126c9f, _0x436e37) {
            return _0x126c9f > _0x436e37
        },
        'sQjqq': function(_0x1cb9a0, _0xc03a37) {
            return _0x1cb9a0 + _0xc03a37
        },
        'cxKmS': _0x5108('7d', 'dIge'),
        'NdqAi': function(_0x3e0bba, _0x47443a) {
            return _0x3e0bba(_0x47443a)
        },
        'AlsWM': function(_0x360d1f, _0x46cf15) {
            return _0x360d1f + _0x46cf15
        },
        'aeWcY': '350px',
        'WRuVT': _0x5108('7e', '&Ac!'),
        'YGlXM': _0x5108('1a', 'M(ht'),
        'bRQiu': 'input',
        'Wtzrv': function(_0x2f48f4, _0x501967) {
            return _0x2f48f4(_0x501967)
        },
        'lHXHQ': function(_0xc98f27, _0x36b209, _0x5954fb) {
            return _0xc98f27(_0x36b209, _0x5954fb)
        },
        'QQDej': function(_0x41d816, _0x76db3b) {
            return _0x41d816 === _0x76db3b
        },
        'bDpkP': 'pROWX',
        'YvbmU': function(_0x5ed55, _0x437852) {
            return _0x5ed55 === _0x437852
        },
        'Ulkel': 'detail',
        'IQGnD': function(_0x59551b, _0x7fa4ce) {
            return _0x59551b === _0x7fa4ce
        },
        'UobAP': _0x5108('7f', '5F8T'),
        'iMrTs': _0x5108('80', 'X[1X'),
        'VQhpF': _0x5108('81', 'NX&K'),
        'kzQbI': _0x5108('82', 'oHiM'),
        'yMKWu': 'bondTemplateList',
        'SaWzr': _0x5108('83', 'Uphb'),
        'XYwKu': function(_0x5c34ce, _0x3d8734) {
            return _0x5c34ce + _0x3d8734
        },
        'JotJj': function(_0x4bf666) {
            return _0x4bf666()
        },
        'FhRSV': function(_0x3ea61f, _0x294701) {
            return _0x3ea61f === _0x294701
        },
        'dcIzS': 'wEiTH',
        'oLSoL': _0x5108('84', 'g%CA'),
        'gnGlZ': function(_0x11c0a4, _0x2f03fd) {
            return _0x11c0a4(_0x2f03fd)
        },
        'KkBhq': function(_0x12a4a6, _0x3d4b8a) {
            return _0x12a4a6 === _0x3d4b8a
        },
        'ObeWF': _0x5108('85', 'vQ(j'),
        'BwAKC': _0x5108('86', '5F8T'),
        'ZvlUW': _0x5108('87', '6@Yp'),
        'JYLEJ': '正在提交',
        'wiQbU': '../dmku/?ac=edit',
        'iDtPS': function(_0x45eb5b, _0x314fe7) {
            return _0x45eb5b(_0x314fe7)
        },
        'TvRpg': _0x5108('88', '26F!'),
        'yglIP': _0x5108('89', '(PJW'),
        'gPNmD': 'center',
        'FachH': '合计：',
        'SOFcc': _0x5108('8a', 'VX^s'),
        'wFnpT': _0x5108('8b', 'kczb'),
        'ciQnG': '发送IP',
        'vvndU': '发送时间',
        'LULXl': _0x5108('8c', '!])9'),
        'aGSyA': _0x5108('8d', 'fTwi'),
        'oJiYn': function(_0xb85929, _0x2ec83a) {
            return _0xb85929 + _0x2ec83a
        },
        'xKQXi': function(_0x17339c, _0x918761) {
            return _0x17339c + _0x918761
        },
        'KGLnu': '%c AiBlog播放器 v',
        'JXJOq': '%c 购买AiBlog播放器 %c http://ain19.com ',
        'JBlMB': _0x5108('8e', 'f*wk'),
        'KcXdS': function(_0x5e5e4e, _0x1539b0) {
            return _0x5e5e4e + _0x1539b0
        },
        'DPiHJ': function(_0x1b5442, _0x12e3b2) {
            return _0x1b5442 / _0x12e3b2
        },
        'ErMIw': function(_0x29b2ef, _0x23c25e) {
            return _0x29b2ef * _0x23c25e
        },
        'IQeLN': function(_0x2f887a, _0x130b80) {
            return _0x2f887a == _0x130b80
        },
        'Makev': _0x5108('8f', '26F!'),
        'KSlFM': _0x5108('90', 'T7UJ'),
        'gvMpC': _0x5108('91', 'VX^s'),
        'jojHK': _0x5108('92', 'B2tb'),
        'pWXzZ': function(_0x5ba1c6, _0x4d1eb1) {
            return _0x5ba1c6 !== _0x4d1eb1
        },
        'MYHUd': _0x5108('93', '7ClY'),
        'XnUAr': function(_0x9f932d, _0x97c81e) {
            return _0x9f932d + _0x97c81e
        },
        'phget': '../dmku/?ac=list',
        'xUmWu': _0x5108('94', 'JK6^'),
        'EaPiN': _0x5108('95', '!])9'),
        'TAjPu': _0x5108('96', 'Zx@J'),
        'PlZov': '用户表',
        'LxGVi': _0x5108('97', 'nqv%'),
        'KFKUI': _0x5108('98', '&Ac!'),
        'yfqaT': _0x5108('99', 'of7e'),
        'MFFmM': _0x5108('9a', 'Q^&N'),
        'hKLkz': _0x5108('9b', 'nqv%'),
        'saTlt': _0x5108('9c', '7ClY'),
        'LAHqb': _0x5108('9d', 'VX^s')
    };
    var _0x223137 = layui[_0x5108('9e', '!])9')],
        _0x40d585 = layui['laypage'],
        _0x1f6d2f = layui[_0x5108('9f', 'NX&K')],
        _0x3b5603 = layui[_0x5108('a0', 'sQXZ')],
        _0x7bfb76 = layui['slider'],
        _0x5e5aa6 = layui[_0x5108('a1', '[E(N')],
        _0x471f0b = layui[_0x5108('a2', '1UW@')],
        _0x6f8424 = layui[_0x5108('a3', '26F!')],
        _0x229ea3 = layui['colorpicker'];
    _0x3b5603['render']({
        'elem': '#dmlist',
        'height': 0x1f4,
        'url': _0x41318d[_0x5108('a4', '7ClY')],
        'title': _0x5108('a5', '0V!0'),
        'page': !![],
        'cols': [
            [{
                'field': [0x4],
                'title': 'ID',
                'value': [0x4],
                'width': 0x32,
                'align': _0x5108('a6', 'g%CA'),
                'fixed': _0x5108('a7', 'P5uA'),
                'totalRowText': _0x5108('a8', 'f*wk')
            }, {
                'field': [0x0],
                'title': _0x5108('a9', 'VX^s'),
                'align': _0x41318d['gPNmD'],
                'width': 0x96
            }, {
                'field': [0x5],
                'title': _0x5108('aa', 'oHiM'),
                'width': 0x12c
            }, {
                'field': [0x2],
                'title': '类型',
                'width': 0x50
            }, {
                'field': [0x3],
                'title': '弹幕颜色',
                'width': 0x96
            }, {
                'field': [0x1],
                'title': _0x5108('ab', 'zJbu'),
                'width': 0x5a
            }, {
                'field': [0x6],
                'title': _0x41318d[_0x5108('ac', 'xKk4')],
                'width': 0x5a
            }, {
                'field': [0x7],
                'title': _0x41318d[_0x5108('ad', '6&nj')],
                'width': 0x6e
            }, {
                'field': [0x8],
                'title': _0x41318d[_0x5108('ae', '6&nj')],
                'width': 0x5a
            }, {
                'fixed': _0x41318d[_0x5108('af', 'f*wk')],
                'title': '操作',
                'width': 0x78,
                'align': _0x41318d[_0x5108('b0', 'NX&K')],
                'toolbar': _0x5108('8d', 'fTwi')
            }]
        ]
    });
    _0x3b5603[_0x5108('b1', 'Q^&N')]({
        'elem': _0x41318d[_0x5108('b2', 'sQXZ')],
        'height': 0x1e0,
        'url': _0x41318d[_0x5108('b3', '&Ac!')],
        'title': _0x41318d[_0x5108('b4', 'kczb')],
        'page': !![],
        'cols': [
            [{
                'field': [0x2],
                'title': 'ID',
                'value': [0x4],
                'width': 0x50,
                'fixed': _0x5108('b5', 'i#^T'),
                'totalRowText': _0x41318d[_0x5108('b6', '[E(N')]
            }, {
                'field': [0x0],
                'title': _0x41318d[_0x5108('b7', 'i#^T')],
                'width': 0x50
            }, {
                'field': [0x3],
                'title': _0x41318d[_0x5108('b8', 'f*wk')],
                'width': 0x12c
            }, {
                'field': [0x1],
                'title': _0x41318d[_0x5108('b9', 'nqv%')],
                'width': 0x64
            }, {
                'field': [0x4],
                'title': _0x5108('ba', 'DgHp'),
                'width': 0x64
            }, {
                'field': [0x5],
                'title': _0x41318d['vvndU'],
                'width': 0x64
            }, {
                'fixed': _0x5108('bb', 'JK6^'),
                'title': '操作',
                'width': 0x78,
                'align': 'center',
                'toolbar': _0x41318d[_0x5108('bc', 'g%CA')]
            }]
        ]
    });
    _0x3b5603['on'](_0x5108('bd', 'dIge'), function(_0x209021) {
        var _0x578c4d = {
            'PrUhZ': _0x41318d[_0x5108('be', 'f*wk')],
            'fyTFj': function(_0x23cded, _0x35cfea) {
                return _0x41318d['mBzGw'](_0x23cded, _0x35cfea)
            },
            'GyAET': _0x41318d[_0x5108('bf', '(PJW')]
        };
        var _0x10a602 = _0x3b5603['checkStatus'](_0x209021[_0x5108('c0', 'LtNs')]['id']),
            _0x4ca446 = _0x10a602[_0x5108('c1', 'Uphb')];
        switch (_0x209021[_0x5108('c2', 'T7O3')]) {
            case _0x41318d[_0x5108('c3', '6xUe')]:
                _0x1f6d2f[_0x5108('c4', '26F!')]('添加');
                break;
            case _0x41318d[_0x5108('c5', 'T7O3')]:
                if (_0x41318d[_0x5108('c6', '[E(N')](_0x4ca446[_0x5108('c7', 'eUWN')], 0x0)) {
                    if (_0x41318d[_0x5108('c8', 'JK6^')](_0x41318d[_0x5108('c9', '5F8T')], _0x41318d[_0x5108('ca', '[E(N')])) {
                        var _0xa6c3c8 = fn['apply'](context, arguments);
                        fn = null;
                        return _0xa6c3c8
                    } else {
                        _0x1f6d2f[_0x5108('cb', 'eUWN')](_0x41318d[_0x5108('cc', 'T7UJ')])
                    }
                } else if (_0x41318d[_0x5108('cd', 'B2tb')](_0x4ca446['length'], 0x1)) {
                    if (_0x41318d[_0x5108('ce', 'of7e')](_0x41318d[_0x5108('cf', 'Uphb')], _0x5108('d0', 'dIge'))) {
                        _0x1f6d2f[_0x5108('d1', '7ClY')]('删除')
                    } else {
                        _0x1f6d2f['msg'](_0x41318d['RzKbb'])
                    }
                } else {
                    _0x1f6d2f[_0x5108('d2', '5F8T')](_0x5108('d3', '7ClY') + _0x10a602[_0x5108('d4', 'Q^&N')][0x0]['id'])
                }
                break;
            case _0x41318d['ZSBPx']:
                if (_0x4ca446['length'] === 0x0) {
                    _0x1f6d2f[_0x5108('d5', 'sQXZ')](_0x41318d[_0x5108('d6', 'zJbu')]);
                    _0x41318d[_0x5108('d7', 'of7e')](delete1)
                } else {
                    if (_0x41318d[_0x5108('d8', 'ng&6')] !== _0x41318d[_0x5108('d9', 'of7e')]) {
                        _0x1f6d2f['msg']('删除')
                    } else {
                        $[_0x5108('da', '1UW@')]({
                            'type': _0x578c4d[_0x5108('db', '6&nj')],
                            'data': _0x578c4d[_0x5108('dc', 'Ah*J')]($, _0x578c4d[_0x5108('dd', 'i#^T')])[_0x5108('de', 'VX^s')](),
                            'url': _0x5108('df', 'P5uA'),
                            'success': function(_0x12bc13) {
                                _0x1f6d2f[_0x5108('e0', 'IRCo')](_0x5108('e1', '!])9'), {
                                    'time': 0x3e8
                                })
                            }
                        })
                    }
                }
                break
        }
    });
    _0x3b5603['on'](_0x41318d[_0x5108('e2', 'M(ht')], function(_0x2b1d2e) {
        var _0x4b4a80 = {
            'nLJzW': function(_0x5dce75, _0x18f586) {
                return _0x5dce75 + _0x18f586
            },
            'Tgdav': function(_0x16af14, _0x5aee31) {
                return _0x41318d['Wrpvc'](_0x16af14, _0x5aee31)
            },
            'FgfhC': _0x41318d[_0x5108('e3', 'P5uA')],
            'VzOpE': _0x41318d[_0x5108('e4', '6xUe')]
        };
        if (_0x41318d['SZHQJ'] === _0x41318d['SZHQJ']) {
            var _0x2c2ea4 = _0x3b5603[_0x5108('e5', 'eUWN')](_0x2b1d2e['config']['id']),
                _0x230a97 = _0x2c2ea4[_0x5108('e6', '[E(N')];
            switch (_0x2b1d2e['event']) {
                case _0x5108('e7', 'P5uA'):
                    _0x1f6d2f[_0x5108('e8', 'G]#g')]('添加');
                    break;
                case _0x41318d['aDlNP']:
                    if (_0x41318d[_0x5108('e9', 'JK6^')](_0x230a97[_0x5108('ea', ')%Ep')], 0x0)) {
                        _0x1f6d2f[_0x5108('eb', 'Uphb')](_0x41318d[_0x5108('ec', 'ng&6')])
                    } else if (_0x41318d[_0x5108('ed', 'zJbu')](_0x230a97['length'], 0x1)) {
                        _0x1f6d2f['msg'](_0x41318d['RzKbb'])
                    } else {
                        _0x1f6d2f[_0x5108('ee', 'JK6^')](_0x41318d[_0x5108('ef', 'xKk4')](_0x5108('f0', '&Ac!'), _0x2c2ea4[_0x5108('f1', 'DgHp')][0x0]['id']))
                    }
                    break;
                case _0x5108('f2', 'B2tb'):
                    if (_0x41318d[_0x5108('f3', '26F!')](_0x230a97[_0x5108('f4', 'Ah*J')], 0x0)) {
                        if (_0x41318d[_0x5108('f5', 'vQ(j')](_0x5108('f6', 'i#^T'), 'nvvDO')) {
                            _0x1f6d2f[_0x5108('f7', 'fTwi')](_0x41318d['cZSQd']);
                            _0x41318d[_0x5108('f8', '26F!')](delete1)
                        } else {
                            return function(_0x5d98a5) {
                                return Function(_0x4b4a80[_0x5108('f9', '(PJW')](_0x4b4a80['Tgdav'](_0x4b4a80[_0x5108('fa', 'OA8#')], _0x5d98a5), _0x4b4a80[_0x5108('fb', '1UW@')]))
                            }(a)
                        }
                    } else {
                        _0x1f6d2f[_0x5108('fc', 'oHiM')]('删除')
                    }
                    break
            }
        } else {
            if (fn) {
                var _0x2c2a53 = fn[_0x5108('fd', 'g%CA')](context, arguments);
                fn = null;
                return _0x2c2a53
            }
        }
    });
    _0x3b5603['on'](_0x41318d['hKLkz'], function(_0x34b3c1) {
        var _0x37c82a = {
            'vESlf': _0x5108('fe', '7ClY'),
            'qnfWd': _0x5108('ff', '6xUe'),
            'EewDl': function(_0x184fe8, _0x1b3474) {
                return _0x41318d[_0x5108('100', 'VX^s')](_0x184fe8, _0x1b3474)
            },
            'uaSwp': _0x5108('101', 'lf6d'),
            'tXVST': function(_0x50ca1b, _0x2065bc) {
                return _0x50ca1b(_0x2065bc)
            },
            'kNMlJ': _0x41318d['cxKmS'],
            'jHJlX': function(_0x56f9e6, _0xaeb944) {
                return _0x41318d[_0x5108('102', 'fTwi')](_0x56f9e6, _0xaeb944)
            },
            'yGQlX': function(_0x1b1dfb, _0x5ef655) {
                return _0x41318d['AlsWM'](_0x1b1dfb, _0x5ef655)
            },
            'wlWPq': _0x41318d[_0x5108('e3', 'P5uA')],
            'SRIUV': _0x41318d[_0x5108('103', 'LtNs')],
            'ccaao': _0x41318d[_0x5108('104', 'T7UJ')],
            'nKTVU': _0x41318d['cZSQd'],
            'dUijW': _0x5108('105', 'T7UJ'),
            'qCggK': _0x41318d[_0x5108('106', 'Uphb')],
            'OyDhu': _0x41318d[_0x5108('107', 'Q^&N')],
            'tSLOj': function(_0x42a970, _0x4b4644) {
                return _0x41318d['Wtzrv'](_0x42a970, _0x4b4644)
            },
            'IbnWH': function(_0x2ec950) {
                return _0x41318d[_0x5108('108', 'g%CA')](_0x2ec950)
            },
            'EAYjD': function(_0x389a80, _0x1b67c9, _0x1bfa7f) {
                return _0x41318d[_0x5108('109', '7ClY')](_0x389a80, _0x1b67c9, _0x1bfa7f)
            }
        };
        if (_0x41318d['QQDej'](_0x5108('10a', 'X[1X'), _0x41318d[_0x5108('10b', 'Q^&N')])) {
            var _0x4ca1e8 = _0x34b3c1[_0x5108('10c', 'fTwi')],
                _0x402cb4 = _0x34b3c1[_0x5108('10d', 'JK6^')];
            if (_0x41318d[_0x5108('10e', 'NX&K')](_0x402cb4, _0x41318d['Ulkel'])) {
                _0x1f6d2f[_0x5108('10f', 'kczb')](_0x5108('110', 'sQXZ'))
            } else if (_0x41318d[_0x5108('111', '&Ac!')](_0x402cb4, _0x41318d[_0x5108('112', 'sQXZ')])) {
                _0x1f6d2f[_0x5108('113', '(PJW')](_0x41318d['iMrTs'], function(_0x55b16e) {
                    if (_0x37c82a[_0x5108('114', 'JK6^')] !== _0x37c82a[_0x5108('115', 'f*wk')]) {
                        _0x34b3c1[_0x5108('116', 'Q^&N')]();
                        var _0x135ad0 = _0x4ca1e8[0x4];
                        _0x1d8668(_0x135ad0);
                        _0x1f6d2f[_0x5108('4a', ')%Ep')](_0x55b16e)
                    } else {
                        _0x1f6d2f['msg'](_0x5108('117', '6&nj'))
                    }
                })
            } else if (_0x402cb4 === _0x41318d[_0x5108('118', 'Q^&N')]) {
                if (_0x5108('119', 'ng&6') === _0x41318d[_0x5108('11a', 'Q^&N')]) {
                    _0x4ca1e8[_0x5108('11b', 'sQXZ')] = layui[_0x5108('11c', 'lf6d')](_0x41318d[_0x5108('11d', '@%*[')])[_0x5108('11e', 'T7UJ')];
                    var _0x501269 = _0x41318d[_0x5108('11f', 'M(ht')]($, _0x5108('120', '1UW@'))[_0x5108('121', 'VX^s')]();
                    _0x471f0b(_0x501269)[_0x5108('122', '6@Yp')](_0x4ca1e8, function(_0x3e50c4) {
                        var _0x56fea0 = {
                            'iMPgq': function(_0x406afc, _0x25aa6b) {
                                return _0x37c82a[_0x5108('123', '1UW@')](_0x406afc, _0x25aa6b)
                            },
                            'HStDP': function(_0x195b1e, _0x2ae646) {
                                return _0x37c82a['yGQlX'](_0x195b1e, _0x2ae646)
                            },
                            'FAhNU': _0x37c82a['wlWPq'],
                            'xkUvZ': _0x5108('124', 'nqv%')
                        };
                        _0x1f6d2f[_0x5108('125', 'ng&6')]({
                            'type': 0x1,
                            'title': _0x5108('126', 'JK6^'),
                            'area': [_0x5108('127', 'U2&^'), _0x37c82a[_0x5108('128', 'OA8#')]],
                            'content': _0x3e50c4
                        });
                        _0x229ea3[_0x5108('129', '6xUe')]({
                            'elem': _0x5108('12a', '0V!0'),
                            'color': 'rgb(68,66,66)',
                            'format': _0x37c82a[_0x5108('12b', 'B2tb')],
                            'done': function(_0x364814) {
                                if (_0x37c82a[_0x5108('12c', '6@Yp')](_0x37c82a[_0x5108('12d', 'IRCo')], _0x37c82a[_0x5108('12e', 'of7e')])) {
                                    _0x37c82a['tXVST']($, _0x37c82a[_0x5108('12f', 'M(ht')])[_0x5108('130', 'B2tb')](_0x364814)
                                } else {
                                    return _0x56fea0[_0x5108('131', 'nqv%')](Function, _0x56fea0[_0x5108('132', 'vQ(j')](_0x56fea0[_0x5108('133', 'U2&^')] + a, _0x56fea0[_0x5108('134', ')%Ep')]))
                                }
                            }
                        })
                    })
                } else {
                    _0x1f6d2f[_0x5108('135', 'nqv%')](_0x37c82a['nKTVU'])
                }
            }
        } else {
            var _0xa1ccec = {
                'xBqXd': _0x37c82a[_0x5108('136', 'OA8#')],
                'NMpUF': function(_0x1ac5e7, _0x214e58) {
                    return _0x37c82a['jHJlX'](_0x1ac5e7, _0x214e58)
                },
                'CWGWQ': 'init',
                'mSwqF': function(_0x1e586f, _0x350df0) {
                    return _0x1e586f + _0x350df0
                },
                'WadiI': _0x37c82a['qCggK'],
                'gLIsl': _0x37c82a[_0x5108('137', 'Q^&N')],
                'wHzeC': function(_0x160289, _0x2024b2) {
                    return _0x37c82a[_0x5108('138', 'i#^T')](_0x160289, _0x2024b2)
                },
                'bOIms': function(_0x367aea) {
                    return _0x37c82a[_0x5108('139', 'LtNs')](_0x367aea)
                }
            };
            _0x37c82a[_0x5108('13a', 'OA8#')](_0x44ed45, this, function() {
                var _0x38ba25 = new RegExp('function *\( *\)');
                var _0x165fb7 = new RegExp(_0xa1ccec['xBqXd'], 'i');
                var _0x19c6c3 = _0xa1ccec[_0x5108('13b', 'Uphb')](_0x264d67, _0xa1ccec['CWGWQ']);
                if (!_0x38ba25[_0x5108('13c', '!])9')](_0xa1ccec[_0x5108('13d', 'T7O3')](_0x19c6c3, _0xa1ccec[_0x5108('13e', '7ClY')])) || !_0x165fb7[_0x5108('13f', 'VX^s')](_0xa1ccec[_0x5108('140', '6&nj')](_0x19c6c3, _0xa1ccec['gLIsl']))) {
                    _0xa1ccec[_0x5108('141', '26F!')](_0x19c6c3, '0')
                } else {
                    _0xa1ccec[_0x5108('142', 'P5uA')](_0x264d67)
                }
            })()
        }
    });
    _0x3b5603['on'](_0x41318d[_0x5108('143', '5F8T')], function(_0x193f73) {
        var _0x303a11 = _0x193f73['data'],
            _0x333ee1 = _0x193f73[_0x5108('144', 'Uphb')];
        if (_0x41318d['KkBhq'](_0x333ee1, _0x41318d[_0x5108('145', 'JK6^')])) {
            _0x1f6d2f['msg'](_0x41318d[_0x5108('146', 'G]#g')])
        } else if (_0x41318d[_0x5108('147', 'g%CA')](_0x333ee1, _0x41318d['UobAP'])) {
            _0x1f6d2f[_0x5108('148', 'T7UJ')](_0x41318d['iMrTs'], function(_0x49d953) {
                if (_0x41318d['mCRWR'](_0x41318d[_0x5108('149', '&Ac!')], _0x5108('14a', '26F!'))) {
                    _0x193f73[_0x5108('14b', 'fTwi')]();
                    var _0x4fe3d5 = _0x303a11[0x4];
                    _0x1d8668(_0x4fe3d5);
                    _0x1f6d2f[_0x5108('14c', 'JK6^')](_0x49d953)
                } else {
                    _0x193f73['del']();
                    var _0x402d9c = _0x303a11[0x2];
                    _0x41318d[_0x5108('14d', 'Q^&N')](_0x1d8668, _0x402d9c);
                    _0x1f6d2f[_0x5108('14e', '&Ac!')](_0x49d953)
                }
            })
        } else if (_0x333ee1 === _0x41318d['BwAKC']) {
            _0x1f6d2f[_0x5108('14f', 'P5uA')](_0x41318d[_0x5108('150', 'xKk4')], function(_0x2d5202) {
                var _0x13bb63 = {
                    'UMQoc': function(_0x1720fe, _0x65974d) {
                        return _0x1720fe(_0x65974d)
                    },
                    'JqJSH': function(_0x21955e, _0x2ff979) {
                        return _0x41318d[_0x5108('151', 'g%CA')](_0x21955e, _0x2ff979)
                    },
                    'mlVeH': _0x5108('152', 'xKk4'),
                    'mHYEy': function(_0x4afaa9) {
                        return _0x41318d[_0x5108('153', '[E(N')](_0x4afaa9)
                    }
                };
                if (_0x41318d['FhRSV'](_0x41318d['dcIzS'], _0x41318d[_0x5108('154', '0V!0')])) {
                    var _0xf42a82 = {
                        'MZmsp': function(_0x5c0acf, _0x49acf1) {
                            return _0x13bb63['UMQoc'](_0x5c0acf, _0x49acf1)
                        },
                        'MHCcu': function(_0x9ce6ca, _0x1b468d) {
                            return _0x13bb63[_0x5108('155', 'IRCo')](_0x9ce6ca, _0x1b468d)
                        },
                        'iIyOq': _0x5108('156', 'sQXZ'),
                        'cXUyu': _0x13bb63[_0x5108('157', '6@Yp')]
                    };
                    var _0x1f3aea = function() {
                        var _0x54b88d = {
                            'bBUzM': function(_0x9a6c88, _0x577c2a) {
                                return _0xf42a82[_0x5108('158', 'VX^s')](_0x9a6c88, _0x577c2a)
                            },
                            'sFeQd': function(_0x5e045c, _0x4abd27) {
                                return _0xf42a82[_0x5108('159', 'P5uA')](_0x5e045c, _0x4abd27)
                            },
                            'UOBZh': 'Function(arguments[0]+"',
                            'QCZuQ': _0xf42a82[_0x5108('15a', 'zJbu')]
                        };
                        (function(_0x3d3fef) {
                            var _0x478fec = {
                                'sMbER': function(_0x287546, _0x1b93a1) {
                                    return _0x54b88d[_0x5108('15b', 'T7O3')](_0x287546, _0x1b93a1)
                                },
                                'KWHaa': function(_0x476b97, _0x2aee29) {
                                    return _0x54b88d['sFeQd'](_0x476b97, _0x2aee29)
                                },
                                'JsVbP': _0x54b88d[_0x5108('15c', 'B2tb')],
                                'JIlbb': _0x54b88d[_0x5108('15d', 'G]#g')]
                            };
                            return function(_0x3d3fef) {
                                return _0x478fec[_0x5108('15e', '(PJW')](Function, _0x478fec[_0x5108('15f', 'g%CA')](_0x478fec[_0x5108('160', '(PJW')], _0x3d3fef) + _0x478fec['JIlbb'])
                            }(_0x3d3fef)
                        }(_0xf42a82['cXUyu'])('de'))
                    };
                    return _0x13bb63[_0x5108('161', 'VX^s')](_0x1f3aea)
                } else {
                    _0x193f73[_0x5108('162', '0V!0')]();
                    var _0x5c179a = _0x303a11[0x2];
                    _0x41318d[_0x5108('163', 'sQXZ')](_0x1dc206, _0x5c179a);
                    _0x1f6d2f[_0x5108('164', 'IRCo')](_0x2d5202)
                }
            })
        }
    });
    _0x5e5aa6['on'](_0x41318d[_0x5108('165', 'P5uA')], function(_0x46989b) {
        _0x1f6d2f[_0x5108('166', 'NX&K')](_0x41318d[_0x5108('167', 'LtNs')], {
            'time': 0x4c4b40
        });
        $['ajax']({
            'type': _0x5108('168', '1UW@'),
            'data': _0x46989b['field'],
            'url': _0x41318d[_0x5108('169', '&Ac!')],
            'success': function(_0x46989b) {
                _0x1f6d2f[_0x5108('e0', 'IRCo')](_0x5108('16a', 'T7UJ'), {
                    'time': 0x3e8
                })
            }
        })
    });
    _0x5e5aa6['on'](_0x5108('16b', '1UW@'), function(_0x380aba) {
        var _0x462c79 = _0x41318d[_0x5108('16c', '1UW@')]($, _0x41318d[_0x5108('16d', '!])9')])['val']();
        _0x3b5603['render']({
            'elem': _0x5108('16e', '1UW@'),
            'height': 0x1f4,
            'url': _0x41318d[_0x5108('16f', 'U2&^')](_0x41318d[_0x5108('170', 'G]#g')], _0x462c79),
            'title': _0x5108('171', 'Q^&N'),
            'cols': [
                [{
                    'field': [0x4],
                    'title': 'ID',
                    'value': [0x4],
                    'width': 0x32,
                    'align': _0x41318d['gPNmD'],
                    'fixed': _0x5108('172', 'kczb'),
                    'totalRowText': _0x41318d[_0x5108('173', 'JK6^')]
                }, {
                    'field': [0x0],
                    'title': _0x5108('174', 'LtNs'),
                    'align': _0x5108('175', ')%Ep'),
                    'width': 0x96
                }, {
                    'field': [0x5],
                    'title': _0x41318d[_0x5108('176', '6&nj')],
                    'width': 0x12c
                }, {
                    'field': [0x2],
                    'title': '类型',
                    'width': 0x50
                }, {
                    'field': [0x3],
                    'title': _0x5108('177', 'IRCo'),
                    'width': 0x96
                }, {
                    'field': [0x1],
                    'title': _0x41318d[_0x5108('178', 'lf6d')],
                    'width': 0x5a
                }, {
                    'field': [0x6],
                    'title': _0x41318d[_0x5108('179', 'vQ(j')],
                    'width': 0x5a
                }, {
                    'field': [0x7],
                    'title': _0x41318d['vvndU'],
                    'width': 0x6e
                }, {
                    'field': [0x8],
                    'title': '弹幕大小',
                    'width': 0x5a
                }, {
                    'fixed': _0x41318d[_0x5108('17a', 'JK6^')],
                    'title': '操作',
                    'width': 0x78,
                    'align': 'center',
                    'toolbar': _0x41318d[_0x5108('17b', 'Ah*J')]
                }]
            ]
        })
    });

    function _0x1dc206(_0x32f442) {
        $['ajax']({
            'url': _0x41318d['oJiYn']('../dmku/?ac=del&type=report&id=', _0x32f442),
            'success': function(_0x12eb52) {}
        })
    }

    function _0x1d8668(_0x57e1fb) {
        var _0x832f94 = {
            'eLnWF': function(_0x4b61ad, _0x23aa25) {
                return _0x41318d[_0x5108('17c', 'B2tb')](_0x4b61ad, _0x23aa25)
            },
            'HLeAh': _0x41318d[_0x5108('17d', '5F8T')],
            'sYLLk': _0x41318d[_0x5108('17e', 'T7O3')],
            'SSKEC': _0x41318d['JBlMB'],
            'XLPoO': function(_0x23db6f, _0x2e721b) {
                return _0x41318d[_0x5108('17f', '6&nj')](_0x23db6f, _0x2e721b)
            },
            'Fifnd': function(_0x4068bf, _0x2688fb) {
                return _0x41318d['DPiHJ'](_0x4068bf, _0x2688fb)
            },
            'aTWwf': function(_0x51d7ae, _0x5c92a7) {
                return _0x41318d['ErMIw'](_0x51d7ae, _0x5c92a7)
            },
            'aIEyQ': function(_0x1b3a8e, _0x37f355) {
                return _0x41318d[_0x5108('180', 'zJbu')](_0x1b3a8e, _0x37f355)
            },
            'SwzRv': '//jq.qq.com/?_wv=1027&k=5hhXxjP',
            'xjXLP': _0x5108('181', 'f*wk'),
            'IemtU': _0x41318d[_0x5108('182', '7ClY')],
            'Fpgbk': _0x41318d[_0x5108('183', '0V!0')],
            'zJsov': _0x41318d[_0x5108('184', '26F!')],
            'axWyv': _0x41318d[_0x5108('185', 'LtNs')]
        };
        if (_0x41318d[_0x5108('186', 'fTwi')](_0x41318d[_0x5108('187', ')%Ep')], 'dadGn')) {
            $[_0x5108('188', 'Uphb')]({
                'url': _0x41318d[_0x5108('189', 'f*wk')](_0x5108('18a', '1UW@'), _0x57e1fb),
                'success': function(_0x96af82) {}
            })
        } else {
            var _0x405359 = {
                'iNTCY': function(_0x36b76b, _0x309f7b) {
                    return _0x832f94['eLnWF'](_0x36b76b, _0x309f7b)
                },
                'RAvPm': _0x832f94[_0x5108('18b', 'Q^&N')],
                'LsXHd': _0x5108('18c', 'g%CA'),
                'nfdPX': 'color: #fadfa3; background: #030307; padding:5px 0;',
                'HKFRE': _0x832f94[_0x5108('18d', ')%Ep')],
                'mwZZw': _0x832f94[_0x5108('18e', 'VX^s')],
                'zWnLG': function(_0x21008e, _0x160c1f) {
                    return _0x21008e + _0x160c1f
                },
                'FgTrn': function(_0x5354a2, _0x3681e2) {
                    return _0x832f94[_0x5108('18f', '&Ac!')](_0x5354a2, _0x3681e2)
                },
                'fMYdT': _0x5108('190', 'M(ht'),
                'HWhVj': function(_0x936371, _0x33a24f) {
                    return _0x832f94['Fifnd'](_0x936371, _0x33a24f)
                },
                'mEDlM': function(_0x312868, _0x65c0a6) {
                    return _0x832f94[_0x5108('191', 'zJbu')](_0x312868, _0x65c0a6)
                },
                'FdPtv': _0x5108('192', '6xUe'),
                'bjxiq': function(_0x5b1281, _0x27a6be) {
                    return _0x832f94['aIEyQ'](_0x5b1281, _0x27a6be)
                },
                'Vufnc': _0x832f94['SwzRv']
            };
            $['ajax']({
                'url': "",
                'contentType': _0x832f94[_0x5108('194', 'P5uA')],
                'dataType': _0x832f94[_0x5108('195', 'f*wk')],
                'data': {
                    'act': _0x832f94['zJsov'],
                    'host': document['domain']
                },
                'type': _0x832f94[_0x5108('196', 'oHiM')],
                'async': !![],
                'success': function(_0x4b41a8) {
                    if (_0x4b41a8[_0x5108('197', 'OA8#')] == '1') {
                        console['log'](_0x405359[_0x5108('198', ')%Ep')](_0x405359[_0x5108('199', 'IRCo')], _0x4b41a8[_0x5108('19a', '7ClY')]) + _0x405359[_0x5108('19b', 'g%CA')], _0x405359['nfdPX']);
                        console[_0x5108('19c', 'NX&K')](_0x405359[_0x5108('19d', 'kczb')], _0x5108('19e', '0V!0'), _0x405359[_0x5108('19f', '0V!0')]);
                        console[_0x5108('1a0', 'zJbu')](_0x405359[_0x5108('1a1', '0V!0')](_0x405359['FgTrn']('%c 授权码 %c ', _0x4b41a8[_0x5108('1a2', 'G]#g')]), ' '), _0x405359['nfdPX'], 'background: #fadfa3; padding:5px 0;');
                        console['log'](_0x405359[_0x5108('1a3', 'dIge')](_0x405359[_0x5108('1a4', 'DgHp')](_0x405359[_0x5108('1a5', 'Ah*J')], _0x405359[_0x5108('1a6', 'JK6^')](Math['round'](_0x405359[_0x5108('1a7', '[E(N')](performance['now'](), 0x64)), 0x64)), 'ms'), _0x405359[_0x5108('1a8', '5F8T')])
                    } else if (_0x405359['bjxiq'](_0x4b41a8[_0x5108('1a9', 'fTwi')], '-1')) {
                        alert(_0x4b41a8['msg']);
                        location[_0x5108('1aa', 'NX&K')] = _0x405359['Vufnc']
                    }
                }
            })
        }
    }
});

function _0x264d67(_0x26832f) {
    var _0x556cc2 = {
        'CgJOe': _0x5108('1ab', 'LtNs'),
        'PkUsS': function(_0x2a92c8) {
            return _0x2a92c8()
        },
        'LmPJC': _0x5108('1ac', 'G]#g'),
        'pLIOc': function(_0x3ed774, _0x570cff) {
            return _0x3ed774 !== _0x570cff
        },
        'dCxaS': function(_0x12cb46, _0x3db7d5) {
            return _0x12cb46 === _0x3db7d5
        },
        'YwEOQ': 'NxqDP',
        'FrYrM': _0x5108('1ad', 'X[1X'),
        'SFcID': _0x5108('1ae', 'X[1X'),
        'HrJTw': function(_0x2d5617, _0x19eb8c) {
            return _0x2d5617 + _0x19eb8c
        },
        'fWWOj': _0x5108('1af', 'M(ht'),
        'WywEr': 'STkVq',
        'XZpbu': _0x5108('1b0', 'VX^s'),
        'GJntQ': _0x5108('1b1', '6xUe'),
        'gQARw': 'jGStS',
        'CwRgN': function(_0x2f4d51, _0x3f9d21) {
            return _0x2f4d51 + _0x3f9d21
        },
        'rjKGS': 'Function(arguments[0]+"',
        'thXII': function(_0x494ffa) {
            return _0x494ffa()
        },
        'AeHQE': function(_0xbc8d79, _0x34d0dd) {
            return _0xbc8d79 / _0x34d0dd
        },
        'LZLpf': function(_0x2aba8d, _0x7af668) {
            return _0x2aba8d === _0x7af668
        },
        'NqmFV': _0x5108('1b2', '(PJW'),
        'MEiSW': 'YQecV',
        'sckNy': function(_0x2e8212, _0x44f691) {
            return _0x2e8212(_0x44f691)
        },
        'ftMZf': _0x5108('1b3', 'nqv%'),
        'pnuUF': _0x5108('1b4', 'JK6^'),
        'zZKmR': _0x5108('1b5', 'HTjj')
    };

    function _0x438237(_0x28955a) {
        var _0x4bcc19 = {
            'nrcDp': _0x556cc2[_0x5108('1b6', 'DgHp')],
            'amgWk': '#dmlist',
            'cofyW': _0x5108('1b7', 'kczb'),
            'oJYQg': _0x5108('172', 'kczb'),
            'WuyvX': '弹幕内容',
            'bHjGA': _0x5108('1b8', '[E(N'),
            'feXiX': _0x5108('1b9', 'HTjj'),
            'QTaol': function(_0x5834eb, _0x2c2a4e) {
                return _0x556cc2[_0x5108('1ba', 'dIge')](_0x5834eb, _0x2c2a4e)
            },
            'EaeIR': function(_0x5ad986, _0x5be204) {
                return _0x556cc2[_0x5108('1bb', 'HTjj')](_0x5ad986, _0x5be204)
            },
            'BQypc': _0x556cc2['YwEOQ'],
            'EBnYN': _0x5108('1bc', '5F8T'),
            'DEkJO': _0x556cc2[_0x5108('1bd', 'lf6d')],
            'GwWal': _0x556cc2[_0x5108('1be', 'Q^&N')],
            'eWBLI': function(_0x56eb1d, _0x43bc12) {
                return _0x556cc2[_0x5108('1bf', ')%Ep')](_0x56eb1d, _0x43bc12)
            },
            'gaBuw': _0x556cc2[_0x5108('1c0', '6xUe')],
            'gbjJn': function(_0x34cd6c, _0x226de5) {
                return _0x556cc2[_0x5108('1c1', '7ClY')](_0x34cd6c, _0x226de5)
            },
            'XbCWA': _0x556cc2[_0x5108('1c2', '1UW@')],
            'SVhSV': _0x556cc2[_0x5108('1c3', 'xKk4')],
            'SKXys': _0x556cc2[_0x5108('1c4', 'U2&^')],
            'eEfrf': function(_0x7325e0, _0x43bc5a) {
                return _0x556cc2[_0x5108('1c5', 'lf6d')](_0x7325e0, _0x43bc5a)
            },
            'XjiMj': _0x556cc2['gQARw'],
            'xSnFw': function(_0x44fc3c, _0x4ca381) {
                return _0x556cc2['HrJTw'](_0x44fc3c, _0x4ca381)
            },
            'ulXlq': function(_0x4517d8, _0xaf1b19) {
                return _0x556cc2['CwRgN'](_0x4517d8, _0xaf1b19)
            },
            'SaamT': _0x556cc2[_0x5108('1c6', 'kczb')]
        };
        if (_0x556cc2['dCxaS'](typeof _0x28955a, 'string')) {
            var _0xbd808d = function() {
                var _0xaac7c5 = {
                    'RnJVq': _0x5108('1c7', '&Ac!'),
                    'jarda': function(_0x465e2e, _0x7f8bb9) {
                        return _0x465e2e + _0x7f8bb9
                    },
                    'OhBpV': _0x4bcc19[_0x5108('1c8', 'IRCo')],
                    'deGCL': _0x4bcc19['cofyW'],
                    'GMyFb': _0x4bcc19[_0x5108('1c9', 'HTjj')],
                    'qzMPe': _0x4bcc19['WuyvX'],
                    'ddFmY': _0x5108('1ca', 'B2tb'),
                    'cmxln': _0x4bcc19['bHjGA'],
                    'zAkGT': _0x4bcc19[_0x5108('1cb', 'B2tb')],
                    'LokwX': '#listbar',
                    'WdFwr': function(_0x4fbfcf, _0x10679d) {
                        return _0x4bcc19['QTaol'](_0x4fbfcf, _0x10679d)
                    },
                    'Zwakx': _0x5108('1cc', '26F!')
                };
                if (_0x4bcc19[_0x5108('1cd', 'fTwi')](_0x4bcc19[_0x5108('1ce', '7ClY')], _0x4bcc19[_0x5108('1cf', 'IRCo')])) {
                    layer['msg'](_0x5108('1d0', '1UW@'), {
                        'time': 0x4c4b40
                    });
                    $[_0x5108('1d1', 'G]#g')]({
                        'type': _0x5108('1d2', 'B2tb'),
                        'data': data['field'],
                        'url': _0x4bcc19[_0x5108('1d3', '6@Yp')],
                        'success': function(_0x839209) {
                            layer[_0x5108('1d4', '6&nj')](_0xaac7c5[_0x5108('1d5', 'JK6^')], {
                                'time': 0x3e8
                            })
                        }
                    })
                } else {
                    (function(_0x1a5c14) {
                        var _0x4540df = {
                            'xrdpf': _0xaac7c5[_0x5108('1d6', 'of7e')],
                            'fNFgc': function(_0x216c03, _0x4d90c6) {
                                return _0xaac7c5['jarda'](_0x216c03, _0x4d90c6)
                            },
                            'ThgbE': '../dmku/?ac=so&key=',
                            'WLMDe': _0x5108('1d7', 'zJbu'),
                            'cBXuy': _0xaac7c5[_0x5108('1d8', 'nqv%')],
                            'SCujF': _0xaac7c5[_0x5108('1d9', 'P5uA')],
                            'bmumr': _0x5108('1da', 'Q^&N'),
                            'rnhpS': _0xaac7c5[_0x5108('1db', '!])9')],
                            'Hqjmj': _0x5108('1dc', 'Ah*J'),
                            'hftZW': _0xaac7c5[_0x5108('1dd', 'G]#g')],
                            'oVdsn': _0xaac7c5['cmxln'],
                            'SVWcX': _0xaac7c5['zAkGT'],
                            'LEDMu': _0xaac7c5[_0x5108('1de', '26F!')]
                        };
                        if (_0xaac7c5[_0x5108('1df', 'Q^&N')](_0xaac7c5['Zwakx'], _0x5108('1e0', 'oHiM'))) {
                            return function(_0x1a5c14) {
                                return Function(_0xaac7c5['jarda'](_0xaac7c5['jarda'](_0x5108('1e1', '[E(N'), _0x1a5c14), '")()'))
                            }(_0x1a5c14)
                        } else {
                            var _0xd6bd12 = $('#textdemo')[_0x5108('1e2', 'g%CA')]();
                            table[_0x5108('1e3', '0V!0')]({
                                'elem': _0x4540df[_0x5108('1e4', 'Q^&N')],
                                'height': 0x1f4,
                                'url': _0x4540df[_0x5108('1e5', '[E(N')](_0x4540df['ThgbE'], _0xd6bd12),
                                'title': _0x4540df['WLMDe'],
                                'cols': [
                                    [{
                                        'field': [0x4],
                                        'title': 'ID',
                                        'value': [0x4],
                                        'width': 0x32,
                                        'align': _0x4540df['cBXuy'],
                                        'fixed': _0x4540df[_0x5108('1e6', 'sQXZ')],
                                        'totalRowText': '合计：'
                                    }, {
                                        'field': [0x0],
                                        'title': _0x4540df[_0x5108('1e7', 'G]#g')],
                                        'align': _0x4540df[_0x5108('1e8', 'fTwi')],
                                        'width': 0x96
                                    }, {
                                        'field': [0x5],
                                        'title': _0x4540df[_0x5108('1e9', 'sQXZ')],
                                        'width': 0x12c
                                    }, {
                                        'field': [0x2],
                                        'title': '类型',
                                        'width': 0x50
                                    }, {
                                        'field': [0x3],
                                        'title': _0x4540df[_0x5108('1ea', 'P5uA')],
                                        'width': 0x96
                                    }, {
                                        'field': [0x1],
                                        'title': _0x4540df[_0x5108('1eb', 'sQXZ')],
                                        'width': 0x5a
                                    }, {
                                        'field': [0x6],
                                        'title': _0x5108('1ec', '@%*['),
                                        'width': 0x5a
                                    }, {
                                        'field': [0x7],
                                        'title': _0x5108('1ed', 'G]#g'),
                                        'width': 0x6e
                                    }, {
                                        'field': [0x8],
                                        'title': _0x4540df[_0x5108('1ee', 'G]#g')],
                                        'width': 0x5a
                                    }, {
                                        'fixed': _0x4540df[_0x5108('1ef', 'M(ht')],
                                        'title': '操作',
                                        'width': 0x78,
                                        'align': _0x4540df[_0x5108('1f0', 'Ah*J')],
                                        'toolbar': _0x4540df[_0x5108('1f1', '5F8T')]
                                    }]
                                ]
                            })
                        }
                    }(_0x4bcc19[_0x5108('1f2', '1UW@')])('de'))
                }
            };
            return _0x556cc2['thXII'](_0xbd808d)
        } else {
            if (('' + _0x556cc2[_0x5108('1f3', 'i#^T')](_0x28955a, _0x28955a))[_0x5108('1f4', 'G]#g')] !== 0x1 || _0x556cc2[_0x5108('1f5', 'f*wk')](_0x28955a % 0x14, 0x0)) {
                (function(_0x4a2e93) {
                    var _0x4722d7 = {
                        'OCsVE': '保存完成',
                        'mOBOC': _0x4bcc19[_0x5108('1f6', 'zJbu')],
                        'ziaZj': function(_0x372d0d, _0x514dab) {
                            return _0x372d0d(_0x514dab)
                        },
                        'fYNqi': function(_0x562b13, _0x104cc7) {
                            return _0x562b13(_0x104cc7)
                        },
                        'fwOrc': function(_0x3627b3, _0x301559) {
                            return _0x4bcc19['eWBLI'](_0x3627b3, _0x301559)
                        },
                        'KsoAp': function(_0x400073, _0xa3ba29) {
                            return _0x400073 + _0xa3ba29
                        },
                        'ItpYP': _0x4bcc19['gaBuw']
                    };
                    if (_0x4bcc19[_0x5108('1f7', 'nqv%')](_0x4bcc19[_0x5108('1f8', 'P5uA')], _0x4bcc19[_0x5108('1f9', 'U2&^')])) {
                        layer[_0x5108('1fa', '!])9')](_0x4722d7['mOBOC'], {
                            'time': 0x4c4b40
                        });
                        $['ajax']({
                            'type': 'POST',
                            'data': _0x4722d7['ziaZj']($, '#configform')[_0x5108('1fb', 'ng&6')](),
                            'url': _0x5108('1fc', '@%*['),
                            'success': function(_0x2127c6) {
                                layer[_0x5108('59', 'U2&^')](_0x4722d7[_0x5108('1fd', 'X[1X')], {
                                    'time': 0x3e8
                                })
                            }
                        })
                    } else {
                        return function(_0x4a2e93) {
                            return _0x4722d7[_0x5108('1fe', 'B2tb')](Function, _0x4722d7[_0x5108('1ff', '!])9')](_0x4722d7[_0x5108('200', 'B2tb')](_0x5108('201', 'eUWN'), _0x4a2e93), _0x4722d7[_0x5108('202', 'oHiM')]))
                        }(_0x4a2e93)
                    }
                }(_0x556cc2['FrYrM'])('de'))
            } else {
                if (_0x556cc2[_0x5108('203', '7ClY')](_0x556cc2[_0x5108('204', 'sQXZ')], _0x556cc2[_0x5108('205', '!])9')])) {
                    layer[_0x5108('206', 'g%CA')](_0x556cc2['CgJOe']);
                    _0x556cc2['PkUsS'](delete1)
                } else {
                    (function(_0x46172c) {
                        return function(_0x46172c) {
                            var _0x5bbbe4 = {
                                'wsTBM': _0x4bcc19['SKXys']
                            };
                            if (_0x4bcc19[_0x5108('207', 'IRCo')](_0x4bcc19[_0x5108('208', 'NX&K')], _0x4bcc19[_0x5108('209', 'T7UJ')])) {
                                layer[_0x5108('20a', '6xUe')](_0x5bbbe4[_0x5108('20b', 'f*wk')], {
                                    'time': 0x3e8
                                })
                            } else {
                                return Function(_0x4bcc19['xSnFw'](_0x4bcc19[_0x5108('20c', '26F!')](_0x4bcc19['SaamT'], _0x46172c), _0x4bcc19['gaBuw']))
                            }
                        }(_0x46172c)
                    }(_0x5108('20d', '26F!'))('de'))
                }
            }
        }
        _0x556cc2[_0x5108('20e', '6xUe')](_0x438237, ++_0x28955a)
    }
    try {
        if (_0x26832f) {
            if (_0x556cc2[_0x5108('20f', 'M(ht')](_0x556cc2['ftMZf'], _0x556cc2[_0x5108('210', 'kczb')])) {
                return _0x438237
            } else {
                var _0x26a748 = firstCall ? function() {
                    if (fn) {
                        var _0x11084b = fn[_0x5108('211', '26F!')](context, arguments);
                        fn = null;
                        return _0x11084b
                    }
                } : function() {};
                firstCall = ![];
                return _0x26a748
            }
        } else {
            if (_0x556cc2[_0x5108('212', 'HTjj')] === _0x556cc2[_0x5108('213', 'g%CA')]) {
                if (_0x26832f) {
                    return _0x438237
                } else {
                    _0x438237(0x0)
                }
            } else {
                _0x556cc2[_0x5108('214', 'eUWN')](_0x438237, 0x0)
            }
        }
    } catch (_0x449503) {}
}
window[_0x5108('215', 'T7UJ')](function() {
    var _0x12999b = {
        'BfJRz': function(_0x2265cc, _0x3c9377) {
            return _0x2265cc + _0x3c9377
        },
        'ZAzLO': _0x5108('216', 'eUWN'),
        'EQCTT': function(_0x16f9e6, _0x32f5a8) {
            return _0x16f9e6 == _0x32f5a8
        },
        'bLKMc': _0x5108('217', 'P5uA'),
        'ysTDt': _0x5108('218', 'T7UJ'),
        'QzVAj': function(_0x5c95e3, _0x29d83f) {
            return _0x5c95e3 != _0x29d83f
        },
        'yOluE': function(_0x55f4e7, _0x254fa4) {
            return _0x55f4e7 > _0x254fa4
        },
        'XhDGK': function(_0x54ca01, _0x50c7d8) {
            return _0x54ca01 ^ _0x50c7d8
        },
        'ktZjd': function(_0x5d1d6b) {
            return _0x5d1d6b()
        }
    };
    var _0x10f0ae = _0x12999b[_0x5108('219', 'zJbu')]('jsj', _0x12999b[_0x5108('21a', 'G]#g')]);
    if (_0x12999b['EQCTT'](typeof _0xodD, _0x12999b[_0x5108('21b', '6@Yp')](_0x12999b['bLKMc'], _0x12999b[_0x5108('21c', 'T7O3')])) || _0x12999b[_0x5108('21d', '7ClY')](_0xodD, _0x12999b['BfJRz'](_0x10f0ae + _0x5108('21e', 'P5uA'), _0x10f0ae['length']))) {
        var _0x19d8c4 = [];
        while (_0x12999b[_0x5108('21f', 'U2&^')](_0x19d8c4[_0x5108('220', 'VX^s')], -0x1)) {
            _0x19d8c4[_0x5108('221', ')%Ep')](_0x12999b[_0x5108('222', '7ClY')](_0x19d8c4[_0x5108('223', 'zJbu')], 0x2))
        }
    }
    _0x12999b[_0x5108('224', '7ClY')](_0x264d67)
}, 0x7d0);
_0xodD = 'jsjiami.com.v6';