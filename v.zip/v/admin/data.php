<?php
 $yzm =  array (
  'danmuon' => 'on',
  'next' => 'on',
  'color' => '#00a1d6',
  'logo' => 'aiblog/img/logo.png',
  'trytime' => '3',
  'yjbt' => '小刀影院',
  'yjurl' => 'https://tv.52meme.top',
  'waittime' => '5',
  'sendtime' => '3',
  'av' => '',
  'mylink' => 'https://bfq.52meme.top/v/',
  'api' => 'https://bfq.52meme.top/v/dmku/',
  'dmrule' => 'https://tv.52meme.top/ggw/dmly.html',
  'pbgjz' => '万岁,尼玛,卧槽,王八蛋,日你,干你,影视,影院,草,操,艹,妈,逼,滚,网址,网站,导航,支付宝,微信,QQ,群,加,企,cn,com,top,cc,me,net,qq,wx,+,tv',
  'ads' => 
  array (
    'state' => 'on',
    'set' => 
    array (
      'state' => '2',
      'group' => 'null',
      'pic' => 
      array (
        'time' => '3',
        'img' => 'https://tv.52meme.top/addons/dplayer/img/U36c68.jpg',
        'link' => 'https://tv.52meme.top',
      ),
      'vod' => 
      array (
        'url' => '/ad.mp4',
        'link' => 'https://tv.52meme.top',
      ),
    ),
    'pause' => 
    array (
      'state' => 'on',
      'pic' => 'https://tv.52meme.top/addons/dplayer/img/U36c68.jpg',
      'link' => 'https://tv.52meme.top',
    ),
  ),
  'adminpass' => 'Sqh19980220',
);
?>