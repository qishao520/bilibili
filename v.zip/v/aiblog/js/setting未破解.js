var _0xod0 = 'jsjiami.com.v6',
    _0xc5f1 = [_0xod0, 'w71swr3CrjrCj8Kv', 'wpDDqcO9w5AH', 'WMOyd8OkwpPDtsKP', 'DX3Ci8KXwoE=', 'w4gjw4M3HA==', 'PcO6Z8OCbR8W', 'w5LDk3LCgcKH', 'wqwQLcKOwoc=', 'QSDDoMK4JhHCg8KvwoIWw63Dt0zCpQ==', 'DsKowoULwpM=', 'wrLCnCo=', 'QMOEXsOqwpI=', 'b1tFw6o=', 'W8OFUE8=', 'w6nDjA0Pwr8=', 'K1TDpsKeFD4=', 'YsOPwqdMZQ==', 'w73DpzUYwqwxw7Q=', 'w7EeWcOTDQ==', 'w4vCvcKTRMKI', 'wrpSw4k=', 'H8KrfsKfwrg=', 'wq/DkcO0w7wH', 'K8OKKzh8', 'JAALw6/CqA==', 'P1HCt3XDssOp', 'w5Fhw6nDiDI=', 'woZnwq8=', 'w6HDhkXCmcKO', 'wpICCsKpwrU=', 'wo4yCsKCwpkU', 'woQ2AMKAwqQS', '6KaP6L685YWU5b6h5bmx5YWe5a2K5Zas5ZWN77yD', 'b8OeKFvClg==', 'w6/CqMKh', 'wrhJw7XDsQ0=', 'w7sPbsOhNA==', 'wqzDlsO9w7IJwrzCt8Ol', 'wr1+LsOeLw==', 'w7zDpy08wos=', 'B8O9TsODbA==', 'JhETw6DCgw==', 'EMKgf8Kywq4=', 'CsOiHidU', 'wrzDnMO9w4kNwrnCu8O5', 'w73DrsKN', 'w6/DrsKPwq3DjcKUw4o=', 'wphxwqYZ', 'wo5yWg==', 'w49vw4HCucOnTQ==', 'A8KnV8Kawq1+dQ==', 'LB3CjMOZw4g=', 'V8KTwoTClsOO', 'w4HCjMKeRMKn', 'TsOjZ04k', 'w60Hw748IsODKg==', 'w4xOwqnCiDI=', 'X8O7FiNCfhJ6wpwhHArDuw==', 'K8ORwqFKYcOIdcOew6cr', 'eDg+wrzCnMKVU0zDncK0Pw==', 'w4V1wqEfwqPCn8KrS1MzBhrChsKrw7MpwqTCsjfDq3jDscOHw796A8KKwq5BaDsvU3nDgVzDpEbDlQ==', 'Qk/CiBMHwqg3wp4WFcOIPR3CscOlw7olw4LCocKVKRDCi3AkO8O6', 'CEfCl18Kwq4yw58OE8KRPRrCtcOmw7hmw5jDucKaJA3Dgw==', '6L2b6Kam6K2K', 'w7vCoVY=', 'wqgtwrzDtQ==', 'w55hQXV/wrVVMcKPdw==', 'w6nCpQHCgMOTUMKvP8ORwo4dNsOJw4sewp8R', 'w6UEWcOR', 'wqTCqAHCgcOU', 'w5FecsOiBQ==', 'dj3Dm8KRMg==', 'w7x4wpXCuBU=', 'wq5Kw4TDqA==', 'wpvDh8Olw6YH', 'ScOuwrx7Vw==', 'w4VUw4XDphw=', 'w69Xw5rDpxs=', 'w7BNwpLCrRQ=', 'KSkbw4/CjA==', 'SFTCp0w2', 'bUBVw70=', 'w5kaQDjDmMOPeg==', 'w7TDtDcI', 'ZUASY2Q=', 'G07CjGrDhw==', 'ccOYwrBN', 'wrJkw49tEQ==', 'w7oKQT3DnA==', 'w5HDh0Qcw4M=', 'wpTDk3jCiCVqK8KJwqMww6DCgsKyw6zDqFzCqMOTa2YrY8K+wplUw6bDjU1twrM=', 'worCiWTChyA1', 'w63Dm0/CnMKtE8O6w7nCjyc=', 'QMKkFisFJwxMw4w0AA3DshFSTQ==', 'wqbCujYEw6JSw6Auw6XChXJfVsO/F8Kj55ef5ouB7724', 'w503Z0HlnaLlnoHvvKY=', 'wpcEBA==', 'wpcuJQ==', 'wrFAEQ==', 'DUjCkMKGwos=', 'w4FMwrjCjS8=', 'w64bLMOHNsOr', 'V2pgw71W', 'wqJjC8O5Jg==', 'DsOuFy1Nfg==', 'w5UFw4I5GA==', 'wptiw6fDlBw=', 'esKwwqPChMOhwr1iCA==', 'wps2C8KM', 'RsO6C03CgQ==', 'wp7CusOFw6Q=', 'w45lwqPCpgk=', 'E3XDq8KvMw==', 'FB9MRsO7wosswqfCgVh3O3TCg8KMe3XCgMKrZmbDicOxwpYew788IGchwp7CvBzDrBBGw5DDgMOiwrbDsQUpwr/CuEQ=', 'TBZXRcK3wo0=', 'BBjlv4fluajnpZrkuKt1w45WE8ObYl3CuMOhw6l1', 'wpTClTrCjMOJ', 'w4xLw4bCk8Oz', 'w7QSw64zOg==', 'wojCtx/CtMOu', 'w4keViE=', 'w77Dh1jCg8KiEsOD', 'Yk3CrEwh', 'MMKzwqbChcOhwrtmTsKeEMKNw4TCp8O7w6o1B8KOw5sefcKAwqzCpjgwdMOeIzTDocKow5TDs8OJw4cBYTLCgcOuGB/DgCDDmkVRwrzCgkNewro4CB/DpsKAQlBcw57Cq8KzwpjDsA==', 'wrnCmzR4', 'O3XColTDuw==', 'VkTCmVcc', 'w5DDmcK1w5HDuBs=', 'w4TCnsKhd8Km', 'w4AsE8OPMA==', 'w5jDgUUFw60=', 'LsKmacKmwoo=', 'w4zCpsKHRMKj', 'woJKw5PDtDY=', 'XMKawqXCqcOm', 'wpMaRzfDgcOLaMOzSFnCglRG', 'w584w5E7JA==', '5oCO5oeG5Yue5bCx', '6LWk5Y+26K+i6aq9', 'C1LCl0HDlQ==', '5Z2E5Z+65biX5ZKo', 'IMKzdsKRwpA=', 'PMOhWsOUZg==', '5LuG5oi+5byC5bq3', '5LmF6Lml5paK5YWt', '5L6d54uU6Zq156ex', 'SxRLVsKywpot', 'wrkEL8Khwoc=', 'AiJ0O8Ku', '6LyM5rC66L6E56aV', '6IqN5oCL5L+/5L2B', 'w6p7w4jCiMOT', '6LeY5Y2Y6KyR6amc', 'VxzDm8KQDg==', 'e8OeNEXChg==', 'cU4PYlbCmA==', 'wpDCliNAew==', 'JMO7cMOTSiI=', 'wr7Cvwh4Rg==', 'esKzwqHCisO4', 'VirDp8KJFQY=', '5LqS6LuQ5pSe5YeL', 'w4bDjynChg0=', 'w6RJw7zDpiY=', 'woLDnH7CtsOX', 'ZcO4H3zCgA==', 'DMKjQMKTwrc=', 'DMOkCTZkaQ==', 'wrfDkB3CksKgBsOdw6PDn2DCo8OoZiLDnsOdCcOvwpbDlcKCwqrCoibDtsKfw41vbgc=', 'WsO3w5USwp9o', 'wqpDWsOPQ2heKS0DX1huwq7Dv8Ku55Wf5oqE77+1', 'wrQiwpDCm+WdsuWegO+/kw==', 'w6PCnMO/w79Dw6nCtsOpwqTCsMOSw5Qhwo8Yw4HCr8KaFsOnw4HDojvCucKiwoIpwqvCtcOjwq7Dt3PDuk4sQVjDn8Oow6XCiMK8w7DDhcKWw4PDrsOhwoHDh8Kn', 'w6c5wqA=', 'wpvCkMO8', 'w5jDp8KTwqjku5jmi6bDgsKLwr5MUz/CmXvDvw==', 'woE4D8KmwpI=', 'BsOBwqlaw7I=', 'w7vDpSoIwrIK', 'w4zDk8Kow4LDkwE=', 'w53DucKGwrDDvw==', 'L0nDrMKZLik=', 'w4tqw6bDmg0=', 'wqdzQFkZ', 'O0fDscKABA==', 'bsK9wrzCk8OSwqY=', 'AMOKwol6w5I=', 'fkBCw6x7wqk=', 'wq7DkW3CkcOy', 'w5ttw4HCqMOWSw==', 'w73DsC4=', 'wo13w4HCucO7BA==', 'wrzDoTMZwrALwrE=', 'dcOMNUY=', 'JWHCocKM', 'OsO6ZsOsbw==', 'BcKlQ8KqwqA=', 'wrfCswXCicOv', 'w7Frwo7CmgU=', 'w5/Dv0JcHg==', 'M8KNwooJwow=', 'w5nDnkJyIA==', 'RzXDvQ==', 'R8KowopDwoQzw7wAZ8OkJhEIwpBJ', 'wrrDr3jCmsOn', 'w7/DsU9EHQ==', 'Dg9ASMKvw5U=', 'w5lqb8K9cg==', 'OcOnZA==', 'w78YD8OXDg==', 'wrLDgMO0', 'wrJNwoonwoo=', 'bUBew7NNwr4=', 'w5HClMKXb8Kh', 'w5LDlsKjwprDqQ==', 'wqNCw4TDgjE=', 'e8K4wrnChcOF', 'azXDjMOuwr9UwopJcw==', 'w5/Dk8K0w53DpRY=', 'wpFyQHYmwqk=', 'dhfDh8KOJA==', 'w74ww6ozOA==', 'Nh9DH8Kx', 'OCbCkMO5w6RN', 'MifCm8O3w7Vnw5g=', 'w5c5D8ObFg==', 'w5zDg2dbNg==', 'w7dCw6fDric=', 'wodxwqYawrvCmA==', 'dsOIwqpKYcKXb8OYw68=', 'GztdEcKX', 'Q8K9MA/DjCI=', 'wp54QXo7wqQ=', 'CsOqFg==', 'PcKjwqccwpA=', 'M8OtMjpV', 'w5zDjEUIw7vDkA7ClSN2Kg==', 'w53CuMKkY8Ko', 'eE5d', 'wozDo0rCmMOs', 'LkPCs2PDog==', 'LVLDksKMMg==', 'RFHCm1kV', 'NixQDMKv', 'wrTCtjxldw==', 'w7wDX8OI', 'VEPCjlEHwqIw', 'SMOtw5g=', '6KW66aCt5bSp5YWw5aaL5bGC57qx772u5Y2E5bO25LmA5oKk5pCU5peD', '6K2x5Yqd5Y2W6YG+5pat5oao5LiG5Ya25ayH77yv6KS26Iy35oO155i35byZ5bmg5YaY5a2G', 'w7sCMcOHLcO/w6h1ccOE', 'UCzDsMKYJQ==', 'w7d3wqvCuSfCrsK9H0hwDA==', 'w6fDucK1wqnDvg==', 'LSDCm8O3w6I=', 'L1vCuFjDocOtVsKA', 'SsKnMhQ=', 'TsK9Kw3DhiI=', 'I8KyeMKGwpM=', 'MTA5w6TClA==', 'cU0dbw==', 'w4oaw7QZKA==', 'wqJXwrAXwpU=', 'woxdwr87wqg=', 'w4xww6k=', 'RmU/YmE=', 'w7jDkUnCssKjCMOFw7nChw==', 'wrJjw65ZEQ==', 'VcKgMw==', 'RsKxXsKbwqdtNsOQwr4Lw5FFw7k=', 'w6UcU8ODGXlBNHkeWEsvwqTCssOpGQ==', 'w4vDmzHCiCI=', 'wobDhCjCjixvdcKJw6pmw63CjcK7wqHCs1bCtMKca2A/OsOvw5xUw7vDiUY3wrxLXcO+fMK+XQnCmDVl', 'PjZ4BcKJ', 'f0paw5px', 'w6bCqMKtQQ==', 'FHjChk7Dlg==', 'wpxHCMO4JQ==', 'w5HDom87w5M=', 'w7RkYcK2eA==', 'VsKowoAcwpo5w6tCZsO1dAYIwpoTwqYvwokIw6VLe8Kew7xOwrxGVX3DjFYtwoMuXsOtF8KGOcO/w5o+esOfw4TCpkU+w5I=', 'w4zDikJOMQ==', 'wqjDklfCm8Ot', 'EMOEwoBww4vDosK8EsOcw5hx', 'blDCp0UO', 'QsKRNw3Dlw==', 'w59nw4rCqA==', 'woV7wrwUwqzClQ==', 'UEzCiVc0', 'wqrDg8OYw7Qk', 'VsK7OwHDig==', 'wrrDncO3', 'SsODTlM=', 'dcORwqlAcMKX', 'NcOhd8OI', 'w63DgCpgWMOOVMK/', 'Si5GW8Ky', 'Jj05w4LCl8KRVBk=', 'wpROTV0X', 'YsOYwrx8ecKAa8OTw6Yowp8fwrB7', 'fcK9wqPCiMO/', 'w7vDnV4=', 'GXHCmE/DuA==', 'OcKaeMK1woo=', 'w7LCgzZ1RcOLX8OmS8K5NC9LJnIGc0hcQyTDlntgb3TCpMK2', 'w64eezbDvg==', 'CcKmSsK9wq5oaMOQ', 'QiDDsg==', 'wprDnxYTwqfDiX7ChXd5aA==', 'JxxYGMKMwozDploYJQ==', 'w7/CjjB2TcONVsKsBcK0NSNCLXcZZlYRFH/Cn3djbnbCssKow5xRasOYNA4Nw4bCh8OFRcKaw6PCkcKnPAAgXD7CvlMgEMK0wqvDm1rCrcKjwrcjbjlrw6XDjh7CtMO9wqAnQkFFI8OsVgrDlDvCry9hYsOD', 'wp94Smg=', 'wpbCkxjChcO4', 'NCkxw6jCjw==', 'w4/DhlYqw7vDkCDCnCxxGzbChsK6', 'w5vDkSoBwr0Xw6k1', 'w5/Dk8K3w5nDvg==', 'KzY6w64=', 'wpx6HcOhKg==', 'Xh1iUcKs', 'w51rw5bCucOm', 'w4h3w4DCrsOsVxw/wpzDp8Os', 'wp46CsKCwr8=', 'TMOZWEsYKMKww7Y=', 'w7INWMOLCHldJms=', 'XsOVZ8Obwoc=', 'w5lnacKgUg==', 'w4JNTsOmJGc=', 'dcORwqlA', 'S8KDasKKwqt5', 'wrfDumVbCMOVw67DlFU=', 'w7IJZRDDhQ==', 'fEpcw7dSwr4=', 'w6LDlS3CgwY=', 'OsK4d8KxwrU=', 'wp5ja8K6e007JyBPw7LDow==', 'w7jDp8KOwrc=', 'w4BEQsOwN3A=', 'QijDvcKZ', 'wpDDuHrChsOj', 'L1vCumjDow==', 'wpF4SX4=', 'w4p3w4bCsw==', 'w7ccXw==', 'w43Dm1Ilw4E=', 'w4gISyc=', 'w4dtw5PCuA==', 'w7jCocK0TMKBw58=', 'JX7CtMKb', 'wo9JQMK0Nm8=', 'AMOGwo5z', 'wqDCoRzCp8OTWsKld8OTwpMsO8Ktw4Y=', 'KTAJw67CrA==', 'wos8AsKIwqI=', 'w41sw6nDjQ==', 'CMKgwoo=', 'wpnDq1I=', 'w5NtwpzCmxs=', 'EcOYwoJl', 'Z8OlC3rCnA==', 'wokjBw==', 'w6xowrHCpQk=', 'RBREVA==', '6KyV572s5ay+5ouM776F5bC/5Z2A5Ymc5pWF5oqc5LqC5Lm36Zuk55aS5peZ', 'wplTWXkb', 'B0fDj8KEHg==', 'Sk/CkFY=', 'w7LCrh1gSMOS', 'fQbDq8KMAzx1w61Ww7pfM0LDo8KHwrR3IOacoOefvOiun+aAggbCilvDuQ==', 'w7HDuSLCvRo=', 'QcK2DzzDqQ==', 'Mz3CksO+', 'wotmHcO4Kg==', 'bxQVFMKdw4HCoFcFLsO6MAMiFsKQPxAE', 'QDpyWsKJ', 'cSLDucK2Lg==', 'RSnDvcKeIQ==', 'wpvDlcO4w7of', 'w6fDhsKwwpfDpw==', 'wrxcwroEwqo=', 'IUfCsQ==', 'cMOMDmzChQ==', 'A8OOwpNSw4vDosKSG8OTw59AATgK', 'wq80O8Kywog=', 'wo/CosOQw6/CgzE=', 'wok3HsKLwrED', 'JsO8woxNfMKV', 'w4TDuhvCi8OAw7xbI8KMwoNjw6YAwqvCnjLDpARH', 'LA9Fw7lWwrzClsKSw7IgPiLDpDjChMObw5ww5buT5ZCww6TDrkUBw4bCsMOrw5/CosKJw5nDhRsGwp9SVA==', 'ZgkFAcOPwoDCtkdfPMKgbhE=', 'D8O7FitP', 'w7siXsOJHg==', 'BDFvNMKR', 'wojDt8OJw58V', 'Biovw6vCiQ==', 'wo5iw6zDijI=', 'wrNEOcKcZMKgw60qOcOIwoLCicKsbVg3w6zDoQ==', 'wpFOwpgcwrY=', 'fsOoFXHCmA==', 'w6giTQXDqQ==', 'wpZhw4tSJQ==', 'w6LDocKPwqXDnsK3w6sDKQ==', 'w6Y+H8OyKQ==', 'OUbCug==', 'wpvDklrCmMOX', 'U8OdLmfCtg==', 'GsKnQ8KRwrRs', 'w7PDuzQIwq4mw5gKwok=', 'NBBBOMKVwpnDr14CNMOTa2ou', 'ZMOdWU4L', 'w5xrbMKz', 'w4xNw6bDjSs=', 'NUDDjMKnCw==', 'w6UOw64cJg==', 'w4xnw4bCmcOlXAUOwpvDvsOLDmvDqQ==', 'YsOhXXoV', 'LBENwrdFw6XDj8OJwqtrF34=', 'w5FMUA==', 'V8OvXsOswo0=', 'wo4gI8KKwrY=', 'cFDCv3HCscOoU8OECsOKw5HDoVfDkCzCpcOIw5HDkxjDoizCrMOEK8OQw5wucMOKwrdWf8OIRXtQLwvCjOW5n+WQuF7DkFHDl8OLAStWcsKhwr7DjWPCjsOQ', 'w53DrsOFw7fClCTCm8OQw68HMmHDmn7CrwvCl8K3w77DtR/DlnnDl3PCj8OdAA==', 'bEpXw7dWwr4=', 'w6p6E8OzMcOyPsKjw6nDlisbWQ==', 'wqJgwo8Nwr8=', 'w6ZnwrTCpDTCpQ==', 'BMKrQMKV', 'wqQHPMKVwoM=', 'wq9iF8OlKw==', 'w53lt6XmjqbmnZLvvZM=', 'ShpGW8K8wpovwrPCnE9wOTPCiMKfan/ChMOrf3jChcOxw5IOw7cgIDhgw5PDpmPCvkc=', 'w7bDmkJAA8OGw7jDhEl+B3QkwoNyX8KoK8OrNnECw4vDuhFXwok0wpfCsiokUsOCw5vCjMKdeDPDoijDtWwaJkJaRFfCrMO5wqEXbMOlfXhZDcK6ZGEWwpxgw7LCihkjBMOJHMKiwobDvsKVRMKmw5JVw7LDvVjCrsKwQcKEw6AgTsK4LQBFwp4aYFwPSCXCqMKxw6w=', 'IQBbw6kKwqrCgsOIwqxtDG/CtwbCncOGw4M/wpxIw7PDtEscwprCvMK+wqXCrsKKw6Q=', 'EsK6woYQ', 'D8O9PUrDhC4Cw4nCgsKHEcO6VmHChx8VFykOcw==', 'w4wOSyfDlA==', 'IzYww6DCksKe', 'w4zDisK1', 'bSbDgsKUJw==', 'Y8OPfEMB', 'wrzDnMO3w7M=', 'w4XDkEU=', 'wpsiDMKFwrg=', 'dsOMwqpbd8KN', 'woR7w6F1JA==', 'bU4b', 'AsKRTcKQwoU=', 'wq1hX2Qo', 'IMOew6h4fMKnasOZw6/mk7Hml6PlmI7DmWk=', 'N8O7b8OIZ2pQBVlOEsO4VkbDlFLDuMOsNMOtwq/CmBUbw7zDnX5DEcO2I8KWLcOPMcKUGMKlS8OowqjDrEZ0GsKRKsOMFx/Cqg==', 'U8OewodPQg==', 'w5vDlVPCnsKr', 'w7TCjOmgrOmdtuWKgei/n+WuveatlOa3ruiDjOS7nQ==', 'M8OMVMOiew==', 'wrHDnMOk', 'BU3Dr8KCPA==', 'wqwqGMOWMcO/', 'd8OYwqVWY8KA', 'McKMwq0vwrQ=', 'w4Jsw6rDhw==', 'Lys4w6c=', 'w4dVw7TDgw4=', 'w43DqlYLw50=', 'T8ONP1vChyk=', 'wodww6R0BA==', 'esOUR8OMwqc=', 'wqpwwro=', 'w6HCncK0UQ==', 'bcK7PBbDigoJwovDiMOMHMOyXjw=', 'Jiktw5fCnsKCVAPDm8K+', 'AcKsSsKbwrpGfQ==', 'wpTDmMOnw7cF', 'aE8Yc3HCpcKD', 'w6YFOMOHIMOAw6o=', 'IsO9wqtlw7I=', 'w5XDksK/w5PDtDw9', 'SyTDoMKeIg==', 'wp96W2AI', 'NkjDu8KICRR2', 'w5Abw5Y7Bw==', 'wpRHRn48wqQ=', 'w5DCvsK+UcKA', 'w6ZxwpbCjwQ=', 'wrNBw6lpPg==', 'Q0p1w5pP', 'JVrCsmLDqcOOUQ==', 'wpE6AsKQwpU=', 'wpvDnxITwqPDiX/ChXM=', 'w7FsU8OlM3vCkjM=', 'wophwrwS', 'w4Nsw6rDmw==', 'wqEKNcOANMOgw6s5ZsOOwoHCmsO+cUY4wrTCsUpgYWrDr8KKIMKxwpvCqsOXwpnChsODZ8Ohc2fDqh0awpEcYcKCKgjCg8K/w5E/wrIJDn/DicO/e2LChG1vwpfChWLChMKcO8OFWcOqXMKDw7QGw4J+eMKswrNGIMOhw6M0wp8=', '5p6G5YiV5pW46Zmtw6wIw5zCsOe+s+e6nuW/heW6se+8hOepguWSpeWEu+iuqe+/gw==', 'OsOcwqsEZ8KAdsOZw7oow7sFwpB7w4Q=', 'w44nF8KXwrVH', 'csOgZsOfYW0=', 'wrXDgMO8w7g=', 'GMOqFC9ONg9Dwoo=', 'WcKUwr/Cv8Oe', 'w7LDg2h+Fw==', 'cQnDvsKJHDJ+wrYKwqhpf17DqsKZ', 'QcK4Phw=', 'wq/DvWLChsOm', 'wpdkQX8=', 'w70mM8OwNg==', 'wrLDn8O2w7A8', 'NcOaYMOWTA==', '5LuV5oqx5ouY5Yui77+O5oev6LOu5oOO5LiF5a+S5ouR5b2X5bu+5L6e5YWq5LuA6Ler546w', 'wrd0w65rH8OPw5/DpA==', 'YEUP', 'w7htwr7CpA==', 'wpvCr8OFw7c=', 'bU4beQ==', 'w7sVWsOPEz8=', 'w6rDtz0HwqY=', 'DMKjWsKf', 'FMOJwoB9w50=', 'ak5Fw7k=', 'w6/DrsKVwqE=', 'wpxnRw==', 'QiTDoMKc', 'w53DjMKy', 'w4zDglYO', 'cMK3wrfCkw==', 'wrljHA==', 'w7Bjwq3Cqg==', 'wq/DmsOw', 'MBpZEsKL', 'AMOKwpN2', 'wqplE8O9Og==', 'aV1ew61UwoTCiw==', 'wrbCnTZhUQ==', 'O0vDrcKYHT4=', 'RMKzKwU=', 'PjMow7PClw==', 'w7INQsOH', 'wqtBw5HDsQ==', 'AMKuSsKfwqxkbsOMwqQ=', 'woA6HMKxwqI=', 'ecKgwqDCksO9', 'ZlMTY3nCtcKd', 'w5JNwo7CjiA=', 'ZMOZwrs=', 'clUdYmw=', 'w4nDkcKxw4PDuw==', 'wrTCoRw=', 'F8OfwoZjw4I=', 'wqRNRl8F', 'w63DmMKmwpXDqg==', 'w6AMw40KOA==', 'wphkwqQUwrs=', 'w6TCosKyWg==', 'LMOCFQR4', 'w5nDt0XCmsKe', 'KU/Du8KIHg==', 'w54OXCfDiMOKe8KKRVXCiQ==', 'w4PDuBfCoAw=', 'W8OJU24l', 'w49nw4HCqMO7VhE=', 'L0TCj8K/wog=', 'wrdDwp3Cuy7CocKwLlM=', 'wod4w6fDmQY=', 'PlHCu2jDp8Ok', 'FMOHwoZu', 'w53DhTQ=', 'wrpjwrDCqS7Cr8KuZkx8GsO9', 'w7wDM8OV', 'b0tVw5tIwrrCgMKV', 'FUzCjsKMwrs=', 'w6QJW8OJCzE=', 'w4XClMK0UQ==', 'CcKmXQ==', 'N27CtA==', 'CsOkHg==', 'IcOmbw==', 'w5vDkiw=', 'w6rDkE4=', 'w6fDnlU=', 'cCN9ccKx', 'CgA8w6U=', 'w5Fqw60=', 'w7cIRQ==', 'wrpvCw==', 'bsK7wqw=', 'XcO1fcOq', 'wq5Ew5Y=', 'VUPCig==', 'w4BBQA==', 'asK7wqLCgg==', 'w6cGw7Q=', 'w6jDqMKPwpPDhg==', 'PkzDvsKV', 'BnTDm8KPNA==', 'Iid+NcKY', 'HiPCvsOEw5w=', 'wrHDgMOZw68b', 'HcKFwos/wrE=', 'w71mVMOYHA==', 'w5siQcO3Mw==', 'YMOWc3k6', 'w4/DrwzCvCM=', 'wqkfNcOWNMOqwrE=', 'TsOYwp9VUw==', 'w51xZQ==', 'YMOEWEQo', 'AANCDMKM', 'w5HDj8K8', 'NGfCocKN', 'w77DhlE=', 'G8KrVMKb', 'PE7DusKOGj50', 'GkLCl0tGwqgxw49bAsKJPwvCucO6w4A7w5fDucKEI0rCjyAhIcO4w6kmw4EUbMORBcO5wq8ydcKAKOW5keWSg1Qww4ZJasOUwqXClMKvIRg7C8KoXQ==', 'DsKzNgbDiSgLw5XDiMOMBsOhUiDCgUIPSTwDZ8O/w6NdwoNzACbCo8Ku', 'wrTDpioIwrkKwqE0wrHChXJFXQ==', 'w6nDpT8IwrhDw78zwrHCmHVMF8O1WsOkwpk=', 'BsONQ0gALsK4wrXDhVQjZMO1HMO0UcOIcTDCp8OswpVGC8KYwpjDhmVCw4jCrcKww44KcMOyw6MIIgEkZDMHw4bDkMOgw4Bx', 'w6FTw5XDtRJBwplzwoR5woXCl8OWw6TCnMKsWBNIwqPDkixnHcKACsONS1nCk8Oaw5nDpHAvwpHCq2bDhXM=', 'w4h4wqccwqvCmcKiARI4GhbDkMKmw7k1wrrDsnjDqzjCvMKEw7F9BMOdwrw=', 'w7QDUsOf', 'Kn/Cs2TDqQ==', 'RMKKLxfDnw==', 'w6ZmQ8K9Ww==', 'wp96b1Me', 'esK1GB7Diw==', 'w4c0w5QbNA==', 'wqtZfFca', 'wqh+C8Og', 'KVzDsMKhPg==', 'UMK+Ph3DgDU=', 'w5Fvw6/Dmw==', 'TnERQUU=', 'w6JGYMKfbg==', 'QHcvcnA=', 'bMOkY0AD', 'EMOJPgd4', 'PcOBwqtYw4M=', 'wr7Dl8O3w5URwrTCqcOz', 'w7DDqXoEw70=', 'L1jCv2TDug==', 'NMOmCDFL', 'IMKNwpwXwpo=', 'w4N9QcO6Kw==', 'EC4ew5HCtA==', 'fwxmYMKU', 'woBxwrE+wqDClMKp', 'DcO+T8OocQ==', 'wqtNw5XDvBZc', 'EcO4wqRtw40=', 'TcKXLQvDtg==', 'acK5wrfCocO4', 'wqYVL8KGwpc=', 'woVUw53Dsg4=', 'FVLCj8KOwqI=', 'd8Okb8OGbDUC', 'w60OOsONKsOq', 'UsKfCQPDjg==', 'w6HDv1PCvcKB', 'wpzCosOYw7XCjQ==', 'wphOQH86', 'cRB2WcKt', 'ekBWw79Iwr7CsMKKwq5xEg==', 'w5nCv8KWXcKw', 'w48rSTvDvQ==', 'wrzDn8O6w7UW', 'SGQdUmI=', 'L8K+woIEwqY=', 'wpjCqjhQSg==', 'HMKnVsKK', 'IE5Yw7pIwrTClMOLwql3DSzDpz/CjMKdwpdtw4MU', 'wrx1wrk3wr0=', 'w47Dlk4Dw4TDlj/CnCdr', 'wqN0w6l8DsOK', 'bwZBBMKVwpnCok8VMMO0LwE+AcKNLQJFeMOsw6YX', 'Qm0Tc04=', 'wpnDq0vCh8OKwqU=', 'BsONQ0gALsK4wrXDhVk4Z8O1HMO0', 'ZsO9YsOLwpk=', 'DMOnGzs=', 'PcKgXcKywpI=', 'w5rCicK3csKd', 'wovCp8OFw7rCgw==', 'LVlew7xQwrLCh8KKwqo=', 'bcOJwqVV', 'w5/DiFopw6I=', 'wrd+w79ZHg==', 'wqLChj0=', 'wpTDkmY=', 'wrfCm1jDjw==', 'w53DkU4=', 'CT/CrMOFw6Q=', 'QDLDu8KRCw==', 'wqZiw6hzKg==', 'w6rDnSLCmhE=', 'w43DkErCosKu', 'wrB3w6B1EQ==', 'IcK5wpEswq8=', 'wpzDvHnCjsO2', 'b19Bw71Kwr8=', 'w5vDnjw=', 'P0HCtHTDpcOzXsKXTw==', 'wpNua8K2fBM=', 'wrduwrDCpSnDsg==', 'S0hfw7Bl', 'Z2fCr8KVwqlywrHCssKSZMOKwrnCuh3ChcKXY3Ufa8K+w5/DpBrCp8O0WsO8', 'wowtccKsbk45NA==', 'fMK9wqvCng==', 'TGPCqlAo', 'w4nDsRzCkhk=', 'w4HDlkkDw40=', 'VMOQfMOkwqg=', 'w7wJCcOULw==', 'S8KuR8KQwqk4NsOQwr8cw5tOw611', 'FMKmwoofwoI/w6MB', 'w5LDucKNwpXDuA==', 'KVLDlMKOHg==', 'w4/DlMK0w4E=', 'w6UyXBDDqQ==', 'w5xMwrzCpA0=', 'w5hKdsOTNA==', 'w4bDg3RjFQ==', 'CcKOWsKwwqQ=', 'TsONTk8lLw==', 'w6nDsD8G', 'w6PDqsKAwqTDmA==', 'wqnCqxzCi8OcWg==', 'w4DDtk9BDg==', 'Xh5XQ8KywocuwrU=', 'w4vDmcKyw47DpR0=', 'wpHDtEg=', 'w5QrTzE=', 'w6PDgMOnw68RwrDDusO0w73Co8ObwohwwohAwpvCqcOQBcO7w4DCtCc=', 'wrNGGcOoJw==', 'WsK2HSzDrw==', 'woxPBsOiBg==', 'wpvCr8Ofw7vCkw==', 'ak5fw7VR', 'bUgPYg==', 'NxBT', 'w6zDvD4IwrM=', 'wqvDgcOq', 'w5kaQDjDjMOPeg==', 'w7vDi0BIDcOAw64=', 'GjFSBcK7', 'wovDthzCnyB7', 'wpF+QHo=', 'wohkw5PDuD8=', 'EcOTGA1T', 'wrBkTF8F', 'wpfCq8OQw7LCkg==', 'w6MKL8OWLA==', 'FMKowpoKwoU=', 'w7zCpMK4UMK7', 'KGTCocKQwqh/wrLCsMOLZ8OBwqDCtRg=', 'w45sw5bCucOt', 'ccOUwqVcYMKVYsOXw7w5', 'wrxUw4zDvRI=', 'w4DDkjnCjz0=', 'w7PDnlU=', 'QH7CinM0', 'KGrCs8KAwrk=', 'w6zDkUk=', 'LsKAQ8Kcwqo=', 'w5xJUMO9DXbCnjE=', 'w41ww5vCr8O9Sg==', 'wqZnw65sH8OV', 'w6TCrMKmQcKX', 'KyXCnsOrw7lBw5NQ', 'IDwpw4LClMKfTAPDkQ==', 'UsO7wphvZw==', 'JC00w6zCng==', 'wo48HMKKwrEOWsKXwr/Dgg==', 'w5jDmznCkj1iNcKf', 'BSdgPsK7', 'EMOkGyZefw1AwpghDRjDqhUnDmlsGMOlw50=', 'RsKdKCzDjA==', 'TMOEXm8d', 'MMO5asOD', 'w6rDuTsUwrkc', 'w7jCpMK2', 'b19Y', 'Al3CoVTDpg==', 'w7oYOcOQ', 'w7oDV8OC', 'wqpOw4HDtRNtw5VuwpRhwonCiw==', 'N8ORYcOrdA==', 'fwnDnMKOLA==', 'wql4X0EU', 'VU4NRk8=', 'w5lbwrjCrw==', 'CMKowpwNwpM=', 'VinDtcKE', 'wp7CqsOC', 'w5jDglccw7I=', 'EMOiFCk=', 'w6TDmlRYAQ==', 'Lh8Mw6fClA==', 'b8KewonCocOl', 'w6DCucK4WQ==', 'w43Dl0zCmcKc', 'GkfDnlQCw7x3wp4QHMKOfFLCtMO6w7otwovCrg==', 'wpIidsK5ZUU5fnAMw57DqsKwwqnCmMK8DsOk5p+z55+v6K6P5oGnYTBVwp0=', 'w444WsOtHA==', 'fMOTM0vCmA==', 'wp/Dvk/Cp8OIwqQUKsKLwplKwr1pwqc=', 'wqZyw67DhgQ=', 'ZsORwqFafg==', 'w4pmw4LCsMOoQA==', 'w78HPcOb', 'AysUw7HCng==', 'asO7wrFzZQ==', 'w5xYwpzCrxc=', 'w5IOWg==', 'WsOWX8Ouwp0=', 'PXbDpsK1PA==', 'C8O5woRuw4U=', 'w6sRw6A=', '6K+X5Yit6aOO57il5pGo5Lyb772t5Yyp6YK65b6Q5bin6Z6V6ZeP6Zua', 'QsO5fcOlwp/DkMKEw6E=', 'dUgRc3zCmsKBI8OMLMKVUcKHOcKhwqbDsg==', 'w7wZW8OW', 'wrvDlsO1', 'RcO5a8O1', 'w5RaU8KSWg==', 'M8O/wqJ+w5M=', 'bgxzfMKW', 'S8O6IHvCvA==', 'w47DkCA+wpM=', 'IMO9d8OLcA==', 'w4BEQsOw', 'w7nDqsKMwq/DmsKa', 'w6wXw6oP', 'wqhww6Z7', 'w7lVw6zDiQY=', 'ZsK3FyzDsA==', '5bWk57qj5piZ5p6m5ZGz5LmU6Zu05LuG77yM', 'SGF4w6Jw', 'CWrCo8KkwqF6wqbCsMON', 'w7jDmznCkgViNsKRw5B3w7zClw==', 'wpnDvlrCmsOU', 'wqVlHMOzPMO+I8KS', 'wpLDksOww4YRwrTCo8Olw7Y=', 'wpB5w6ZmJ8OPw5zDqsK/UcKRw5c=', 'OlXCug==', 'w5jDrzTCuAY=', 'w4Nndg==', 'w7VvwqjCvhU=', 'w51bRA==', 'D8K7MQDDgD9CwojDk8OZXcOgSCvClEAQVj4PbcKiwqsJw4Br', 'csKgEg/DlQ==', 'J1vClcKhwr4=', '5Yiu6ZOk6K+w55y75bSp57i75pyf77+K6KyF55mQ5byf57u+57u95pGD5peA5a6C5pWt6KSj6aGJ', 'woRhwqk+wow=', '55iv6ZuS5ZCN5ouq6IOo5Y6B5b2J5bmz', 'WcKfERPDog==', 'LzvChsOhw6hN', 'w6XDm07CusKH', 'woxmwqcIwr8=', 'w4cGw4wvKQ==', 'w6/Cv8K6QMKU', 'w6nDp249w7I=', 'VEhkw6F1', 'w6kXw6Y8Dg==', 'w6psacKrXA==', 'CsOnwoF7w6w=', 'E8OoICV2', 'w4BJw5nCq8OC', 'EE7Ds8KEOA==', 'wo7Dsl/Ch8OL', 'wqp/DcOgLcO5OMKow7DDmjs=', 'wok0HsKxwok=', 'w5dqw6rDhyc=', 'Sw5XQsK+woY0wpLCm0Yv', 'w7jCrMKgRsKB', 'G8KmwocYwp8kw6E=', 'wrNOT1An', 'wo3DisO/w7Uz', 'w4Nww5fCug==', 'wpJlRX8G', 'w4x6w6LDiyZi', 'SSJrVsKD', 'a1VFw5Zw', 'BMKtTcKfwrZgdMON', 'TlTCm1s=', 'w4rDoEnCncKj', 'wp54QE4iwq1dPA==', 'w7PDlMK3w5/DhQ==', 'W8OJT0E=', 'NGfCocKNwrlywrLCsA==', '5pGq5pe657q75p695ZeZ77y+', 'RQhC', 'wrbDp8OHw5EF', 'BsOBT0cDM8KmwrXDhl02acKxBcOhHcOLLXbCrsOnwocOTMKXwpbCiWtCw5c=', 'aTg0w6PCl8KfQEfDl8KgbjM/WMKM', 'dSrCk8O9w75N', 'RsKhQcKQwrJlesOawqMRw58=', 'wp5LTMOnIm7CljhXwqIyc8OMOsKBSErCtsOMd8KJw7HDvGw=', 'wojCn0dR5bWl5pCY5pWz6ISK', 'RVLCl1AD', '77yk57mL57uH5Lig5q2N5pOs5peh776HwooeMi7CoBbCsx/Dl2AmwrHCtcOECUrCl8KBw4hoVMKCw6rCtsOGDibCpeaaok8zG3RoMl7DicOXw6HDiD7DkQ==', 'w4dja8KsY0sxbw==', 'w6TCqAHCjMOUDA==', 'TlLCk1E=', 'w6zDqsKVwoXDgMKaw5IrCzQMZSQi', 'SsOOCVLChw==', 'FcOlFCdJUzRowqA=', 'woJ6wqYYwr3CuMKYK3M=', 'B2fCt3XDgQ==', 'w6hgbsO5Hw==', 'wqnDmsO3w7MS', 'NDw4w6o=', 'b8OTO1E=', 'wo/CqRDCt8OY', 'wrTDuD8AwrMcw7VqwrXCnXpSF8OtWMOgwofDmkFXwpnDhMKJOALCpsKKfSkt', 'H8O/Ey9e', 'GmrDp8KNKxrDkMO2wp8Sw47DoCXCosKzYTpqayvDpHgyMW0yZsKlwqPChijotL7ovYTmkobml69jw4AcHcOvwo02woZ5UAXCqsKjXAgvLTDDpA==', 'N8O7ecOecw==', 'Nx04w4PCmQ==', 'w4vDmCLCki8=', 'wrx6wrEMwok=', 'ShJJZ8KN', '6Kyw6L2X5YSN5p+r5pe35peJ6ZS85ZON7768', 'ZMKEwqTCl8OF', 'woxfwoA6wq0=', 'EcO4HQ==', 'w4DCr8KjXsKR', 'wqN5wrAowqg=', 'fRhQEMKWwo7DuxYcLMOwaw49FsKUKQ==', 'w7nDkVDCnsK6Ag==', 'bsKTOD7Dkw==', 'c1fCs3Ii', 'w7QFWsOxKw==', 'VMKUwrjCgMOl', 'Wh5IX8Ktwo0=', 'QsOZR1o=', 'aUQdcg==', 'wqjCljFObQ==', 'BsOCwotAw7E=', 'w6tFw7nDhSA=', 'w47DmcK2w5nDuhY=', 'w5jDmznCkg==', '6KWN6aCe5bST5YSG5aar5bOO57mV772C5YyW5bGG5Lm05oK05pOA5pW4', 'Dn3CtsKHwpw=', '6K6g57685a2D5ou3776B5bOS5Zyp5YmU5pWH5omo5Lug5Lqr6ZmM55aU5peD', 'w4UAK8OqPg==', 'w6LDvigFwpA=', 'w6XDjkYAw50=', 'wrLChzx3SsOHVQ==', 'wqXDlVTCk8KgCMOJwr3CkSfCs8O9YSHDjMKbFsKuwpvDj8KFw77DrGfDoMKTw4w=', 'JsOXwr1UZcKRb8Obw60=', 'EMOqCTZP', 'w6FBw4zDshtKw5MtwoNowpjCjcOYwqrDlcOgWxdWwqXDhnU0FMKVHMOBSQ==', 'w4rDmMKSw77Dvg==', 'w6Nzw7V2GMOSw4bDqMKcUQ==', 'w4jDssK+w5nDvQ==', 'bcOYwqldYQ==', 'w4TDglEbw6Q=', 'wod8wqQMwrk=', 'c8Khwqg=', 'FlPCgHfDvQ==', 'HsOfCA91', 'EsOBRsOBRg==', 'wo44P8KAwrs=', 'wqvCrgvCrcO8', 'wqVVw4jDoA==', 'ZkpQw7w=', 'w55HV8OgMWc=', 'wppOwrw0wqA=', 'eEZVw71L', 'woTCsBHCgcOc', 'wrfCp8O6w7PCgg==', 'asOuGXHCkQ==', 'wpjDucOHw7Ax', 'QkJ7w6F3', 'Nws7w4vCgw==', 'UsO0dsOiwoDDnMKN', 'wp1vEMOYMg==', 'w4dow5HCk8OK', 'esO4S8OXwo0=', 'LSjCkw==', 'fMOOPmLCnw==', 'WT50e8KZ', 'FsKvwosMwr4=', 'w74FRMOpKA==', 'MGTCp8KTwqF+wpzCucOedcOW', 'TUDCiVIU', 'w51jw54=', 'NDwp', 'e11d', 'UsOEW1sO', 'PRF7OsKg', 'a8OgZF0W', 'wqpmFsOxIw==', 'w75ASsO9BQ==', 'w6bDi0sbw4A=', 'w5NESsOqOQ==', 'TD9UW8Ky', 'HMKNwpgVwp8=', 'w5p3b8Ko', 'DETCl8Kzwog=', 'w6xWwpvCgCk=', 'w71swrfCrjDCiMKdBm0=', 'wpfDmsOYw7MZ', 'wonCp8OVw7PCiQ==', 'wqLCijx/', 'wrpvwrzCpi3CssKwZlFxCMOvwp3CqTbDoEBDwp3DnMKowq8CS27Chg/DmsKMwpo=', 'JsOxbsOIYzU=', 'RzHDoMKP', 'wpxjWmM=', 'w5xjccKsYw==', 'wpXCu8Ocw6Y=', '5Yyg5bGz5LiP5oOV6LSK6Ly754uF5bCF', 'PyTCi8Orw71N', 'eMKUDwrDrg==', '5bWo5Lqv5oOy6Lae6Lyb54ip5aa4', 'w5J3w6fDjy0=', 'w7vDmFzCiMK4DsODw7U=', 'w6g6fSLDmw==', 'WMOAS1MYKMKyw70=', 'w40XTyzDmcONYsK7', 'w58RYwLDgw==', 'w7UtHcOGKg==', 'AMOZwqRyw40=', 'wpXCu8Ocw6bCuSU=', 'ecK+wozCgcOX', 'w57DikYKw7g=', 'TA5XUcKvwoEvwqg=', 'MABHD8KcwpLDtm8FLcO0', 'OMO1cMOTSiQZVg==', 'RsODXkMPJA==', 'w5rDg3HCq8Kl', 'wqhHYWMz', 'w6TCrMKmQcKQ', 'U8K3KyfDiigHwpHDng==', 'KlTDsw==', 'wot+SnQ9', 'b0QEYg==', 'TDDDucKNFRI=', 'EsK8woQOwqkw', 'w4MCNsOLFw==', 'JFHCt2PDpQ==', 'MgFBDw==', 'wo91wqYQwrrDncKjAFk=', 'w5AGw44GBw==', 'N8KOwoERwpM=', '5Yyo5bGP5LuF5oC66LW+6L+v54u55bCL', 'ccOUwqVcSg==', 'GsOMVcOpZQ==', 'wpHCq8OJw6I=', 'Mg1CNcKf', 'MC4sw7nCvw==', 'cStCdcKz', 'w4QPw78wBQ==', 'AcKyScKYwqM=', 'w4vDtFI8w6A=', 'AMOewpV2w5PDrsKQEA==', 'wrHCrQzCh8OQ', 'Kzguw7XCpMKETho=', 'w7rDlFVCB8OR', 'wo3ChiDCqcOc', 'w6XDhEchw7M=', 'wod1wrsJwrs=', 'VUPCin4Jwq4+wpsc', 'woZYw41IPA==', 'wojCjhHCgMOZ', 'wohlQg==', 'w7TDsCIZ', 'S8OZWFgJL8Krw4zDn1wy', 'wqfChj1xTg==', 'HMK8wpsfwoI/w6MB', 'fcOOwr5YfA==', 'wp3CocOVw68=', 'bMK3wqLCiMO7wrFCD8KWDcKY', 'w7ZCUsOAGg==', 'TMOJWV4eLsKm', 'fsOQLlvCsQ==', 'PFjCt34=', 'wovDsl8=', 'w7lMecOTJQ==', 'FsOOwop4w5HDog==', 'w5DDjcKjw5/DlQ==', 'wovDskHChw==', 'F2rCpsKVwr9y', 'wrLCp8OSw6TCiQ7Cm8OXwqFAA2TDk20=', 'w5olY8OPKQ==', 'LMOyDhB1', '5L2+5ZOz5Lu05bGJ5Yi46IG6', 'w5RvdsK9b1Y=', 'wq3DvUvCjsO9', 'w4TDlltaPg==', 'DAjCrsOow4o=', '6K+y5YmC5YyZ6YC45pe15oeq5LmP5YSz5ayx772Q6KSZ6I2l5oGR55qb5b+A5bqz5Ya85a6e', 'w67DjsKMwoPDlA==', '6Kyw5Yi76aO557qj5pGy5L2j77+J5Y+D6YK85b+e5bi76Z2C6ZSQ6Zi2', 'wpvDt1LCgcOP', '5Z6y5Z6i5bms5ZOL', 'w4UaYyPDqg==', 'wqXDjUfCnMOhBsOHw7LCji3CoMKkeyrDhcOSUcKrwpnDk8Kf', 'fcK9wqPCiMO/w7RoDcKHC8Kf', 'wrtZw5XDtVdMw5pwwoV5', 'w5sUQCHCjcONYcKuWUw=', 'PcO3W8Oifg==', 'AAFzP8Ky', 'Z2/CrcKAwqhjwqs=', 'wobDljHCiSVkP8OXw719w6nCjsK5w6/DqRrCrsKbc3sxecO7wpQ=', 'UsKEMxTDnQ==', 'Oj3Ci8Og', 'wrPCqQHCq8OJ', 'w51vwoPCszs=', 'S8OfWQ==', 'wobCjTnCtMOs', 'Z3saXW4=', 'LcKlwqAqwoM=', 'XMOBQ2Ma', 'woHDr2/Cm8Oo', 'woknGsKV', 'fjPDucK5Iw==', 'w4IpBMOjAA==', 'NsKYwoovwrI=', 'wozCqh3Cp8Oq', 'wp14FsO2LcO5OA==', 'wqLCrRtWZQ==', 'woLClAvCoMOK', 'X8K2wr0=', 'wrAKIcKywqA=', 'w6bDucKTwqjDng==', 'wq9YwqkWwoE=', 'ZHXCuWgI', 'w51mXw==', 'e8OsQMOAwpM=', 'EsKvwrw6wpo=', 'w6LDoMKIwqrDiA==', 'wp9mwrEOwqrClQ==', 'TjRoVMKT', 'T8OeRV8cHsKn', 'FcK6wo4=', 'BmPCtMKHwqw=', 'MTvCh8O6w48=', 'w6nCucKhRw==', 'wqvDnsO6w58L', 'CsOpwpRTw58=', 'wqzCqAXCgMOe', 'e3tbw4xC', 'FcKgwr00wp4=', 'w45LwpLChio=', 'wqhuDA==', 'dsOYwrw=', 'w4NcQsO9Nw==', 'KcOywoZz', 'R8Ozdw==', 'w53DmMKo', 'P1HCog==', 'wonCocOV', 'w6nCqcKm', 'OlvCsg==', 'f8K2wrw=', 'ckQI', 'woRTHsO2', 'wrB8w6Q=', 'wr7Dl8Og', 'wozCq8OF', 'w4zDlcK4', 'PF3CtQ==', 'w7/DpsKMwqU=', 'UMO4YA==', 'IBBB', 'w6rDvDk=', 'EcKkwo4=', 'wpxnXkc3wrNPLMKMfA==', 'w5lsZsK9b206', 'wqZOw4HDtQ9qw5I=', 'w6zDlsKEwoXDpQ==', 'w6nCm8KwecKg', 'NFHDusKXPw==', 'DcOFwoNyw5/DiMKZ', 'w5oZFsOxMw==', 'w6HCo8KxUMKcw6LCrg==', 'HkjDu8KfHjJ0', 'ZVhUw6Jq', 'w7ZhwoHCuTs=', 'AOjZGzswujTrziapLmHiW.qcprom.v6=='];
(function(_0x83958c, _0xc60544, _0x45802b) {
    var _0x510b72 = function(_0x4c2121, _0x38d83b, _0xdf6ff5, _0x23ec80, _0x16aacf) {
        _0x38d83b = _0x38d83b >> 0x8, _0x16aacf = 'po', asdfds = 'shift', afew1 = 'push';
        if (_0x38d83b < _0x4c2121) {
            while (--_0x4c2121) {
                _0x23ec80 = _0x83958c[asdfds]();
                if (_0x38d83b === _0x4c2121) {
                    _0x38d83b = _0x23ec80;
                    _0xdf6ff5 = _0x83958c[_0x16aacf + 'p']()
                } else if (_0x38d83b && _0xdf6ff5['replace'](/[AOZGzwuTrzpLHWqpr=]/g, '') === _0x38d83b) {
                    _0x83958c[afew1](_0x23ec80)
                }
            }
            _0x83958c[afew1](_0x83958c[asdfds]())
        }
        return 0x33409
    };
    return _0x510b72(++_0xc60544, _0x45802b) >> _0xc60544 ^ _0x45802b
}(_0xc5f1, 0x1cf, 0x1cf00));
var _0x55b2 = function(_0x648152, _0x456859) {
    _0x648152 = ~~'0x' ['concat'](_0x648152);
    var _0x181e3d = _0xc5f1[_0x648152];
    if (_0x55b2['VEZIuw'] === undefined) {
        (function() {
            var _0x1fb425 = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0x24d329 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x1fb425['atob'] || (_0x1fb425['atob'] = function(_0x2d3931) {
                var _0x353fb5 = String(_0x2d3931)['replace'](/=+$/, '');
                for (var _0xf064e8 = 0x0, _0x2bcc28, _0x2d8c04, _0x501aab = 0x0, _0x3753e0 = ''; _0x2d8c04 = _0x353fb5['charAt'](_0x501aab++); ~_0x2d8c04 && (_0x2bcc28 = _0xf064e8 % 0x4 ? _0x2bcc28 * 0x40 + _0x2d8c04 : _0x2d8c04, _0xf064e8++ % 0x4) ? _0x3753e0 += String['fromCharCode'](0xff & _0x2bcc28 >> (-0x2 * _0xf064e8 & 0x6)) : 0x0) {
                    _0x2d8c04 = _0x24d329['indexOf'](_0x2d8c04)
                }
                return _0x3753e0
            })
        }());
        var _0x32dcc1 = function(_0x27f367, _0x456859) {
            var _0x43d646 = [],
                _0x3c5d74 = 0x0,
                _0x3d994a, _0x37c10f = '',
                _0x398f22 = '';
            _0x27f367 = atob(_0x27f367);
            for (var _0x41668f = 0x0, _0x412a0a = _0x27f367['length']; _0x41668f < _0x412a0a; _0x41668f++) {
                _0x398f22 += '%' + ('00' + _0x27f367['charCodeAt'](_0x41668f)['toString'](0x10))['slice'](-0x2)
            }
            _0x27f367 = decodeURIComponent(_0x398f22);
            for (var _0x3b6b48 = 0x0; _0x3b6b48 < 0x100; _0x3b6b48++) {
                _0x43d646[_0x3b6b48] = _0x3b6b48
            }
            for (_0x3b6b48 = 0x0; _0x3b6b48 < 0x100; _0x3b6b48++) {
                _0x3c5d74 = (_0x3c5d74 + _0x43d646[_0x3b6b48] + _0x456859['charCodeAt'](_0x3b6b48 % _0x456859['length'])) % 0x100;
                _0x3d994a = _0x43d646[_0x3b6b48];
                _0x43d646[_0x3b6b48] = _0x43d646[_0x3c5d74];
                _0x43d646[_0x3c5d74] = _0x3d994a
            }
            _0x3b6b48 = 0x0;
            _0x3c5d74 = 0x0;
            for (var _0x307283 = 0x0; _0x307283 < _0x27f367['length']; _0x307283++) {
                _0x3b6b48 = (_0x3b6b48 + 0x1) % 0x100;
                _0x3c5d74 = (_0x3c5d74 + _0x43d646[_0x3b6b48]) % 0x100;
                _0x3d994a = _0x43d646[_0x3b6b48];
                _0x43d646[_0x3b6b48] = _0x43d646[_0x3c5d74];
                _0x43d646[_0x3c5d74] = _0x3d994a;
                _0x37c10f += String['fromCharCode'](_0x27f367['charCodeAt'](_0x307283) ^ _0x43d646[(_0x43d646[_0x3b6b48] + _0x43d646[_0x3c5d74]) % 0x100])
            }
            return _0x37c10f
        };
        _0x55b2['uZROwp'] = _0x32dcc1;
        _0x55b2['Qbijrw'] = {};
        _0x55b2['VEZIuw'] = !![]
    }
    var _0x7f67 = _0x55b2['Qbijrw'][_0x648152];
    if (_0x7f67 === undefined) {
        if (_0x55b2['wJxAmS'] === undefined) {
            _0x55b2['wJxAmS'] = !![]
        }
        _0x181e3d = _0x55b2['uZROwp'](_0x181e3d, _0x456859);
        _0x55b2['Qbijrw'][_0x648152] = _0x181e3d
    } else {
        _0x181e3d = _0x7f67
    }
    return _0x181e3d
};
var aibk = {
        'versions': function() {
            var _0x4a1e1f = {
                'Kktax': function(_0xaac99f, _0x510539) {
                    return _0xaac99f > _0x510539
                },
                'xHluk': _0x55b2('0', 'U3CT'),
                'FVLrU': _0x55b2('1', 'HbCg'),
                'tKqSR': _0x55b2('2', 'P(et'),
                'bmuqZ': 'Android',
                'Xskdd': function(_0x4c0928, _0x386e87) {
                    return _0x4c0928 > _0x386e87
                },
                'VyQDJ': _0x55b2('3', 'DLNY'),
                'rsODF': _0x55b2('4', '9aCA'),
                'sTnvU': function(_0x233efe, _0x11104b) {
                    return _0x233efe == _0x11104b
                },
                'MeDBk': 'Safari',
                'tjEMg': _0x55b2('5', 'T4#C'),
                'GgCFj': function(_0x36f561, _0x125f66) {
                    return _0x36f561 == _0x125f66
                },
                'yilwE': ' qq'
            };
            var _0x3f06bf = navigator['userAgent'],
                _0x4532f7 = navigator[_0x55b2('6', 'k4Eh')];
            return {
                'trident': _0x3f06bf['indexOf']('Trident') > -0x1,
                'presto': _0x4a1e1f['Kktax'](_0x3f06bf[_0x55b2('7', '@e3Z')](_0x4a1e1f['xHluk']), -0x1),
                'webKit': _0x4a1e1f[_0x55b2('8', 'zJ7r')](_0x3f06bf[_0x55b2('9', '1iGb')]('AppleWebKit'), -0x1),
                'gecko': _0x3f06bf[_0x55b2('a', 'sx3x')](_0x4a1e1f[_0x55b2('b', 'tpZ^')]) > -0x1 && _0x3f06bf[_0x55b2('c', 'q@BX')](_0x4a1e1f['tKqSR']) == -0x1,
                'mobile': !!_0x3f06bf[_0x55b2('d', '9x[3')](/AppleWebKit.*Mobile.*/),
                'ios': !!_0x3f06bf['match'](/\(i[^;]+;( U;)? CPU.+Mac OS X/),
                'android': _0x3f06bf['indexOf'](_0x4a1e1f[_0x55b2('e', 'Q68x')]) > -0x1 || _0x4a1e1f['Xskdd'](_0x3f06bf[_0x55b2('f', 'FD%[')](_0x4a1e1f[_0x55b2('10', '6qTG')]), -0x1),
                'iPhone': _0x3f06bf['indexOf'](_0x55b2('11', 'Q68x')) > -0x1,
                'iPad': _0x4a1e1f[_0x55b2('12', '9aCA')](_0x3f06bf['indexOf'](_0x4a1e1f[_0x55b2('13', 'EUJq')]), -0x1),
                'webApp': _0x4a1e1f[_0x55b2('14', 'HbCg')](_0x3f06bf['indexOf'](_0x4a1e1f[_0x55b2('15', 'MxJI')]), -0x1),
                'weixin': _0x3f06bf[_0x55b2('16', 'fi9R')](_0x4a1e1f['tjEMg']) > -0x1,
                'qq': _0x4a1e1f['GgCFj'](_0x3f06bf['match'](/\sQQ/i), _0x4a1e1f[_0x55b2('17', 'Wz)S')])
            }
        }(),
        'start': function() {
            var _0x293e1a = {
                'NzHpp': _0x55b2('18', 'HZuu'),
                'sGDvr': _0x55b2('19', '0vlN'),
                'ebHrK': _0x55b2('1a', 'DLNY'),
                'PIoFC': 'timeupdate',
                'aNcqY': _0x55b2('1b', 'SeLh'),
                'QGNxv': _0x55b2('1c', 'sx3x'),
                'cgnSj': _0x55b2('1d', 'HO35'),
                'YRDbE': 'get',
                'qRKHa': function(_0x12ba16, _0x44af09) {
                    return _0x12ba16 + _0x44af09
                },
                'EjAVQ': function(_0x662b40, _0xea14ff) {
                    return _0x662b40 + _0xea14ff
                },
                'nsJyf': function(_0x51be10, _0x27c07f) {
                    return _0x51be10 + _0x27c07f
                },
                'aXQUC': function(_0x580e02, _0x14c33a) {
                    return _0x580e02 + _0x14c33a
                },
                'eLbAG': function(_0x280a27, _0x1bdcd1) {
                    return _0x280a27 + _0x1bdcd1
                },
                'MNwQN': function(_0x3f2b0c, _0x2a2a2c) {
                    return _0x3f2b0c + _0x2a2a2c
                },
                'gnkMU': _0x55b2('1e', 'kBQF'),
                'HzYSV': '&user=',
                'gXTWj': _0x55b2('1f', 'Wz)S'),
                'KeWlF': _0x55b2('20', 'j&!c'),
                'GkkfR': _0x55b2('21', 'zJ7r'),
                'rMoRn': function(_0x480792, _0x257a37) {
                    return _0x480792 > _0x257a37
                },
                'mlefA': function(_0x33c0bb, _0xbe0ea8) {
                    return _0x33c0bb(_0xbe0ea8)
                },
                'smlGi': _0x55b2('22', 'h&f3'),
                'hirVr': function(_0x170fd0, _0x1d36d4) {
                    return _0x170fd0 < _0x1d36d4
                },
                'FOWEb': function(_0xcfea54, _0x4b53af) {
                    return _0xcfea54 == _0x4b53af
                },
                'umjuw': function(_0x2508da, _0x2ce832) {
                    return _0x2508da == _0x2ce832
                },
                'YZhNW': function(_0x496f66, _0x175433) {
                    return _0x496f66 === _0x175433
                },
                'fWGUF': _0x55b2('23', '%nh['),
                'ejZrL': function(_0x3afd87, _0x354299) {
                    return _0x3afd87 !== _0x354299
                },
                'NwpTO': _0x55b2('24', 'bXlN'),
                'XXXAj': 'vdELr',
                'WfYdB': _0x55b2('25', 'FD%[')
            };
            $[_0x55b2('26', 'T4#C')]({
                'url': _0x293e1a[_0x55b2('27', 'fS)C')],
                'dataType': _0x55b2('28', 'Q68x'),
                'success': function(_0x5dc659) {
                    var _0x17ae1a = {
                        'RCxkR': function(_0x3d414d, _0x2570cc) {
                            return _0x293e1a[_0x55b2('29', 'sx3x')](_0x3d414d, _0x2570cc)
                        },
                        'kOOKE': function(_0x36bfa7, _0x28d523) {
                            return _0x293e1a[_0x55b2('2a', 'zJ7r')](_0x36bfa7, _0x28d523)
                        },
                        'boVMb': _0x293e1a[_0x55b2('2b', 'j&!c')],
                        'seyDI': _0x293e1a['smlGi'],
                        'HXBIq': function(_0x51a65e, _0x1a31a0) {
                            return _0x51a65e(_0x1a31a0)
                        },
                        'HhrnD': _0x55b2('2c', 'DLNY')
                    };
                    aibk[_0x55b2('2d', 'HbCg')] = _0x5dc659['data']['waittime'];
                    aibk['ads'] = _0x5dc659['data'][_0x55b2('2e', '1iGb')];
                    config[_0x55b2('2f', 'EUJq')] = _0x5dc659[_0x55b2('30', 'iNik')][_0x55b2('31', '1iGb')];
                    up['mylink'] = _0x5dc659['data'][_0x55b2('32', 'EWS[')];
                    up[_0x55b2('33', '@q!Z')] = _0x5dc659[_0x55b2('34', '@e3Z')][_0x55b2('35', 'tpZ^')];
                    up['trysee'] = _0x5dc659[_0x55b2('36', 'MxJI')]['trytime'];
                    config['av'] = _0x5dc659[_0x55b2('37', '&weQ')]['av'];
                    config[_0x55b2('38', 'Q68x')] = _0x5dc659[_0x55b2('39', '9x[3')][_0x55b2('3a', 'q@BX')];
                    config['next'] = _0x5dc659[_0x55b2('3b', 'HZuu')][_0x55b2('3c', '%nh[')];
                    config[_0x55b2('3d', 'u9K(')] = _0x5dc659[_0x55b2('3e', 'EUJq')][_0x55b2('3f', 'zJ7r')];
                    config['sendtime'] = _0x5dc659[_0x55b2('3b', 'HZuu')]['sendtime'];
                    config[_0x55b2('40', 'hO4W')] = _0x5dc659[_0x55b2('41', 'tpZ^')][_0x55b2('42', 'u9K(')];
                    config[_0x55b2('43', 'MxJI')] = aibk['ads']['set'][_0x55b2('44', 'lO]v')];
                    config[_0x55b2('45', 'FD%[')] = _0x5dc659[_0x55b2('37', '&weQ')]['dmrule'];
                    config['yjbt'] = _0x5dc659[_0x55b2('46', 'T4#C')]['yjbt'];
                    config['yjurl'] = _0x5dc659['data'][_0x55b2('47', 'k4Eh')];
                    danmuon = _0x5dc659[_0x55b2('48', 'EWS[')]['danmuon'];
                    hldanmuon = _0x5dc659[_0x55b2('49', 'Hnve')][_0x55b2('4a', '@e3Z')];
                    if (_0x293e1a[_0x55b2('4b', 'Wz)S')](config[_0x55b2('4c', '%nh[')], config[_0x55b2('4d', '1iGb')]) && _0x293e1a[_0x55b2('4e', 'EUJq')](aibk[_0x55b2('4f', 'kBQF')][_0x55b2('50', '1iGb')], 'on') && config[_0x55b2('44', 'lO]v')] != '') {
                        if (_0x293e1a[_0x55b2('51', 'q@BX')](aibk['ads'][_0x55b2('52', 'k^bl')][_0x55b2('53', 'tpZ^')], '1')) {
                            if (_0x293e1a[_0x55b2('54', 'Q68x')](_0x293e1a[_0x55b2('55', '&weQ')], _0x55b2('56', '6qTG'))) {
                                var _0x1bdfab = _0x293e1a['NzHpp'][_0x55b2('57', 'DLNY')]('|'),
                                    _0x1161b7 = 0x0;
                                while (!![]) {
                                    switch (_0x1bdfab[_0x1161b7++]) {
                                        case '0':
                                            aibk['ad'] = new aiblog({
                                                'autoplay': !![],
                                                'element': document['getElementById'](_0x293e1a['sGDvr']),
                                                'theme': config['color'],
                                                'logo': config[_0x55b2('58', '9aCA')],
                                                'video': {
                                                    'url': url,
                                                    'pic': config['pic'],
                                                    'type': _0x293e1a['ebHrK']
                                                }
                                            });
                                            continue;
                                        case '1':
                                            aibk['ad']['on'](_0x293e1a[_0x55b2('59', 'h&f3')], function() {
                                                if (_0x17ae1a[_0x55b2('5a', 'HO35')](aibk['ad'][_0x55b2('5b', 'FD%[')][_0x55b2('5c', 'ljjg')], aibk['ad']['video']['duration'] - 0.1)) {
                                                    _0x17ae1a[_0x55b2('5d', 'A9kN')]($, _0x17ae1a['boVMb'])['removeClass'](_0x17ae1a[_0x55b2('5e', 'I!ON')]);
                                                    aibk['ad'][_0x55b2('5f', 'Vw#z')]();
                                                    _0x17ae1a[_0x55b2('60', '9E^K')]($, _0x55b2('61', 'EUJq'))['remove']();
                                                    _0x17ae1a[_0x55b2('62', 'Hnve')]($, '#ADtip')[_0x55b2('63', 'fi9R')]();
                                                    aibk[_0x55b2('64', 'tpZ^')](config[_0x55b2('65', 'A9kN')])
                                                }
                                            });
                                            continue;
                                        case '2':
                                            $(_0x55b2('66', 'EUJq'))[_0x55b2('67', 'sx3x')]();
                                            continue;
                                        case '3':
                                            $(_0x293e1a['aNcqY'])[_0x55b2('68', 'MxJI')]('danmu-off');
                                            continue;
                                        case '4':
                                            $(_0x293e1a[_0x55b2('69', '9E^K')])[_0x55b2('6a', 'EWS[')]();
                                            continue
                                    }
                                    break
                                }
                            } else {
                                aibk[_0x55b2('6b', '9aCA')]['vod'](aibk[_0x55b2('6c', '@e3Z')][_0x55b2('6d', '9E^K')][_0x55b2('6e', 'h&f3')][_0x55b2('6f', 'j&!c')], aibk['ads'][_0x55b2('70', 'A9kN')]['vod']['link'])
                            }
                        } else if (_0x293e1a['umjuw'](aibk[_0x55b2('71', 'HO35')][_0x55b2('72', 'bXlN')]['state'], '2')) {
                            if (_0x293e1a['ejZrL'](_0x293e1a['NwpTO'], _0x293e1a[_0x55b2('73', 'M0h5')])) {
                                aibk[_0x55b2('74', 'k4Eh')][_0x55b2('75', 'SeLh')](aibk[_0x55b2('76', 'EWS[')][_0x55b2('77', 'u9K(')][_0x55b2('78', '%nh[')][_0x55b2('79', 'P(et')], aibk[_0x55b2('7a', 'Hnve')][_0x55b2('7b', 'HmS@')][_0x55b2('7c', '0vlN')][_0x55b2('7d', '%nh[')], aibk[_0x55b2('7e', '6qTG')]['set']['pic']['img'])
                            } else {
                                var _0x31e265 = {
                                    'Svwqu': _0x293e1a[_0x55b2('7f', '&weQ')]
                                };
                                $[_0x55b2('80', 'FD%[')]({
                                    'type': _0x293e1a[_0x55b2('81', 'FD%[')],
                                    'url': _0x293e1a[_0x55b2('82', 'hO4W')](_0x293e1a[_0x55b2('83', 'wVm6')](_0x293e1a[_0x55b2('84', 'zJ7r')](_0x293e1a['nsJyf'](_0x293e1a['aXQUC'](_0x293e1a['eLbAG'](_0x293e1a[_0x55b2('85', 'dO7c')](_0x293e1a[_0x55b2('86', '0vlN')](_0x293e1a['MNwQN'](_0x293e1a[_0x55b2('87', 'EWS[')](config['api'], _0x293e1a['gnkMU']), d), _0x293e1a[_0x55b2('88', 'I!ON')]), a), _0x293e1a[_0x55b2('89', 'A9kN')]), type), _0x55b2('8a', 'sx3x')), b), _0x293e1a[_0x55b2('8b', 'kBQF')]), c),
                                    'cache': ![],
                                    'dataType': _0x293e1a['GkkfR'],
                                    'beforeSend': function() {},
                                    'success': function(_0x54065d) {
                                        layer[_0x55b2('8c', 'uGmG')](_0x17ae1a[_0x55b2('8d', 'I!ON')])
                                    },
                                    'error': function(_0x4f6402) {
                                        var _0xc3a17 = _0x31e265[_0x55b2('8e', 'hO4W')];
                                        layer[_0x55b2('8f', 'q@BX')](_0xc3a17)
                                    }
                                })
                            }
                        }
                    } else {
                        aibk[_0x55b2('90', '9E^K')](config[_0x55b2('91', 'HO35')])
                    }
                }
            })
        },
        'play': function(_0x3c9282) {
            var _0x1db530 = {
                'vzoLO': _0x55b2('92', '@e3Z'),
                'iswMl': function(_0x58ae0d, _0x3cfdf2) {
                    return _0x58ae0d(_0x3cfdf2)
                },
                'lBDEC': function(_0x369525, _0x326e85) {
                    return _0x369525 > _0x326e85
                },
                'YjLOd': function(_0x9c1bd) {
                    return _0x9c1bd()
                },
                'BMPIS': _0x55b2('93', 'FD%['),
                'XJXkj': function(_0x5f4ae2, _0x3f44d5) {
                    return _0x5f4ae2(_0x3f44d5)
                },
                'uSCzj': function(_0x57ac5a, _0x1a4003) {
                    return _0x57ac5a + _0x1a4003
                },
                'mEroS': function(_0x556c5a, _0x4b619c) {
                    return _0x556c5a + _0x4b619c
                },
                'wkxFu': function(_0xf1eb7, _0x1b62f1) {
                    return _0xf1eb7 + _0x1b62f1
                },
                'NFAaG': _0x55b2('94', 'HmS@'),
                'Jtxby': '"></a></div>',
                'QYOzo': function(_0x25047d, _0x2b0b3c) {
                    return _0x25047d(_0x2b0b3c)
                },
                'IEaDk': function(_0x2ebb2e, _0x38175e) {
                    return _0x2ebb2e(_0x38175e)
                },
                'WwkzP': _0x55b2('95', 'T4#C'),
                'BGEqF': _0x55b2('96', '@q!Z'),
                'jKnLM': _0x55b2('97', '@q!Z'),
                'tRZzv': _0x55b2('98', 'I!ON'),
                'IpqJj': function(_0x52a5c2, _0x91badf) {
                    return _0x52a5c2(_0x91badf)
                },
                'rPgnP': _0x55b2('99', 'Hnve'),
                'CLoeG': _0x55b2('9a', 'DLNY'),
                'RJGln': _0x55b2('9b', 'EWS['),
                'zcVKq': 'YLzWD',
                'rMVgk': function(_0x51ffdd, _0x13a9c0) {
                    return _0x51ffdd(_0x13a9c0)
                },
                'UbsLP': '.vod-pic',
                'AVSdy': function(_0x801949, _0x5219e9) {
                    return _0x801949 === _0x5219e9
                },
                'VNRFH': _0x55b2('9c', 'fi9R'),
                'NvQiG': 'AwiFk',
                'OPmWL': function(_0xd9cd4b, _0x25cb0f) {
                    return _0xd9cd4b !== _0x25cb0f
                },
                'AebAx': _0x55b2('9d', 'T4#C'),
                'RDbGy': function(_0x1f41a0, _0x2d9e0f) {
                    return _0x1f41a0 != _0x2d9e0f
                },
                'oUHnC': _0x55b2('9e', 'uGmG'),
                'DHIjo': _0x55b2('9f', 'Q68x'),
                'sUbsy': function(_0xbb5aba, _0x440a45) {
                    return _0xbb5aba !== _0x440a45
                },
                'WwCPO': _0x55b2('a0', 'T4#C'),
                'qGWCA': function(_0x31c14b, _0x23c147) {
                    return _0x31c14b(_0x23c147)
                },
                'WaqJr': 'click'
            };
            if (!danmuon) {
                if (_0x1db530[_0x55b2('a1', '6qTG')](_0x1db530[_0x55b2('a2', 'Q68x')], _0x1db530['NvQiG'])) {
                    d[_0x55b2('a3', 'u9K(')](_0x1db530[_0x55b2('a4', 'FD%[')], t)
                } else {
                    aibk[_0x55b2('a5', 'T4#C')][_0x55b2('a6', 'SeLh')](_0x3c9282)
                }
            } else {
                if (_0x1db530[_0x55b2('a7', '1iGb')]('VCLpE', _0x1db530['AebAx'])) {
                    if (_0x1db530[_0x55b2('a8', 'uGmG')](config['av'], '')) {
                        if (_0x1db530[_0x55b2('a9', '1iGb')](_0x1db530['oUHnC'], _0x1db530[_0x55b2('aa', 'I!ON')])) {
                            var _0x5f0832 = {
                                'Hmrsp': function(_0x201964, _0x2ef23b) {
                                    return _0x1db530['iswMl'](_0x201964, _0x2ef23b)
                                },
                                'YCPKz': function(_0x46ee54, _0x35ce53) {
                                    return _0x1db530[_0x55b2('ab', 'h&f3')](_0x46ee54, _0x35ce53)
                                },
                                'XDuil': function(_0x594dc7) {
                                    return _0x1db530[_0x55b2('ac', 'tpZ^')](_0x594dc7)
                                }
                            };
                            $(b)[_0x55b2('ad', 'zJ7r')](_0x1db530['BMPIS']);
                            _0x1db530[_0x55b2('ae', 'HZuu')]($, b)[_0x55b2('af', 'fi9R')](function() {
                                o = _0x5f0832[_0x55b2('b0', 'h&f3')]($, t)['val']();
                                if (_0x5f0832['YCPKz'](o, 0x0)) {
                                    yzmck['set'](c, 0x0)
                                } else {
                                    _0x5f0832[_0x55b2('b1', 'dO7c')](er)
                                }
                            })
                        } else {
                            aibk['player']['bdplay'](_0x3c9282)
                        }
                    } else {
                        if (_0x1db530[_0x55b2('b2', '0vlN')](_0x1db530[_0x55b2('b3', 'k4Eh')], _0x1db530[_0x55b2('b4', 'M0h5')])) {
                            if (e[_0x55b2('b5', 'DLNY')] == 0xd) {
                                _0x1db530[_0x55b2('b6', 'j&!c')](k)
                            }
                        } else {
                            aibk['player'][_0x55b2('b7', 'Hnve')](_0x3c9282)
                        }
                    }
                } else {
                    var _0x36ad9e = _0x1db530[_0x55b2('b8', 'tpZ^')](_0x1db530['mEroS'](_0x1db530[_0x55b2('b9', 'T4#C')](_0x1db530[_0x55b2('ba', '%nh[')](_0x1db530[_0x55b2('bb', 'Wz)S')], l), '" target="_blank"><img src="'), p), _0x1db530[_0x55b2('bc', 'Hnve')]);
                    _0x1db530[_0x55b2('bd', '9E^K')]($, _0x55b2('be', 'j&!c'))[_0x55b2('bf', 'sx3x')](_0x36ad9e)
                }
            }
            _0x1db530[_0x55b2('c0', 'T4#C')]($, function() {
                var _0x3a5dd1 = {
                    'eYnnh': function(_0x4b46a5, _0x262357) {
                        return _0x1db530['IEaDk'](_0x4b46a5, _0x262357)
                    },
                    'YkSiv': _0x1db530['BGEqF'],
                    'QrChT': _0x1db530[_0x55b2('c1', 'HO35')]
                };
                $(_0x1db530['tRZzv'])['on'](_0x55b2('c2', 'iNik'), function() {
                    _0x3a5dd1[_0x55b2('c3', 'Q68x')]($, _0x3a5dd1[_0x55b2('c4', 'M0h5')])[_0x55b2('c5', 'MxJI')](_0x3a5dd1[_0x55b2('c6', '9aCA')])
                });
                _0x1db530['IpqJj']($, _0x1db530[_0x55b2('c7', 'ljjg')])[_0x55b2('c8', 'zJ7r')](function() {
                    _0x1db530[_0x55b2('c9', '1iGb')]($, _0x1db530[_0x55b2('ca', 'dO7c')])['text'](_0x1db530[_0x55b2('cb', 'lO]v')]($, this)[_0x55b2('cc', '@e3Z')]())
                })
            });
            _0x1db530['qGWCA']($, _0x55b2('cd', 'MxJI'))['on'](_0x1db530[_0x55b2('ce', 'DLNY')], function() {
                if ('YLzWD' === _0x1db530['zcVKq']) {
                    aibk['dp'][_0x55b2('cf', 'HZuu')][_0x55b2('d0', 'HbCg')]()
                } else {
                    var _0x35b6a3 = _0x55b2('d1', 'hO4W');
                    _0x35b6a3 += _0x1db530[_0x55b2('d2', '1iGb')];
                    _0x35b6a3 += '</style>';
                    _0x1db530['IpqJj']($, _0x1db530['RJGln'])[_0x55b2('d3', 'fS)C')](_0x35b6a3)['addClass']('')
                }
            });
            $(_0x55b2('d4', 'I!ON'))['on'](_0x1db530[_0x55b2('d5', 'P(et')], function() {
                aibk['dp'][_0x55b2('d6', 'h&f3')]();
                _0x1db530['rMVgk']($, _0x1db530[_0x55b2('d7', '@e3Z')])['remove']()
            });
            if (_0x1db530[_0x55b2('d8', '9aCA')](config[_0x55b2('d9', 'iNik')], '')) {
                $(_0x55b2('da', 'MxJI'))[_0x55b2('db', 'kBQF')](_0x1db530[_0x55b2('dc', 'HZuu')](_0x1db530[_0x55b2('dd', 'HbCg')](config['title'], '  '), config[_0x55b2('de', 'lO]v')]))
            }
        },
        'dmid': function() {
            var _0x41b921 = {
                'BjzqX': function(_0x227ceb, _0x27599b) {
                    return _0x227ceb + _0x27599b
                },
                'FdwSb': _0x55b2('df', 'A9kN'),
                'YpxRY': _0x55b2('e0', 'HO35'),
                'dgBlR': function(_0x40acca, _0x5ea786) {
                    return _0x40acca(_0x5ea786)
                },
                'ofwos': '#vod-title',
                'zWxyh': function(_0x42641e, _0x5e5e6a) {
                    return _0x42641e(_0x5e5e6a)
                },
                'RvSWi': function(_0x17c762, _0x5e8218) {
                    return _0x17c762 !== _0x5e8218
                },
                'fwolA': 'GKyau',
                'mXZqR': function(_0x722690, _0xda8ec3) {
                    return _0x722690 == _0xda8ec3
                }
            };
            var _0x484282 = _0x41b921['zWxyh'](md5, config[_0x55b2('e1', 'HZuu')]);
            if (_0x484282 == 0x0 && config['id'] != '') {
                if (_0x41b921[_0x55b2('e2', 'wVm6')](_0x41b921[_0x55b2('e3', '9x[3')], _0x41b921[_0x55b2('e4', 'HbCg')])) {
                    var _0x1872af = _0x41b921[_0x55b2('e5', 'A9kN')](_0x41b921[_0x55b2('e6', 'HO35')] + up[_0x55b2('e7', 'HbCg')][i], _0x41b921[_0x55b2('e8', 'dO7c')]);
                    _0x41b921[_0x55b2('e9', 'fS)C')]($, _0x41b921['ofwos'])[_0x55b2('ea', 'MxJI')](_0x1872af)
                } else {
                    a = config['id'], b = config[_0x55b2('eb', 'A9kN')]
                }
            } else if (_0x41b921['mXZqR'](_0x484282, 0x1) || !config['id']) {
                a = _0x484282, b = _0x484282
            }
            aibk['id'] = a[_0x55b2('ec', 'fi9R')](0x2, 0x8)
        },
        'load': function() {
            var _0x24af39 = {
                'YFnWy': function(_0x23cd79, _0x11e279) {
                    return _0x23cd79(_0x11e279)
                },
                'jETmN': _0x55b2('ed', 'uGmG'),
                'iuklZ': function(_0xce3838, _0x5a75c6) {
                    return _0xce3838 + _0x5a75c6
                },
                'eLoeC': function(_0x25a6c9, _0x3b57fe) {
                    return _0x25a6c9 === _0x3b57fe
                },
                'RxUHq': function(_0x349acc, _0x58d579) {
                    return _0x349acc(_0x58d579)
                },
                'vtKco': _0x55b2('ee', 'EUJq'),
                'IsXJM': '已为您跳过片头',
                'QiDUs': function(_0x2a3882, _0x37c68b) {
                    return _0x2a3882 !== _0x37c68b
                },
                'hbUZf': _0x55b2('ef', 'MxJI'),
                'aLtNf': '#link3,#span',
                'aFDyP': function(_0x4431af, _0x1e2602, _0x559dea) {
                    return _0x4431af(_0x1e2602, _0x559dea)
                },
                'XIrED': function(_0x2fcc7b, _0x48b406) {
                    return _0x2fcc7b * _0x48b406
                },
                'KmUCp': function(_0x18ce57, _0xaf8c15) {
                    return _0x18ce57 * _0xaf8c15
                },
                'zLfzo': _0x55b2('f0', '9E^K'),
                'zdBHJ': _0x55b2('f1', 'uGmG'),
                'EEypN': _0x55b2('f2', '%nh[')
            };
            setTimeout(function() {
                _0x24af39['YFnWy']($, _0x24af39[_0x55b2('f3', 'HmS@')])['fadeIn']()
            }, 0x64);
            _0x24af39[_0x55b2('f4', 'A9kN')](setTimeout, function() {
                var _0x3daa75 = {
                    'YvlUT': function(_0x5425b8, _0x4d1bd5) {
                        return _0x24af39[_0x55b2('f5', 'HZuu')](_0x5425b8, _0x4d1bd5)
                    }
                };
                if (_0x24af39[_0x55b2('f6', 'P(et')]('sbUvw', _0x55b2('f7', 'sx3x'))) {
                    _0x24af39['RxUHq']($, _0x55b2('f8', '@e3Z'))['fadeIn']()
                } else {
                    top[_0x55b2('f9', 'dO7c')]['href'] = _0x3daa75[_0x55b2('fa', '&weQ')](up['mylink'], '/index.php/user/login.html')
                }
            }, 0x1f4);
            _0x24af39['aFDyP'](setTimeout, function() {
                $(_0x24af39[_0x55b2('fb', 'FD%[')])[_0x55b2('fc', 'q@BX')]()
            }, _0x24af39[_0x55b2('fd', 'ljjg')](0x1, 0x3e8));
            setTimeout(function() {
                var _0x41857c = {
                    'TMnjj': _0x24af39['IsXJM']
                };
                if (_0x24af39['QiDUs'](_0x55b2('fe', 'EUJq'), _0x24af39[_0x55b2('ff', '0vlN')])) {
                    _0x24af39[_0x55b2('100', 'bXlN')]($, _0x24af39[_0x55b2('101', '@e3Z')])[_0x55b2('102', 'I!ON')]()
                } else {
                    aibk['dp'][_0x55b2('103', '@q!Z')](aibk[_0x55b2('104', '&weQ')]);
                    aibk['dp'][_0x55b2('105', 'k^bl')](_0x41857c[_0x55b2('106', 'bXlN')])
                }
            }, _0x24af39['KmUCp'](0x2, 0x3e8));
            if (aibk[_0x55b2('107', 'M0h5')][_0x55b2('108', 'q@BX')] && (aibk['versions'][_0x55b2('109', 'fS)C')] || aibk['versions'][_0x55b2('10a', 'ljjg')])) {
                var _0xd9b377 = _0x55b2('10b', 'zJ7r');
                _0xd9b377 += _0x24af39[_0x55b2('10c', 'u9K(')];
                _0xd9b377 += _0x24af39[_0x55b2('10d', 'T4#C')];
                $(_0x24af39[_0x55b2('10e', 'u9K(')])['append'](_0xd9b377)['addClass']('')
            }
            aibk[_0x55b2('10f', 'iNik')]['send']();
            aibk[_0x55b2('110', 'MxJI')][_0x55b2('111', '1iGb')]();
            aibk[_0x55b2('112', 'hO4W')]();
            aibk[_0x55b2('113', '@q!Z')][_0x55b2('114', 'zJ7r')]();
            aibk['dp'][_0x55b2('115', 'ljjg')][_0x55b2('116', 'bXlN')](0x1)
        },
        'def': function() {
            var _0x36ffb1 = {
                'NiwSw': '?ac=dm',
                'dhtEq': 'VtxWR',
                'ZgFEf': _0x55b2('117', 'hO4W'),
                'iFQfo': function(_0x4cd954, _0x21d9e9) {
                    return _0x4cd954(_0x21d9e9)
                },
                'qLFFh': _0x55b2('118', 'A9kN'),
                'FcqhP': function(_0x58043f, _0x54f3c6) {
                    return _0x58043f + _0x54f3c6
                },
                'XTlKa': function(_0x23c003, _0x34120c) {
                    return _0x23c003(_0x34120c)
                },
                'cEbLa': _0x55b2('119', 'Q68x'),
                'YLHsf': function(_0x2a3c52, _0x41be6d) {
                    return _0x2a3c52 === _0x41be6d
                },
                'ToqPF': _0x55b2('11a', 'Hnve'),
                'oFyJp': function(_0x3fb8e4, _0x4c060a) {
                    return _0x3fb8e4(_0x4c060a)
                },
                'OGHkg': function(_0x536f74, _0x378195) {
                    return _0x536f74 > _0x378195
                },
                'HZEdU': function(_0x13144c) {
                    return _0x13144c()
                },
                'ItSuR': _0x55b2('11b', 'h&f3'),
                'DrIpe': _0x55b2('11c', 'Q68x'),
                'twTVp': function(_0x233f23, _0x329c1f) {
                    return _0x233f23 + _0x329c1f
                },
                'bPyXM': function(_0x26f252, _0x16db26) {
                    return _0x26f252 === _0x16db26
                },
                'oRcyb': 'gGGZt',
                'fXtNR': _0x55b2('11d', 'iNik'),
                'FBmbh': _0x55b2('11e', 'sx3x'),
                'sGYtS': _0x55b2('11f', 'dO7c'),
                'WFPVr': _0x55b2('120', '9aCA'),
                'VRUCB': _0x55b2('121', '9E^K'),
                'fOwHi': _0x55b2('122', 'Vw#z'),
                'dvTDM': 'pause',
                'kJLov': _0x55b2('123', 'kBQF')
            };
            aibk[_0x55b2('124', 'Hnve')] = 0x0;
            aibk[_0x55b2('125', 'A9kN')] = yzmck[_0x55b2('126', 'bXlN')](_0x36ffb1[_0x55b2('127', 'HmS@')]);
            aibk[_0x55b2('128', '9E^K')] = yzmck[_0x55b2('129', 'HO35')](_0x36ffb1[_0x55b2('12a', '@e3Z')]);
            aibk[_0x55b2('12b', '0vlN')] = _0x36ffb1['twTVp'](_0x36ffb1['oFyJp'](parseInt, aibk['lastt']), 0xa);
            aibk[_0x55b2('12c', 'Vw#z')] = yzmck['get'](_0x55b2('12d', 'HbCg'));
            aibk[_0x55b2('12e', '9aCA')] = yzmck[_0x55b2('129', 'HO35')](_0x36ffb1['sGYtS']);
            aibk[_0x55b2('12f', 'wVm6')] = Number(aibk[_0x55b2('130', 'k4Eh')](_0x36ffb1[_0x55b2('131', 'kBQF')] + config['url']));
            aibk[_0x55b2('132', 'k4Eh')] = aibk[_0x55b2('133', 'Wz)S')](aibk[_0x55b2('134', 'A9kN')]);
            aibk['dp']['on'](_0x36ffb1[_0x55b2('135', 'hO4W')], function() {
                aibk[_0x55b2('136', 'h&f3')]()
            });
            aibk['dp']['on'](_0x36ffb1[_0x55b2('137', 'T4#C')], function() {
                if (_0x36ffb1[_0x55b2('138', 'I!ON')] === _0x36ffb1['ZgFEf']) {
                    aibk[_0x55b2('139', 'j&!c')]();
                    aibk['dp'] = new aiblog({
                        'autoplay': ![],
                        'element': document['getElementById'](_0x55b2('13a', '@q!Z')),
                        'theme': config['color'],
                        'logo': config['logo'],
                        'video': {
                            'url': url,
                            'pic': config[_0x55b2('13b', '9aCA')],
                            'type': 'auto'
                        },
                        'danmaku': {
                            'id': aibk['id'],
                            'api': config[_0x55b2('13c', 'MxJI')] + _0x36ffb1[_0x55b2('13d', 'fi9R')],
                            'user': config[_0x55b2('13e', 'sx3x')]
                        }
                    });
                    aibk[_0x55b2('13f', 'EWS[')]()
                } else {
                    aibk[_0x55b2('140', 'Hnve')]()
                }
            });
            aibk['dp']['on'](_0x36ffb1['dvTDM'], function() {
                var _0x120988 = {
                    'iRKVs': _0x36ffb1[_0x55b2('141', 'j&!c')]
                };
                if (_0x36ffb1[_0x55b2('142', '9x[3')](_0x36ffb1[_0x55b2('143', 'Q68x')], _0x36ffb1[_0x55b2('144', '1iGb')])) {
                    aibk[_0x55b2('145', 'EUJq')][_0x55b2('146', 'dO7c')][_0x55b2('147', '9x[3')](aibk[_0x55b2('148', 'iNik')][_0x55b2('149', 'HZuu')][_0x55b2('14a', 'h&f3')], aibk['ads'][_0x55b2('14b', 'bXlN')]['pic'])
                } else {
                    _0x36ffb1[_0x55b2('14c', 'k4Eh')]($, _0x36ffb1[_0x55b2('14d', '%nh[')])[_0x55b2('14e', '9aCA')](_0x36ffb1[_0x55b2('14f', 'HO35')](_0x55b2('150', 'HmS@'), l) + _0x55b2('151', 'uGmG'));
                    _0x36ffb1[_0x55b2('152', 'EWS[')]($, '#ADplayer')[_0x55b2('153', 'U3CT')](function() {
                        document[_0x55b2('154', 'fS)C')](_0x120988[_0x55b2('155', 'Hnve')])[_0x55b2('156', 'kBQF')]()
                    });
                    aibk['player'][_0x55b2('157', 'Vw#z')](u)
                }
            });
            aibk['dp']['on'](_0x55b2('158', 'sx3x'), function() {
                if (_0x36ffb1['YLHsf'](_0x36ffb1['ItSuR'], _0x36ffb1[_0x55b2('159', 'k4Eh')])) {
                    o = _0x36ffb1[_0x55b2('15a', 'kBQF')]($, t)['val']();
                    if (_0x36ffb1['OGHkg'](o, 0x0)) {
                        yzmck['set'](c, 0x1)
                    } else {
                        _0x36ffb1[_0x55b2('15b', 'EUJq')](er)
                    }
                } else {
                    aibk['MYad']['pause'][_0x55b2('15c', 'ljjg')]()
                }
            });
            aibk['dp']['on'](_0x36ffb1[_0x55b2('15d', 'P(et')], function(_0x2e073f) {
                if (_0x36ffb1[_0x55b2('15e', 'FD%[')]('hOFvE', _0x36ffb1[_0x55b2('15f', 'tpZ^')])) {
                    layer[_0x55b2('160', '6qTG')](_0x36ffb1['twTVp'](_0x55b2('161', 'T4#C'), config[_0x55b2('162', 'P(et')]) + '秒~');
                    return
                } else {
                    aibk[_0x55b2('163', '1iGb')]()
                }
            });
            aibk[_0x55b2('164', 'EWS[')][_0x55b2('165', 'zJ7r')]()
        },
        'video': {
            'play': function() {
                var _0x18401a = {
                    'FwVLM': function(_0x5bd428, _0x16d3d8) {
                        return _0x5bd428(_0x16d3d8)
                    },
                    'zWNWh': '#vodtitle',
                    'TEzSO': function(_0x221cbc, _0x449cb2) {
                        return _0x221cbc + _0x449cb2
                    },
                    'dXQJM': function(_0x37f635, _0x2e9d56) {
                        return _0x37f635 === _0x2e9d56
                    },
                    'WTEit': 'GOPfM',
                    'zeXcE': '#link3',
                    'XVbkN': function(_0x162626, _0x17ce72) {
                        return _0x162626 * _0x17ce72
                    }
                };
                $(_0x18401a['zeXcE'])[_0x55b2('166', 'P(et')]('视频已准备就绪，即将为您播放');
                setTimeout(function() {
                    if (_0x18401a[_0x55b2('167', 'uGmG')]('REAlW', _0x18401a[_0x55b2('168', 'tpZ^')])) {
                        _0x18401a[_0x55b2('169', 'M0h5')]($, _0x18401a['zWNWh'])['html'](_0x18401a[_0x55b2('16a', 'U3CT')](_0x18401a[_0x55b2('16b', '@q!Z')](config[_0x55b2('16c', 'j&!c')], '  '), config['sid']))
                    } else {
                        aibk['dp'][_0x55b2('16d', '0vlN')]();
                        _0x18401a['FwVLM']($, '#loading-box')[_0x55b2('16e', '&weQ')]();
                        aibk[_0x55b2('16f', '6qTG')][_0x55b2('170', 'HbCg')]()
                    }
                }, _0x18401a[_0x55b2('171', 'SeLh')](0x1, 0x5dc))
            },
            'next': function() {
                var _0x4c85ad = {
                    'xGflM': function(_0x227c9f, _0x408971) {
                        return _0x227c9f(_0x408971)
                    },
                    'pXlSO': function(_0x5ddb5f, _0x107ee4) {
                        return _0x5ddb5f > _0x107ee4
                    },
                    'amquW': function(_0x223081) {
                        return _0x223081()
                    },
                    'FNIzT': function(_0x110a14, _0x4495a3) {
                        return _0x110a14 != _0x4495a3
                    },
                    'aeaxp': _0x55b2('172', 'T4#C'),
                    'DnoSB': _0x55b2('173', 'EWS[')
                };
                if (_0x4c85ad[_0x55b2('174', 'MxJI')](parent[_0x55b2('175', '9E^K')][_0x55b2('176', 'A9kN')], '')) {
                    if (_0x4c85ad[_0x55b2('177', 'fS)C')] === _0x4c85ad['aeaxp']) {
                        top[_0x55b2('178', 'u9K(')]['href'] = parent[_0x55b2('179', 'zJ7r')][_0x55b2('17a', 'HbCg')]
                    } else {
                        o = _0x4c85ad['xGflM']($, t)[_0x55b2('17b', 'fi9R')]();
                        if (_0x4c85ad[_0x55b2('17c', 'A9kN')](o, 0x0)) {
                            yzmck[_0x55b2('17d', 'uGmG')](c, 0x0)
                        } else {
                            _0x4c85ad[_0x55b2('17e', 'EUJq')](er)
                        }
                    }
                } else {
                    layer[_0x55b2('17f', '0vlN')](_0x4c85ad['DnoSB'])
                }
            },
            'try': function() {
                var _0x4ffd17 = {
                    'orknT': function(_0x425143, _0x141086) {
                        return _0x425143 + _0x141086
                    },
                    'aYNfX': _0x55b2('180', 'T4#C'),
                    'ocZgM': _0x55b2('181', 'T4#C'),
                    'kKkwK': '/index.php/user/reg.html',
                    'OhliI': function(_0x1e9289, _0x3abae8) {
                        return _0x1e9289 * _0x3abae8
                    },
                    'yMNwG': function(_0x36681c, _0x7f0b41) {
                        return _0x36681c > _0x7f0b41
                    },
                    'agpVY': _0x55b2('182', '9E^K'),
                    'NYaAu': _0x55b2('183', 'M0h5'),
                    'RylcN': '温馨提示',
                    'wZxwE': function(_0x4e5c77, _0x3fd3f0, _0x2c76bf) {
                        return _0x4e5c77(_0x3fd3f0, _0x2c76bf)
                    },
                    'nosKK': function(_0x97c7f2, _0x350090) {
                        return _0x97c7f2 < _0x350090
                    },
                    'AdKPd': function(_0x355836, _0x46dc75) {
                        return _0x355836 != _0x46dc75
                    },
                    'ADLRe': function(_0x4e2709, _0x2de8e1) {
                        return _0x4e2709 === _0x2de8e1
                    },
                    'ZgUyQ': _0x55b2('184', 'DLNY'),
                    'ZnksK': _0x55b2('185', 'j&!c'),
                    'nLflK': function(_0x315037, _0x34c54a, _0x40a8ab) {
                        return _0x315037(_0x34c54a, _0x40a8ab)
                    }
                };
                if (_0x4ffd17[_0x55b2('186', 'T4#C')](up[_0x55b2('187', 'wVm6')], 0x0) && _0x4ffd17[_0x55b2('188', 'HO35')](config[_0x55b2('189', 'DLNY')], config['group_x']) && _0x4ffd17[_0x55b2('18a', '6qTG')](config[_0x55b2('18b', '9aCA')], '')) {
                    if (_0x4ffd17[_0x55b2('18c', 'HZuu')](_0x4ffd17[_0x55b2('18d', 'MxJI')], _0x55b2('18e', '6qTG'))) {
                        $('#dmtext')['attr']({
                            'disabled': !![],
                            'placeholder': _0x4ffd17[_0x55b2('18f', 'uGmG')]
                        });
                        _0x4ffd17[_0x55b2('190', 'tpZ^')](setInterval, function() {
                            var _0x369011 = {
                                'eztNT': _0x4ffd17[_0x55b2('191', 'h&f3')],
                                'ATtlo': _0x4ffd17[_0x55b2('192', 'Vw#z')]
                            };
                            var _0x33aaf0 = _0x4ffd17[_0x55b2('193', 'FD%[')](up['trysee'], 0x3c);
                            var _0x182963 = aibk['dp'][_0x55b2('194', 'fS)C')][_0x55b2('195', 'u9K(')];
                            if (_0x4ffd17['yMNwG'](_0x182963, _0x33aaf0)) {
                                if (_0x4ffd17['agpVY'] !== _0x4ffd17[_0x55b2('196', 'Wz)S')]) {
                                    aibk['jump_f'] = 0x1
                                } else {
                                    aibk['dp'][_0x55b2('197', 'SeLh')][_0x55b2('198', 'M0h5')] = 0x0;
                                    aibk['dp'][_0x55b2('199', '9aCA')]();
                                    layer[_0x55b2('19a', 'dO7c')](up['trysee'] + _0x4ffd17[_0x55b2('19b', 'Q68x')], {
                                        'anim': 0x1,
                                        'title': _0x4ffd17[_0x55b2('19c', 'zJ7r')],
                                        'btn': ['登录', '注册'],
                                        'yes': function(_0x4dd177, _0x15e26f) {
                                            top['location'][_0x55b2('19d', 'Vw#z')] = _0x4ffd17[_0x55b2('19e', 'Q68x')](up[_0x55b2('19f', 'SeLh')], _0x4ffd17[_0x55b2('1a0', 'M0h5')])
                                        },
                                        'btn2': function(_0x225540, _0x55edf7) {
                                            if (_0x369011[_0x55b2('1a1', 'MxJI')] === _0x369011['eztNT']) {
                                                top[_0x55b2('1a2', '@e3Z')][_0x55b2('1a3', 'HmS@')] = up['mylink'] + _0x369011[_0x55b2('1a4', 'HO35')]
                                            } else {
                                                er()
                                            }
                                        }
                                    })
                                }
                            }
                        }, 0x3e8)
                    } else {
                        _0x4ffd17['wZxwE'](setTimeout, function() {
                            aibk[_0x55b2('5b', 'FD%[')][_0x55b2('1a5', 'Q68x')]()
                        }, _0x4ffd17[_0x55b2('1a6', 'q@BX')](0x1, 0x3e8))
                    }
                }
            },
            'seek': function() {
                aibk['dp'][_0x55b2('1a7', 'I!ON')](aibk[_0x55b2('1a8', '9E^K')])
            },
            'end': function() {
                var _0x35b0eb = {
                    'iTTGx': _0x55b2('1a9', 'k^bl')
                };
                layer[_0x55b2('1aa', 'M0h5')](_0x35b0eb[_0x55b2('1ab', 'zJ7r')])
            },
            'con_play': function() {
                var _0x54c42d = {
                    'KSarP': function(_0x3c7003, _0x3ec732) {
                        return _0x3c7003 == _0x3ec732
                    },
                    'XHMpM': function(_0x42b05f, _0x4e6873) {
                        return _0x42b05f(_0x4e6873)
                    },
                    'HmxUg': function(_0x53ff21, _0x400948) {
                        return _0x53ff21(_0x400948)
                    },
                    'zVkpH': function(_0x46d74e, _0x268bf7) {
                        return _0x46d74e !== _0x268bf7
                    },
                    'gKHGb': 'Xhcyz',
                    'OBzQv': '.memory-play-wrap',
                    'JFwgh': function(_0x4f092d, _0x1b45c8) {
                        return _0x4f092d(_0x1b45c8)
                    },
                    'NMXHj': '#loading-box',
                    'DllGh': _0x55b2('1ac', 'I!ON'),
                    'UqSzt': 'num',
                    'cozyf': function(_0x491768, _0x1295be) {
                        return _0x491768(_0x1295be)
                    },
                    'pDeBb': _0x55b2('1ad', 'k4Eh'),
                    'WnyqF': _0x55b2('1ae', 'wVm6'),
                    'bilWV': 'click',
                    'NAgZv': function(_0x16f229, _0x5e302a, _0x35a77b) {
                        return _0x16f229(_0x5e302a, _0x35a77b)
                    },
                    'UqMOD': _0x55b2('1af', '@e3Z'),
                    'yyhZL': _0x55b2('1b0', '0vlN')
                };
                if (!danmuon) {
                    aibk['jump']['head']()
                } else {
                    var _0x113661 = _0x55b2('1b1', 'HZuu') + aibk[_0x55b2('1b2', 'HmS@')] + _0x55b2('1b3', 'I!ON') + aibk[_0x55b2('1b4', 'uGmG')] + '</i>s</d><d class="conplaying">否</d>';
                    $(_0x55b2('1b5', 'k^bl'))[_0x55b2('1b6', 'HmS@')](_0x113661);
                    var _0x11bfd2 = document[_0x55b2('1b7', '&weQ')](_0x54c42d[_0x55b2('1b8', 'U3CT')]);
                    var _0x40dbfd = _0x11bfd2[_0x55b2('1b9', 'h&f3')];
                    var _0xa75428 = null;
                    setTimeout(function() {
                        _0xa75428 = setInterval(function() {
                            _0x40dbfd--;
                            _0x11bfd2[_0x55b2('1ba', 'DLNY')] = _0x40dbfd;
                            if (_0x54c42d[_0x55b2('1bb', 'fi9R')](_0x40dbfd, 0x0)) {
                                _0x54c42d[_0x55b2('1bc', '0vlN')](clearInterval, _0xa75428);
                                aibk[_0x55b2('1bd', 'zJ7r')][_0x55b2('1be', 'k4Eh')]();
                                aibk['dp'][_0x55b2('1bf', 'U3CT')]();
                                _0x54c42d[_0x55b2('1c0', 'k^bl')]($, _0x55b2('1c1', '@q!Z'))['remove']()
                            }
                        }, 0x3e8)
                    }, 0x1)
                };
                var _0x1fab67 = '<div class="memory-play-wrap"><div class="memory-play"><span class="close">×</span><span>上次看到 </span><span>' + aibk[_0x55b2('1c2', 'h&f3')] + _0x55b2('1c3', '9x[3');
                _0x54c42d[_0x55b2('1c4', 'j&!c')]($, _0x54c42d[_0x55b2('1c5', 'k4Eh')])[_0x55b2('d3', 'fS)C')](_0x1fab67);
                _0x54c42d[_0x55b2('1c6', 'A9kN')]($, _0x54c42d[_0x55b2('1c7', 'DLNY')])['on'](_0x54c42d[_0x55b2('1c8', 'M0h5')], function() {
                    var _0x2afeb7 = {
                        'Hbvku': _0x55b2('1c9', 'k^bl')
                    };
                    if (_0x54c42d[_0x55b2('1ca', '%nh[')]('Xhcyz', _0x54c42d[_0x55b2('1cb', 'DLNY')])) {
                        layer[_0x55b2('1cc', 'h&f3')](_0x2afeb7[_0x55b2('1cd', '9aCA')])
                    } else {
                        _0x54c42d[_0x55b2('1ce', 'DLNY')]($, _0x55b2('1cf', 'hO4W'))[_0x55b2('1d0', 'HO35')]()
                    }
                });
                _0x54c42d[_0x55b2('1d1', 'T4#C')](setTimeout, function() {
                    _0x54c42d['HmxUg']($, _0x54c42d['OBzQv'])['remove']()
                }, 0x14 * 0x3e8);
                _0x54c42d['cozyf']($, _0x54c42d[_0x55b2('1d2', 'HmS@')])['on'](_0x54c42d[_0x55b2('1d3', 'EWS[')], function() {
                    clearTimeout(_0xa75428);
                    _0x54c42d[_0x55b2('1d4', '%nh[')]($, _0x54c42d['NMXHj'])[_0x55b2('1d5', 'M0h5')]();
                    aibk['dp']['play']();
                    aibk[_0x55b2('1d6', 'I!ON')][_0x55b2('1d7', '1iGb')]()
                });
                $(_0x54c42d[_0x55b2('1d8', 'lO]v')])['on'](_0x54c42d[_0x55b2('1d9', 'tpZ^')], function() {
                    _0x54c42d[_0x55b2('1da', 'SeLh')](clearTimeout, _0xa75428);
                    aibk['video']['seek']();
                    $(_0x54c42d['DllGh'])[_0x55b2('1db', 'q@BX')]();
                    aibk['dp'][_0x55b2('1dc', 'A9kN')]()
                })
            }
        },
        'jump': {
            'def': function() {
                var _0x2dcbdb = {
                    'ZgVpl': '请输入有效时间哟！',
                    'ljcOC': _0x55b2('1dd', '&weQ'),
                    'bTrMN': function(_0x1e5996, _0x1e4e52) {
                        return _0x1e5996 === _0x1e4e52
                    },
                    'FUEfS': _0x55b2('1de', '9E^K'),
                    'Ctycc': _0x55b2('1df', '%nh['),
                    'GJTfL': function(_0x402a0e, _0x43dc48) {
                        return _0x402a0e > _0x43dc48
                    },
                    'xTBKk': function(_0x16f588) {
                        return _0x16f588()
                    },
                    'iIvEE': function(_0x10bce9, _0x2733e5) {
                        return _0x10bce9 !== _0x2733e5
                    },
                    'dDqki': _0x55b2('1e0', 'sx3x'),
                    'MiBgr': function(_0x586ba5, _0x204548) {
                        return _0x586ba5(_0x204548)
                    },
                    'HiKed': function(_0x38456b, _0x5ca340) {
                        return _0x38456b == _0x5ca340
                    },
                    'uQCYb': '举报成功！感谢您为守护弹幕作出了贡献',
                    'sMQOx': 'yAqlv',
                    'LmJyS': function(_0x4e5c3a, _0x4c2d45) {
                        return _0x4e5c3a !== _0x4c2d45
                    },
                    'pRfJx': _0x55b2('1e1', '@q!Z'),
                    'AVhSp': _0x55b2('1e2', 'HZuu'),
                    'TeoJz': function(_0x59bd61) {
                        return _0x59bd61()
                    },
                    'ndNGY': _0x55b2('1e3', 'lO]v'),
                    'CLNwz': function(_0x454c59, _0x140244) {
                        return _0x454c59(_0x140244)
                    },
                    'NhitW': 'xtbgQ',
                    'vdIHr': _0x55b2('1e4', 'HO35'),
                    'mSDCc': _0x55b2('1e5', 'kBQF'),
                    'LYSst': function(_0x230861, _0x8cd283, _0x2413d1, _0x693eb0, _0x484805, _0x19a342, _0x3ac77f) {
                        return _0x230861(_0x8cd283, _0x2413d1, _0x693eb0, _0x484805, _0x19a342, _0x3ac77f)
                    },
                    'tNeoq': 'frists',
                    'pamYw': 'headt',
                    'lhlqv': _0x55b2('1e6', 'h&f3'),
                    'WIgky': function(_0x3454f9, _0x2c3c81) {
                        return _0x3454f9(_0x2c3c81)
                    }
                };
                h = _0x55b2('1e7', 'Hnve');
                l = _0x2dcbdb[_0x55b2('1e8', 'q@BX')];
                f = _0x55b2('1e9', 'HbCg');
                j = _0x2dcbdb['mSDCc'];
                _0x2dcbdb['LYSst'](_0x58d8cf, h, _0x2dcbdb[_0x55b2('1ea', 'q@BX')], aibk[_0x55b2('12d', 'HbCg')], _0x2dcbdb['pamYw'], aibk[_0x55b2('1eb', 'kBQF')], f);
                _0x2dcbdb['LYSst'](_0x58d8cf, l, 'lasts', aibk[_0x55b2('1ec', 'HZuu')], _0x2dcbdb[_0x55b2('1ed', 'DLNY')], aibk['lastt'], j);

                function _0x559199() {
                    layer[_0x55b2('1ee', '%nh[')](_0x2dcbdb[_0x55b2('1ef', 'fi9R')])
                }

                function _0x1fcdb3() {
                    if (_0x2dcbdb[_0x55b2('1f0', 'h&f3')](_0x2dcbdb[_0x55b2('1f1', 'j&!c')], _0x55b2('1f2', 'Wz)S'))) {
                        var _0x18097d = {
                            'qZtIo': _0x2dcbdb[_0x55b2('1f3', 'k^bl')]
                        };
                        setTimeout(function() {
                            if (!danmuon) {
                                aibk[_0x55b2('1f4', 'Hnve')][_0x55b2('1f5', 'MxJI')]()
                            } else {
                                aibk['dp'][_0x55b2('1f6', '0vlN')](_0x18097d[_0x55b2('1f7', 'DLNY')]);
                                aibk[_0x55b2('1f8', 'MxJI')]['play']()
                            }
                        }, 0x1 * 0x3e8)
                    } else {
                        layer['msg'](_0x2dcbdb[_0x55b2('1f9', 'k^bl')])
                    }
                }

                function _0x58d8cf(_0x17dbe7, _0x5204d4, _0x3635a7, _0x4fc9a2, _0x1e71fa, _0x3394a6) {
                    var _0x59c8a0 = {
                        'zhqqb': function(_0xdd88f7, _0x10eb5d) {
                            return _0x2dcbdb[_0x55b2('1fa', 'iNik')](_0xdd88f7, _0x10eb5d)
                        },
                        'quhcN': _0x2dcbdb[_0x55b2('1fb', 'U3CT')],
                        'KdXVf': _0x2dcbdb['sMQOx'],
                        'cqdJl': function(_0x179fd8, _0x5d0130) {
                            return _0x2dcbdb[_0x55b2('1fc', 'zJ7r')](_0x179fd8, _0x5d0130)
                        },
                        'qEQKB': function(_0x48ae8b, _0x206e30) {
                            return _0x2dcbdb[_0x55b2('1fd', 'MxJI')](_0x48ae8b, _0x206e30)
                        },
                        'nfbrH': _0x2dcbdb[_0x55b2('1fe', 'k4Eh')],
                        'uKKQG': _0x2dcbdb['AVhSp'],
                        'hirOU': function(_0x3c7290, _0x53b034) {
                            return _0x3c7290(_0x53b034)
                        },
                        'LVSFf': _0x55b2('1ff', 'P(et'),
                        'kfwor': function(_0x19102a) {
                            return _0x2dcbdb[_0x55b2('200', 'u9K(')](_0x19102a)
                        },
                        'HOWGE': _0x2dcbdb[_0x55b2('201', 'Vw#z')]
                    };
                    $(_0x17dbe7)['on']('click', function() {
                        if ('NQgLY' !== _0x59c8a0[_0x55b2('202', 'P(et')]) {
                            o = $(_0x3394a6)[_0x55b2('203', 'wVm6')]();
                            if (_0x59c8a0[_0x55b2('204', 'U3CT')](o, 0x0)) {
                                if (_0x59c8a0[_0x55b2('205', 'M0h5')](_0x59c8a0[_0x55b2('206', 'dO7c')], _0x59c8a0['uKKQG'])) {
                                    _0x59c8a0[_0x55b2('207', 'EWS[')]($, _0x17dbe7)[_0x55b2('208', '9E^K')](_0x59c8a0['LVSFf']);
                                    _0x59c8a0[_0x55b2('209', 'HmS@')](_0x1fcdb3);
                                    _0x1e71fa = $(_0x3394a6)[_0x55b2('20a', 'Vw#z')]();
                                    yzmck[_0x55b2('20b', 'k4Eh')](_0x4fc9a2, _0x1e71fa)
                                } else {
                                    var _0x23046c = md5(config[_0x55b2('20c', 'MxJI')]);
                                    if (_0x59c8a0[_0x55b2('20d', 'I!ON')](_0x23046c, 0x0) && config['id'] != '') {
                                        _0x58d8cf = config['id'], _0x17dbe7 = config['sid']
                                    } else if (_0x23046c == 0x1 || !config['id']) {
                                        _0x58d8cf = _0x23046c, _0x17dbe7 = _0x23046c
                                    }
                                    aibk['id'] = _0x58d8cf['substring'](0x2, 0x8)
                                }
                            } else {
                                _0x559199()
                            }
                        } else {
                            layer['msg'](_0x59c8a0['quhcN'])
                        }
                    });
                    if (_0x3635a7 == 0x1) {
                        _0x2dcbdb['MiBgr']($, _0x17dbe7)['addClass'](_0x2dcbdb[_0x55b2('20e', 'hO4W')]);
                        _0x2dcbdb[_0x55b2('20f', 'I!ON')]($, _0x17dbe7)[_0x55b2('210', 'u9K(')](function() {
                            o = $(_0x3394a6)['val']();
                            if (_0x2dcbdb['GJTfL'](o, 0x0)) {
                                yzmck['set'](_0x5204d4, 0x0)
                            } else {
                                _0x2dcbdb['xTBKk'](_0x559199)
                            }
                        })
                    } else {
                        if (_0x2dcbdb['bTrMN'](_0x2dcbdb[_0x55b2('211', '0vlN')], _0x2dcbdb[_0x55b2('212', 'HZuu')])) {
                            $(_0x17dbe7)[_0x55b2('213', '0vlN')](function() {
                                if (_0x2dcbdb['iIvEE'](_0x2dcbdb[_0x55b2('214', 'M0h5')], _0x2dcbdb[_0x55b2('215', 'dO7c')])) {
                                    if (!danmuon) {
                                        aibk[_0x55b2('216', 'uGmG')]['head']()
                                    } else {
                                        aibk['dp']['notice'](_0x59c8a0[_0x55b2('217', '9E^K')]);
                                        aibk['video']['play']()
                                    }
                                } else {
                                    o = _0x2dcbdb['MiBgr']($, _0x3394a6)['val']();
                                    if (o > 0x0) {
                                        yzmck['set'](_0x5204d4, 0x1)
                                    } else {
                                        _0x2dcbdb[_0x55b2('218', 'EUJq')](_0x559199)
                                    }
                                }
                            })
                        } else {
                            num--;
                            span[_0x55b2('219', 'EUJq')] = num;
                            if (_0x2dcbdb[_0x55b2('21a', 'zJ7r')](num, 0x0)) {
                                _0x2dcbdb['MiBgr'](clearInterval, timer);
                                aibk[_0x55b2('21b', 'iNik')][_0x55b2('21c', 'lO]v')]();
                                aibk['dp'][_0x55b2('90', '9E^K')]();
                                $(_0x55b2('21d', 'EUJq'))[_0x55b2('21e', 'j&!c')]()
                            }
                        }
                    }
                };
                _0x2dcbdb['WIgky']($, f)[_0x55b2('21f', '9x[3')]({
                    'value': aibk['headt']
                });
                _0x2dcbdb['WIgky']($, j)[_0x55b2('220', 'Q68x')]({
                    'value': aibk[_0x55b2('221', 'uGmG')]
                });
                aibk[_0x55b2('222', 'iNik')]['last']()
            },
            'head': function() {
                var _0x64b74a = {
                    'yEZQZ': function(_0x21cb30, _0x349e04) {
                        return _0x21cb30 - _0x349e04
                    },
                    'QwLZi': _0x55b2('223', 'hO4W'),
                    'UPOra': function(_0x24f9e4, _0x1d14ce) {
                        return _0x24f9e4 < _0x1d14ce
                    },
                    'nxxAT': function(_0x573dba, _0xe8f660) {
                        return _0x573dba + _0xe8f660
                    },
                    'glCfZ': function(_0x1002a7, _0x3bd54f, _0x19318b) {
                        return _0x1002a7(_0x3bd54f, _0x19318b)
                    },
                    'CsNBw': _0x55b2('224', 'wVm6'),
                    'mucVV': function(_0x33ccc4, _0x394de3) {
                        return _0x33ccc4 > _0x394de3
                    },
                    'UASwv': function(_0x3fb02e, _0x289be9) {
                        return _0x3fb02e == _0x289be9
                    },
                    'bjMWn': function(_0x3a0656, _0x1bdcfa) {
                        return _0x3a0656 === _0x1bdcfa
                    },
                    'zFAdr': 'drCej',
                    'BbQos': function(_0x108b42, _0x4ad664) {
                        return _0x108b42 == _0x4ad664
                    },
                    'LijiO': function(_0x20a2d3, _0x4c12b0) {
                        return _0x20a2d3 !== _0x4c12b0
                    },
                    'VrEHM': _0x55b2('225', 'T4#C'),
                    'ixScm': _0x55b2('226', '@q!Z')
                };
                if (_0x64b74a['mucVV'](aibk[_0x55b2('227', 'SeLh')], aibk[_0x55b2('228', 'HO35')])) aibk['playtime'] = aibk['stime'];
                if (_0x64b74a[_0x55b2('229', 'ljjg')](aibk['frists'], 0x1)) {
                    if (aibk['headt'] > aibk[_0x55b2('22a', 'I!ON')] || aibk[_0x55b2('22b', 'ljjg')] == 0x0) {
                        if (_0x64b74a[_0x55b2('22c', 'ljjg')](_0x64b74a[_0x55b2('22d', 'sx3x')], _0x55b2('22e', 'tpZ^'))) {
                            aibk[_0x55b2('22f', 'iNik')] = 0x1
                        } else {
                            _0x64b74a[_0x55b2('230', '%nh[')](setInterval, function() {
                                var _0x24bcc5 = _0x64b74a['yEZQZ'](aibk['dp'][_0x55b2('231', 'HZuu')][_0x55b2('232', 'M0h5')], aibk['dp']['video'][_0x55b2('233', 'hO4W')]);
                                if (_0x24bcc5 < aibk[_0x55b2('234', 'j&!c')]) aibk['dp'][_0x55b2('235', 'I!ON')](_0x64b74a[_0x55b2('236', 'HO35')]);
                                if (aibk['lastt'] > 0x0 && _0x64b74a[_0x55b2('237', 'Q68x')](_0x24bcc5, aibk[_0x55b2('238', '9aCA')])) {
                                    aibk[_0x55b2('239', 'T4#C')](_0x64b74a['nxxAT']('time_', config[_0x55b2('23a', 'FD%[')]), '', -0x1);
                                    aibk[_0x55b2('23b', 'Q68x')][_0x55b2('23c', '1iGb')]()
                                }
                            }, 0x3e8)
                        }
                    } else {
                        aibk[_0x55b2('23d', '9x[3')] = 0x0
                    }
                }
                if (_0x64b74a['BbQos'](aibk[_0x55b2('23e', 'dO7c')], 0x1)) {
                    if (_0x64b74a[_0x55b2('23f', 'sx3x')](_0x64b74a['VrEHM'], 'GtcYq')) {
                        aibk['dp']['seek'](aibk[_0x55b2('240', 'fi9R')]);
                        aibk['dp']['notice'](_0x64b74a['ixScm'])
                    } else {
                        d[_0x55b2('241', 'hO4W')](_0x64b74a['CsNBw'], t)
                    }
                }
            },
            'last': function() {
                var _0x2c85ee = {
                    'xsvai': function(_0x4ebb21, _0x221d51) {
                        return _0x4ebb21(_0x221d51)
                    },
                    'FjqIH': _0x55b2('242', 'DLNY'),
                    'ncOXy': '#ADplayer',
                    'aotsB': '#ADtip',
                    'ipgfa': function(_0x1c482e, _0x4420f) {
                        return _0x1c482e !== _0x4420f
                    },
                    'cWpSw': _0x55b2('243', '6qTG'),
                    'MzUyw': _0x55b2('244', 'dO7c'),
                    'MgeNd': function(_0x44e00f, _0x1e2a67) {
                        return _0x44e00f < _0x1e2a67
                    },
                    'JBHKc': _0x55b2('245', 'wVm6'),
                    'FMJWW': function(_0x2c4490, _0x631b82) {
                        return _0x2c4490 + _0x631b82
                    },
                    'OJybf': _0x55b2('246', 'kBQF'),
                    'NALEq': function(_0x1a98e2, _0x5693ea) {
                        return _0x1a98e2 == _0x5693ea
                    },
                    'wwqxD': _0x55b2('247', 'j&!c'),
                    'YPgEh': function(_0x2861b6, _0x32b106) {
                        return _0x2861b6 == _0x32b106
                    },
                    'BmxOH': function(_0x1d3b93, _0x4fab08, _0xa578f9) {
                        return _0x1d3b93(_0x4fab08, _0xa578f9)
                    },
                    'EbOnf': function(_0x2721b2, _0x572e78) {
                        return _0x2721b2(_0x572e78)
                    },
                    'IdZZw': '.icon-xj'
                };
                if (_0x2c85ee['NALEq'](config[_0x55b2('248', 'iNik')], 'on')) {
                    if (_0x55b2('249', 'hO4W') !== _0x2c85ee[_0x55b2('24a', 'k4Eh')]) {
                        if (_0x2c85ee[_0x55b2('24b', 'M0h5')](aibk[_0x55b2('11f', 'dO7c')], 0x1)) {
                            _0x2c85ee[_0x55b2('24c', '6qTG')](setInterval, function() {
                                if (_0x2c85ee[_0x55b2('24d', '@e3Z')](_0x2c85ee[_0x55b2('24e', 'HZuu')], _0x2c85ee['MzUyw'])) {
                                    var _0x337bc7 = aibk['dp']['video'][_0x55b2('24f', 'tpZ^')] - aibk['dp'][_0x55b2('250', 'k^bl')]['currentTime'];
                                    if (_0x2c85ee['MgeNd'](_0x337bc7, aibk[_0x55b2('251', 'k4Eh')])) aibk['dp'][_0x55b2('252', 'bXlN')](_0x2c85ee[_0x55b2('253', 'k^bl')]);
                                    if (aibk['lastt'] > 0x0 && _0x2c85ee[_0x55b2('254', 'HZuu')](_0x337bc7, aibk[_0x55b2('255', 'DLNY')])) {
                                        aibk[_0x55b2('256', 'HmS@')](_0x2c85ee[_0x55b2('257', 'HbCg')](_0x2c85ee[_0x55b2('258', 'k^bl')], config[_0x55b2('259', 'Q68x')]), '', -0x1);
                                        aibk['video'][_0x55b2('25a', '@q!Z')]()
                                    }
                                } else {
                                    if (aibk['ad']['video'][_0x55b2('25b', 'I!ON')] > aibk['ad'][_0x55b2('25c', 'lO]v')][_0x55b2('25d', 'dO7c')] - 0.1) {
                                        _0x2c85ee[_0x55b2('25e', 'kBQF')]($, _0x55b2('25f', 'iNik'))[_0x55b2('260', '%nh[')](_0x2c85ee[_0x55b2('261', '0vlN')]);
                                        aibk['ad'][_0x55b2('262', 'I!ON')]();
                                        $(_0x2c85ee['ncOXy'])[_0x55b2('16e', '&weQ')]();
                                        _0x2c85ee['xsvai']($, _0x2c85ee[_0x55b2('263', 'U3CT')])['remove']();
                                        aibk[_0x55b2('264', 'fi9R')](config['url'])
                                    }
                                }
                            }, 0x3e8)
                        }
                    } else {
                        a = config['id'], b = config[_0x55b2('265', 'fS)C')]
                    }
                } else {
                    _0x2c85ee['EbOnf']($, _0x2c85ee[_0x55b2('266', '0vlN')])[_0x55b2('267', 'tpZ^')]()
                }
            },
            'ad': function(_0x18661c, _0x355ef0) {}
        },
        'danmu': {
            'send': function() {
                var _0x35832e = {
                    'UlITu': function(_0x74890d, _0x4f7afb) {
                        return _0x74890d(_0x4f7afb)
                    },
                    'tmiIv': 'value',
                    'ImZxy': function(_0x27e364, _0x1fedad, _0x301f07) {
                        return _0x27e364(_0x1fedad, _0x301f07)
                    },
                    'QXGVn': 'dmtype',
                    'ytTyL': function(_0x16f728, _0xe6adb8, _0x2247e5) {
                        return _0x16f728(_0xe6adb8, _0x2247e5)
                    },
                    'MBXAX': function(_0x157b86, _0x87264c) {
                        return _0x157b86 == _0x87264c
                    },
                    'NQcQD': function(_0x1e1636, _0x47ab0f) {
                        return _0x1e1636 !== _0x47ab0f
                    },
                    'HtchM': _0x55b2('268', 'q@BX'),
                    'KnuEU': _0x55b2('269', 'fS)C'),
                    'sBBBD': function(_0x3e337f, _0x47855d) {
                        return _0x3e337f > _0x47855d
                    },
                    'EPcBu': function(_0x241f05, _0x228934) {
                        return _0x241f05 > _0x228934
                    },
                    'XYOUp': 'iPhone',
                    'mvrhr': 'iPad',
                    'DLakN': _0x55b2('26a', '9E^K'),
                    'BSGUn': _0x55b2('26b', 'iNik'),
                    'JpSAx': _0x55b2('26c', 'EWS['),
                    'jfUDl': _0x55b2('26d', 'h&f3'),
                    'ioijd': function(_0x1610c8, _0x4d0c4a) {
                        return _0x1610c8 > _0x4d0c4a
                    },
                    'fOMdH': function(_0x2fb965, _0x1ad705) {
                        return _0x2fb965 == _0x1ad705
                    },
                    'Bhtsa': _0x55b2('26e', 'tpZ^'),
                    'jrxhB': function(_0x3b76bd, _0x3a6e4) {
                        return _0x3b76bd(_0x3a6e4)
                    },
                    'nBsDx': function(_0x17c7c2, _0x463918, _0x26944e) {
                        return _0x17c7c2(_0x463918, _0x26944e)
                    },
                    'zQdNe': '#link1',
                    'uWeYn': _0x55b2('26f', 'uGmG'),
                    'qXMky': 'color',
                    'sYWbc': function(_0x37be5f, _0x486907) {
                        return _0x37be5f > _0x486907
                    },
                    'DRAQv': function(_0x3fed04, _0x281286) {
                        return _0x3fed04 === _0x281286
                    },
                    'CpFql': _0x55b2('270', 'fS)C'),
                    'ZkOOM': _0x55b2('271', 'bXlN'),
                    'gJfLy': '登陆后才能发弹幕yo(・ω・)',
                    'wiPaz': function(_0x4b7695, _0x5dfe43) {
                        return _0x4b7695 < _0x5dfe43
                    },
                    'cYVnS': _0x55b2('272', 'wVm6'),
                    'DbCOl': _0x55b2('273', 'kBQF'),
                    'OWEdo': 'dmsent',
                    'mcXGI': function(_0x25efc9, _0x43b911) {
                        return _0x25efc9 - _0x43b911
                    },
                    'ttQLg': _0x55b2('274', '&weQ'),
                    'frwQW': 'aSjAV',
                    'SiMdy': function(_0x16f152, _0x1299be) {
                        return _0x16f152 + _0x1299be
                    },
                    'aHNax': function(_0x370675, _0x15a662) {
                        return _0x370675 + _0x15a662
                    },
                    'xbQLl': _0x55b2('275', 'k^bl'),
                    'fZfKg': _0x55b2('276', 'fS)C'),
                    'wTsKE': _0x55b2('277', 'P(et'),
                    'wIBva': function(_0x4f7463, _0x54a781) {
                        return _0x4f7463 === _0x54a781
                    },
                    'IAKqC': _0x55b2('278', 'ljjg'),
                    'XLpCp': function(_0x116056) {
                        return _0x116056()
                    },
                    'icXEk': _0x55b2('279', 'HO35'),
                    'StFBK': function(_0x4e05de, _0x58bc83) {
                        return _0x4e05de(_0x58bc83)
                    },
                    'rVlpx': _0x55b2('27a', '%nh['),
                    'AIQVS': _0x55b2('27b', 'Hnve'),
                    'DdEPU': function(_0x179315, _0x2e0afe) {
                        return _0x179315(_0x2e0afe)
                    },
                    'XvmDi': function(_0x381234, _0xc8ceff) {
                        return _0x381234 + _0xc8ceff
                    },
                    'bBfWM': _0x55b2('27c', 'ljjg')
                };
                g = $(_0x35832e[_0x55b2('27d', 'j&!c')]);
                d = _0x35832e[_0x55b2('27e', 'hO4W')]($, _0x55b2('27f', '9E^K'));
                h = _0x55b2('280', 'A9kN');
                _0x35832e['StFBK']($, h + _0x35832e[_0x55b2('281', 'T4#C')])['on']('click', function() {
                    r = _0x35832e['UlITu']($, this)[_0x55b2('282', 'wVm6')](_0x35832e[_0x55b2('283', 'k^bl')]);
                    _0x35832e[_0x55b2('284', 'EUJq')](setTimeout, function() {
                        d[_0x55b2('285', 'I!ON')]({
                            'color': r
                        })
                    }, 0x64)
                });
                $(h + _0x35832e[_0x55b2('286', 'k^bl')])['on'](_0x35832e[_0x55b2('287', '1iGb')], function() {
                    t = _0x35832e[_0x55b2('288', 'dO7c')]($, this)['attr'](_0x35832e[_0x55b2('289', 'I!ON')]);
                    _0x35832e[_0x55b2('28a', 'fS)C')](setTimeout, function() {
                        d[_0x55b2('28b', 'Wz)S')](_0x35832e['QXGVn'], t)
                    }, 0x64)
                });
                _0x35832e['DdEPU']($, _0x35832e[_0x55b2('28c', '9x[3')](h, _0x35832e['bBfWM']))['on'](_0x35832e['fZfKg'], function() {
                    var _0x16da8f = {
                        'ZIKMh': function(_0x136e12, _0xe618cf) {
                            return _0x35832e[_0x55b2('28d', 'sx3x')](_0x136e12, _0xe618cf)
                        },
                        'klmba': function(_0x34250c, _0xe41b3) {
                            return _0x35832e[_0x55b2('28e', 'dO7c')](_0x34250c, _0xe41b3)
                        },
                        'uTjTf': _0x35832e['HtchM'],
                        'miTJh': _0x35832e[_0x55b2('28f', 'k^bl')],
                        'luoOP': _0x55b2('290', 'u9K('),
                        'ZHquE': function(_0x328204, _0x296bcb) {
                            return _0x35832e[_0x55b2('291', 'lO]v')](_0x328204, _0x296bcb)
                        },
                        'gYeEI': 'Presto',
                        'kwezN': function(_0x2dbf94, _0x3ac7a0) {
                            return _0x35832e[_0x55b2('292', 'k^bl')](_0x2dbf94, _0x3ac7a0)
                        },
                        'aVeLD': 'AppleWebKit',
                        'UrJSk': 'Gecko',
                        'JbYYL': function(_0x5d1c85, _0x5cbccc) {
                            return _0x5d1c85 == _0x5cbccc
                        },
                        'vFPEW': 'KHTML',
                        'bcXry': _0x55b2('293', '%nh['),
                        'OZnFz': _0x35832e[_0x55b2('294', 'Wz)S')],
                        'IvKcL': _0x35832e[_0x55b2('295', '&weQ')],
                        'NADHQ': _0x35832e[_0x55b2('296', 'DLNY')],
                        'YgOpK': _0x35832e[_0x55b2('297', 'HmS@')],
                        'DCCiW': _0x55b2('298', 'Q68x')
                    };
                    if (_0x35832e[_0x55b2('299', 'P(et')] !== _0x35832e[_0x55b2('29a', 'dO7c')]) {
                        if (_0x35832e[_0x55b2('29b', '&weQ')](up[_0x55b2('29c', 'DLNY')], 0x0) && _0x35832e[_0x55b2('29d', 'M0h5')](config['group'], config[_0x55b2('29e', 'I!ON')])) {
                            layer[_0x55b2('29f', 'dO7c')](_0x35832e[_0x55b2('2a0', '9E^K')]);
                            return
                        };
                        t = _0x35832e[_0x55b2('2a1', 'wVm6')]($, this)[_0x55b2('2a2', '9aCA')](_0x35832e[_0x55b2('2a3', 'zJ7r')]);
                        _0x35832e[_0x55b2('2a4', 'tpZ^')](setTimeout, function() {
                            if (_0x16da8f[_0x55b2('2a5', 'k^bl')](_0x16da8f[_0x55b2('2a6', 'MxJI')], 'czMEI')) {
                                d['attr'](_0x16da8f[_0x55b2('2a7', 'dO7c')], t)
                            } else {
                                if (_0x16da8f[_0x55b2('2a8', 'EUJq')](aibk[_0x55b2('2a9', 'u9K(')][_0x55b2('2aa', 'kBQF')][_0x55b2('2ab', '0vlN')], '1')) {
                                    aibk[_0x55b2('2ac', 'tpZ^')][_0x55b2('2ad', 'P(et')](aibk[_0x55b2('2ae', 'q@BX')][_0x55b2('2af', 'fi9R')][_0x55b2('2b0', 'iNik')]['url'], aibk[_0x55b2('2b1', '9aCA')]['set'][_0x55b2('2b2', 'fi9R')]['link'])
                                } else if (aibk[_0x55b2('2b3', '%nh[')][_0x55b2('2b4', '1iGb')]['state'] == '2') {
                                    aibk[_0x55b2('2b5', 'u9K(')][_0x55b2('2b6', 'HbCg')](aibk[_0x55b2('2b7', 'zJ7r')][_0x55b2('2b8', 'iNik')][_0x55b2('2b9', 'q@BX')]['link'], aibk[_0x55b2('2ae', 'q@BX')]['set'][_0x55b2('2ba', 'fi9R')][_0x55b2('2bb', '&weQ')], aibk[_0x55b2('2bc', 'P(et')][_0x55b2('2bd', 'hO4W')][_0x55b2('2be', '@q!Z')][_0x55b2('2bf', 'dO7c')])
                                }
                            }
                        }, 0x64)
                    } else {
                        var _0x5c16ce = navigator['userAgent'],
                            _0x56079f = navigator[_0x55b2('2c0', 'Q68x')];
                        return {
                            'trident': _0x5c16ce[_0x55b2('2c1', 'uGmG')](_0x16da8f['luoOP']) > -0x1,
                            'presto': _0x16da8f['ZHquE'](_0x5c16ce[_0x55b2('2c2', 'Hnve')](_0x16da8f[_0x55b2('2c3', '&weQ')]), -0x1),
                            'webKit': _0x16da8f['kwezN'](_0x5c16ce['indexOf'](_0x16da8f[_0x55b2('2c4', '9aCA')]), -0x1),
                            'gecko': _0x16da8f[_0x55b2('2c5', 'FD%[')](_0x5c16ce[_0x55b2('2c6', 'tpZ^')](_0x16da8f[_0x55b2('2c7', 'sx3x')]), -0x1) && _0x16da8f['JbYYL'](_0x5c16ce[_0x55b2('a', 'sx3x')](_0x16da8f['vFPEW']), -0x1),
                            'mobile': !!_0x5c16ce['match'](/AppleWebKit.*Mobile.*/),
                            'ios': !!_0x5c16ce['match'](/\(i[^;]+;( U;)? CPU.+Mac OS X/),
                            'android': _0x5c16ce[_0x55b2('2c8', '9aCA')](_0x55b2('2c9', 'FD%[')) > -0x1 || _0x16da8f[_0x55b2('2ca', 'MxJI')](_0x5c16ce['indexOf'](_0x16da8f[_0x55b2('2cb', 'EUJq')]), -0x1),
                            'iPhone': _0x16da8f['kwezN'](_0x5c16ce[_0x55b2('2cc', 'EUJq')](_0x16da8f[_0x55b2('2cd', 'zJ7r')]), -0x1),
                            'iPad': _0x5c16ce[_0x55b2('2ce', 'P(et')](_0x16da8f[_0x55b2('2cf', '9E^K')]) > -0x1,
                            'webApp': _0x5c16ce[_0x55b2('16', 'fi9R')](_0x16da8f[_0x55b2('2d0', '6qTG')]) == -0x1,
                            'weixin': _0x5c16ce[_0x55b2('2d1', 'j&!c')](_0x16da8f[_0x55b2('2d2', 'HO35')]) > -0x1,
                            'qq': _0x5c16ce['match'](/\sQQ/i) == _0x16da8f[_0x55b2('2d3', 'Wz)S')]
                        }
                    }
                });
                g['on'](_0x35832e['fZfKg'], function() {
                    a = document[_0x55b2('2d4', '9x[3')](_0x35832e['uWeYn']);
                    a = a[_0x55b2('2d5', 'dO7c')];
                    b = d[_0x55b2('28b', 'Wz)S')](_0x35832e['QXGVn']);
                    c = d[_0x55b2('2d6', 'lO]v')](_0x35832e[_0x55b2('2d7', 'P(et')]);
                    z = d[_0x55b2('2d8', 'MxJI')](_0x55b2('2d9', 'I!ON'));
                    if (_0x35832e[_0x55b2('2da', '@q!Z')](up[_0x55b2('2db', 'FD%[')], 0x0) && config[_0x55b2('2dc', 'kBQF')] < config[_0x55b2('2dd', '@q!Z')] && config[_0x55b2('2de', 'EWS[')] != '') {
                        if (_0x35832e['DRAQv'](_0x35832e[_0x55b2('2df', '9aCA')], _0x35832e['ZkOOM'])) {
                            aibk['play'](config[_0x55b2('2e0', 'Hnve')])
                        } else {
                            layer['msg'](_0x35832e['gJfLy']);
                            return
                        }
                    }
                    for (var _0x2cc0ca = 0x0; _0x35832e[_0x55b2('2e1', '@e3Z')](_0x2cc0ca, up[_0x55b2('2e2', 'zJ7r')]['length']); _0x2cc0ca++) {
                        if (_0x55b2('2e3', 'h&f3') === _0x35832e[_0x55b2('2e4', 'k4Eh')]) {
                            if (a[_0x55b2('2e5', 'fi9R')](up[_0x55b2('2e6', 'SeLh')][_0x2cc0ca]) != -0x1) {
                                layer[_0x55b2('2e7', 'DLNY')](_0x35832e['DbCOl']);
                                return
                            }
                        } else {
                            _0x35832e[_0x55b2('2e8', 'HO35')]($, _0x35832e[_0x55b2('2e9', 'Wz)S')])[_0x55b2('2ea', 'Wz)S')]()
                        }
                    }
                    if (_0x35832e['wiPaz'](a[_0x55b2('2eb', 'Wz)S')], 0x1)) {
                        layer['msg'](_0x55b2('2ec', 'MxJI'));
                        return
                    }
                    var _0x3673ab = Date[_0x55b2('2ed', 'U3CT')](new Date());
                    var _0x2e9caa = yzmck[_0x55b2('2ee', '9aCA')](_0x35832e['OWEdo'], _0x3673ab);
                    if (_0x35832e[_0x55b2('2ef', 'Hnve')](_0x35832e[_0x55b2('2f0', 'EWS[')](_0x3673ab, _0x2e9caa), config[_0x55b2('2f1', 'zJ7r')] * 0x3e8)) {
                        if (_0x35832e[_0x55b2('2f2', 'u9K(')] !== _0x35832e[_0x55b2('2f3', '@q!Z')]) {
                            layer[_0x55b2('160', '6qTG')](_0x35832e[_0x55b2('2f4', 'j&!c')](_0x35832e[_0x55b2('2f5', 'k4Eh')](_0x35832e[_0x55b2('2f6', '@e3Z')], config['sendtime']), '秒~'));
                            return
                        } else {
                            aibk[_0x55b2('2f7', 'h&f3')][_0x55b2('2f8', 'zJ7r')]()
                        }
                    }
                    d[_0x55b2('2f9', '&weQ')]('');
                    aibk['dp'][_0x55b2('2fa', '&weQ')][_0x55b2('2fb', 'DLNY')]({
                        'text': a,
                        'color': c,
                        'type': b,
                        'size': z
                    });
                    yzmck[_0x55b2('2fc', 'Q68x')](_0x55b2('2fd', 'Vw#z'), _0x3673ab)
                });

                function _0x85d230() {
                    g['trigger'](_0x35832e['fZfKg'])
                };
                d[_0x55b2('2fe', '@e3Z')](function(_0x1db876) {
                    var _0x3ac664 = {
                        'rNwcU': _0x35832e[_0x55b2('2ff', 'wVm6')]
                    };
                    if (_0x35832e['wIBva'](_0x35832e[_0x55b2('300', '%nh[')], _0x35832e[_0x55b2('301', '9aCA')])) {
                        if (_0x35832e[_0x55b2('302', 'I!ON')](_0x1db876[_0x55b2('303', '6qTG')], 0xd)) {
                            _0x35832e[_0x55b2('304', 'EUJq')](_0x85d230)
                        }
                    } else {
                        aibk[_0x55b2('110', 'MxJI')]['post_r'](a, b, c, d, _0x3ac664['rNwcU'])
                    }
                })
            },
            'list': function() {
                var _0x3689df = {
                    'NTTES': function(_0xc70256, _0x24f60c) {
                        return _0xc70256(_0x24f60c)
                    },
                    'DUDJs': _0x55b2('305', 'h&f3'),
                    'dOKfV': 'time',
                    'npFNw': function(_0x3ca312, _0x22d047) {
                        return _0x3ca312 === _0x22d047
                    },
                    'CkwxT': 'nrYqP',
                    'WzZmV': '.danmuku-num',
                    'rqHrz': function(_0x3e522f, _0x324db4) {
                        return _0x3e522f(_0x324db4)
                    },
                    'SgEFU': function(_0x3fdce0, _0xba3010) {
                        return _0x3fdce0(_0xba3010)
                    },
                    'TBBDk': '.danmuku-list',
                    'PxOlx': _0x55b2('306', 'kBQF'),
                    'hzLsW': function(_0x4024f6, _0x2f8543) {
                        return _0x4024f6(_0x2f8543)
                    },
                    'Dtvpz': function(_0x49a06c, _0x5b13cd) {
                        return _0x49a06c + _0x5b13cd
                    },
                    'LStBB': function(_0x3f60e0, _0x8b9ffc) {
                        return _0x3f60e0 + _0x8b9ffc
                    },
                    'dWKDT': _0x55b2('307', 'k4Eh'),
                    'SQRnv': function(_0xe7ac45, _0x408fa9) {
                        return _0xe7ac45(_0x408fa9)
                    },
                    'bIPLQ': _0x55b2('308', 'DLNY'),
                    'gItOz': _0x55b2('309', 'HmS@'),
                    'rpiLw': function(_0x4f8233, _0x18b611) {
                        return _0x4f8233(_0x18b611)
                    },
                    'OswVQ': _0x55b2('30a', 'HmS@'),
                    'DkRqG': function(_0xcbd53, _0x14406b) {
                        return _0xcbd53(_0x14406b)
                    },
                    'wAtSj': _0x55b2('30b', '6qTG'),
                    'OGOmh': function(_0x54de6a, _0x2c60a9) {
                        return _0x54de6a + _0x2c60a9
                    },
                    'gygip': _0x55b2('30c', 'k^bl'),
                    'FdGXH': _0x55b2('30d', 'EUJq'),
                    'VCFMz': _0x55b2('30e', 'Q68x'),
                    'MjvdA': function(_0x131d9f, _0x347db4, _0x3fcfee, _0x3dae3f) {
                        return _0x131d9f(_0x347db4, _0x3fcfee, _0x3dae3f)
                    },
                    'BHjNk': _0x55b2('30f', 'k^bl'),
                    'ITYNZ': _0x55b2('310', 'EWS[')
                };
                $(_0x3689df['bIPLQ'])['on'](_0x55b2('311', 'k^bl'), function() {
                            var _0x4ad871 = {
                                'Gqohq': _0x55b2('312', '0vlN'),
                                'ICPrF': function(_0x528623, _0x46d2ce) {
                                    return _0x528623(_0x46d2ce)
                                },
                                'UNaFm': _0x3689df[_0x55b2('313', '9x[3')]
                            };
                            _0x3689df[_0x55b2('314', 'EUJq')]($, _0x3689df[_0x55b2('313', '9x[3')])['empty']();
                            $[_0x55b2('315', 'Hnve')]({
                                    'url': _0x3689df[_0x55b2('316', 'zJ7r')](_0x3689df[_0x55b2('317', 'kBQF')](config['api'], _0x3689df[_0x55b2('318', 'SeLh')]), aibk['id']),
                                    'success': function(_0x58a04a) {
                                        var _0x325188 = {
                                            'YEQer': function(_0x439cae, _0x574d2f) {
                                                return _0x3689df[_0x55b2('319', 'SeLh')](_0x439cae, _0x574d2f)
                                            },
                                            'kitkn': _0x3689df['DUDJs'],
                                            'ZgzmK': _0x3689df[_0x55b2('31a', 'EUJq')]
                                        };
                                        if (_0x3689df[_0x55b2('31b', 'k4Eh')](_0x3689df['CkwxT'], _0x55b2('31c', 'HmS@'))) {
                                            if (_0x58a04a[_0x55b2('31d', 'MxJI')] == 0x17) {
                                                a = _0x58a04a[_0x55b2('31e', 'ljjg')];
                                                b = _0x58a04a[_0x55b2('31f', '@q!Z')];
                                                c = _0x58a04a[_0x55b2('320', '1iGb')];
                                                _0x3689df['NTTES']($, _0x3689df[_0x55b2('321', 'fi9R')])[_0x55b2('322', 'kBQF')](c);
                                                _0x3689df[_0x55b2('323', 'HbCg')]($, a)['each'](function(_0x2908a9, _0x4fcf16) {
                                                        if (_0x4ad871[_0x55b2('324', 'ljjg')] !== _0x55b2('325', 'HZuu')) {
                                                            l = _0x55b2('326', 'A9kN') + _0x4fcf16[0x0] + _0x55b2('327', 'A9kN') + aibk[_0x55b2('328', 'HO35')](_0x4fcf16[0x0]) + _0x55b2('329', 'h&f3') + _0x4fcf16[0x4] + '">' + _0x4fcf16[0x4] + _0x55b2('32a', '@q!Z') + _0x4fcf16[0x3] + _0x55b2('32b', 'Q68x') + _0x4fcf16[0x5] + '">' + _0x4fcf16[0x6] + '</li><li class="report" onclick="aibk.danmu.report('
                                                            ' + _0x4fcf16[0x5] + _0x55b2('
                                                            32c ', '
                                                            0vlN ') + b + _0x55b2('
                                                            32d ', '
                                                            uGmG ') + _0x4fcf16[0x4] + _0x55b2('
                                                            32e ', '
                                                            EWS[') + _0x4fcf16[0x3] + '
                                                                ')">举报</li></d>'; _0x4ad871[_0x55b2('32f', '9E^K')]($, _0x4ad871[_0x55b2('330', 'EUJq')])[_0x55b2('331', 'sx3x')](l)
                                                            } else {
                                                                _0x325188[_0x55b2('332', 'MxJI')]($, _0x325188[_0x55b2('333', 'u9K(')])[_0x55b2('334', 'h&f3')]()
                                                            }
                                                        })
                                                }
                                                _0x3689df[_0x55b2('335', '6qTG')]($, _0x3689df[_0x55b2('336', 'Hnve')])['on'](_0x55b2('337', '%nh['), function() {
                                                    aibk['dp'][_0x55b2('338', 'Wz)S')](_0x325188[_0x55b2('339', 'U3CT')]($, this)[_0x55b2('33a', 'iNik')](_0x325188[_0x55b2('33b', 'EUJq')]))
                                                })
                                            } else {
                                                aibk['endedHandler']()
                                            }
                                        }
                                    })
                            });
                        var _0x4f4ef9 = _0x3689df[_0x55b2('33c', 'FD%[')](_0x3689df['LStBB'](_0x55b2('33d', 'M0h5'), config[_0x55b2('33e', 'M0h5')]), _0x55b2('33f', 'HmS@')); _0x3689df[_0x55b2('340', 'k^bl')]($, _0x3689df[_0x55b2('341', 'Vw#z')])['append'](_0x4f4ef9); _0x3689df[_0x55b2('342', '6qTG')]($, _0x3689df[_0x55b2('343', 'k^bl')])[_0x55b2('344', 'ljjg')](up[_0x55b2('345', 'HO35')]); _0x3689df[_0x55b2('346', 'HmS@')]($, _0x55b2('347', '%nh['))[_0x55b2('348', 'lO]v')](_0x3689df[_0x55b2('349', 'fi9R')]);
                        for (var _0x296582 = 0x0; _0x296582 < up[_0x55b2('34a', 'HmS@')][_0x55b2('34b', 'q@BX')]; _0x296582++) {
                            var _0x50fb4e = _0x3689df[_0x55b2('34c', '9aCA')](_0x3689df[_0x55b2('34d', 'sx3x')](_0x3689df['gygip'], up[_0x55b2('34e', 'HZuu')][_0x296582]), _0x3689df[_0x55b2('34f', '@e3Z')]);
                            _0x3689df[_0x55b2('350', '9aCA')]($, _0x3689df['VCFMz'])['append'](_0x50fb4e)
                        }
                        _0x3689df[_0x55b2('351', 'Hnve')](_0x4d57af, _0x3689df[_0x55b2('352', '%nh[')], _0x55b2('353', 'ljjg'), _0x3689df['ITYNZ']);

                        function _0x4d57af(_0x2384c9, _0x1651d8, _0x59de99, _0x30e7aa) {
                            var _0x23cafc = {
                                'YZVDi': function(_0x4dc6c0, _0x399395) {
                                    return _0x3689df['hzLsW'](_0x4dc6c0, _0x399395)
                                }
                            };
                            _0x3689df['SQRnv']($, _0x2384c9)['click'](function() {
                                $(_0x1651d8)['toggleClass'](_0x59de99);
                                _0x23cafc[_0x55b2('354', '6qTG')]($, _0x30e7aa)['remove']()
                            })
                        }
                    },
                    'report': function(_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3) {
                        var _0x1a8b00 = {
                            'AyzTZ': _0x55b2('355', 'dO7c'),
                            'oPQlg': _0x55b2('356', 'I!ON'),
                            'nxqmD': function(_0x117b1a, _0x18bf71) {
                                return _0x117b1a(_0x18bf71)
                            },
                            'EJrDn': function(_0x58699a, _0x3ae349) {
                                return _0x58699a === _0x3ae349
                            },
                            'zGETs': _0x55b2('357', 'fi9R'),
                            'VvgpS': _0x55b2('358', 'k^bl'),
                            'jihxE': _0x55b2('359', '@e3Z'),
                            'ZdnHK': _0x55b2('35a', 'j&!c'),
                            'VJVsV': '违法违禁',
                            'Ykedx': '色情低俗',
                            'QWAFW': function(_0x59b0f2, _0xe4a5c) {
                                return _0x59b0f2 + _0xe4a5c
                            },
                            'PrCWh': _0x55b2('35b', 'fS)C'),
                            'qYOmD': _0x55b2('35c', 'iNik'),
                            'bumEt': _0x55b2('35d', 'M0h5')
                        };
                        layer[_0x55b2('35e', 'M0h5')](_0x1a8b00[_0x55b2('35f', 'Wz)S')](_0x1a8b00[_0x55b2('360', 'hO4W')]('', _0x5b813e), '<!--br><br><span style="color:#333">请选择需要举报的类型</span-->'), {
                            'anim': 0x1,
                            'title': _0x1a8b00['PrCWh'],
                            'btn': [_0x55b2('361', 'lO]v'), _0x55b2('362', 'iNik'), _0x1a8b00[_0x55b2('363', 'Vw#z')], _0x55b2('364', 'EUJq'), _0x1a8b00[_0x55b2('365', '9x[3')], _0x1a8b00['bumEt'], _0x1a8b00['VvgpS'], '剧透', '引战'],
                            'btn3': function(_0x3d25e2, _0x3dc9ef) {
                                aibk[_0x55b2('366', 'U3CT')][_0x55b2('367', '1iGb')](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, _0x1a8b00[_0x55b2('368', 'lO]v')])
                            },
                            'btn4': function(_0xe917c8, _0x3abf96) {
                                aibk['danmu'][_0x55b2('369', 'j&!c')](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, _0x1a8b00[_0x55b2('36a', 'lO]v')])
                            },
                            'btn5': function(_0x1c55c5, _0x2b5a2e) {
                                aibk[_0x55b2('36b', '%nh[')][_0x55b2('36c', '9x[3')](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, _0x55b2('36d', 'M0h5'))
                            },
                            'btn6': function(_0x58072b, _0x313be5) {
                                var _0x30ffa9 = {
                                    'ikaAB': function(_0x2a3ed9, _0x4df261) {
                                        return _0x1a8b00[_0x55b2('36e', 'A9kN')](_0x2a3ed9, _0x4df261)
                                    },
                                    'bjNMU': '.list-show'
                                };
                                if (_0x1a8b00[_0x55b2('36f', 'SeLh')](_0x1a8b00[_0x55b2('370', 'fS)C')], _0x1a8b00[_0x55b2('371', 'U3CT')])) {
                                    aibk[_0x55b2('372', '@e3Z')][_0x55b2('373', 'h&f3')](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, '侵犯隐私')
                                } else {
                                    l = _0x55b2('374', 'HO35') + item[0x0] + _0x55b2('375', 'dO7c') + aibk['formatTime'](item[0x0]) + '</li><li title="' + item[0x4] + '">' + item[0x4] + _0x55b2('376', 'EWS[') + item[0x3] + _0x55b2('377', 'EUJq') + item[0x5] + '">' + item[0x6] + _0x55b2('378', 'zJ7r') + item[0x5] + _0x55b2('32e', 'EWS[') + _0x3f3d51 + _0x55b2('379', 'HbCg') + item[0x4] + _0x55b2('37a', 'q@BX') + item[0x3] + _0x55b2('37b', 'iNik');
                                    _0x30ffa9[_0x55b2('37c', 'Wz)S')]($, _0x30ffa9[_0x55b2('37d', 'tpZ^')])[_0x55b2('37e', '@q!Z')](l)
                                }
                            },
                            'btn7': function(_0x2dac53, _0x5cf5d8) {
                                aibk[_0x55b2('366', 'U3CT')][_0x55b2('37f', 'q@BX')](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, _0x1a8b00[_0x55b2('380', '&weQ')])
                            },
                            'btn8': function(_0x3145bc, _0x340d78) {
                                aibk['danmu'][_0x55b2('381', 'FD%[')](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, '剧透')
                            },
                            'btn9': function(_0x158c52, _0x47b9ac) {
                                if (_0x1a8b00[_0x55b2('382', 'SeLh')] !== _0x1a8b00[_0x55b2('383', 'Q68x')]) {
                                    aibk[_0x55b2('384', 'FD%[')][_0x55b2('385', '%nh[')](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, '引战')
                                } else {
                                    aibk[_0x55b2('386', 'tpZ^')][_0x55b2('387', 'MxJI')](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, '剧透')
                                }
                            }
                        }, function(_0x279aa7, _0x827fa5) {
                            aibk['danmu']['post_r'](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, _0x1a8b00[_0x55b2('388', 'fS)C')])
                        }, function(_0x1d2860) {
                            aibk['danmu'][_0x55b2('389', 'Vw#z')](_0x4e418a, _0x3f3d51, _0x5b813e, _0x16e4d3, _0x1a8b00['Ykedx'])
                        })
                    },
                    'post_r': function(_0x4a0578, _0x6b5bf5, _0x4ab3a5, _0x4fda83, _0xe12a73) {
                        var _0x5a4d66 = {
                            'psSuV': '举报成功！感谢您为守护弹幕作出了贡献',
                            'nneKz': _0x55b2('38a', '@q!Z'),
                            'mgmTb': function(_0x832b7, _0x2f7291) {
                                return _0x832b7 + _0x2f7291
                            },
                            'pwmkP': function(_0x3fe5c4, _0x4a2c61) {
                                return _0x3fe5c4 + _0x4a2c61
                            },
                            'eiWQG': function(_0x17812b, _0xbeaac5) {
                                return _0x17812b + _0xbeaac5
                            },
                            'KDcwz': function(_0x2cb9f9, _0x3637bc) {
                                return _0x2cb9f9 + _0x3637bc
                            },
                            'MecYD': function(_0x2a33cd, _0x4aee4c) {
                                return _0x2a33cd + _0x4aee4c
                            },
                            'BtCxC': _0x55b2('38b', 'Vw#z'),
                            'kJnoy': _0x55b2('38c', '@q!Z'),
                            'ihmee': _0x55b2('38d', 'U3CT')
                        };
                        $[_0x55b2('38e', '9E^K')]({
                            'type': _0x5a4d66[_0x55b2('38f', 'j&!c')],
                            'url': _0x5a4d66[_0x55b2('390', '@e3Z')](_0x5a4d66[_0x55b2('391', 'k^bl')](_0x5a4d66[_0x55b2('392', 'EUJq')](_0x5a4d66['KDcwz'](_0x5a4d66[_0x55b2('393', 'bXlN')](_0x5a4d66[_0x55b2('394', 'dO7c')](_0x5a4d66[_0x55b2('395', 'bXlN')](config[_0x55b2('396', '9x[3')], _0x55b2('397', 'dO7c')), _0x4fda83) + _0x5a4d66[_0x55b2('398', 'fS)C')], _0x4a0578) + '&type=', _0xe12a73), _0x5a4d66[_0x55b2('399', 'bXlN')]) + _0x6b5bf5, _0x55b2('39a', 'M0h5')), _0x4ab3a5),
                            'cache': ![],
                            'dataType': _0x5a4d66[_0x55b2('39b', 'uGmG')],
                            'beforeSend': function() {},
                            'success': function(_0x214cf3) {
                                layer[_0x55b2('39c', 'j&!c')](_0x5a4d66[_0x55b2('39d', 'sx3x')])
                            },
                            'error': function(_0x58a5a8) {
                                var _0x258f3f = '服务故障 or 网络异常，稍后再试！';
                                layer[_0x55b2('39e', 'zJ7r')](_0x258f3f)
                            }
                        })
                    }
            },
            'setCookie': function(_0x29feff, _0xa5ef, _0x468987) {
                var _0x3633c9 = {
                    'YYBZE': function(_0x5e0587, _0x1f2e72) {
                        return _0x5e0587 + _0x1f2e72
                    },
                    'lbaRF': function(_0x22a1d5, _0xe28bf1) {
                        return _0x22a1d5(_0xe28bf1)
                    },
                    'vjqeB': function(_0x1fc8b6, _0x3e756e) {
                        return _0x1fc8b6 === _0x3e756e
                    },
                    'DrxXK': ';expires='
                };
                var _0x3b7a3c = new Date();
                _0x3b7a3c['setHours'](_0x3633c9[_0x55b2('39f', 'DLNY')](_0x3b7a3c['getHours'](), _0x468987));
                document[_0x55b2('3a0', 'MxJI')] = _0x3633c9[_0x55b2('3a1', '9aCA')](_0x3633c9[_0x55b2('3a2', '&weQ')](_0x29feff, '=') + _0x3633c9[_0x55b2('3a3', 'Hnve')](escape, _0xa5ef), _0x3633c9['vjqeB'](_0x468987, null) ? '' : _0x3633c9['YYBZE'](_0x3633c9['DrxXK'], _0x3b7a3c['toGMTString']()))
            },
            'getCookie': function(_0xef688c) {
                var _0x1194c1 = {
                    'EjNbf': function(_0x132566, _0xff61c4) {
                        return _0x132566 > _0xff61c4
                    },
                    'OfHxn': function(_0x167994, _0x5c418c) {
                        return _0x167994(_0x5c418c)
                    },
                    'UuqVL': 'checked',
                    'txqzH': function(_0x242ab3) {
                        return _0x242ab3()
                    },
                    'PRSsn': function(_0x3ca64b, _0x3e2775) {
                        return _0x3ca64b === _0x3e2775
                    },
                    'xRmLu': _0x55b2('3a4', '%nh['),
                    'HxFpR': function(_0x468c0f, _0x2b6823) {
                        return _0x468c0f + _0x2b6823
                    },
                    'XRSyN': function(_0x1ef285, _0xe84929) {
                        return _0x1ef285 !== _0xe84929
                    },
                    'jBQZu': _0x55b2('3a5', 'wVm6'),
                    'VAiLo': function(_0x23aebe, _0x5a7511) {
                        return _0x23aebe + _0x5a7511
                    },
                    'HNhln': function(_0x3f9fd1, _0x278559) {
                        return _0x3f9fd1 === _0x278559
                    }
                };
                if (document[_0x55b2('3a6', 'q@BX')][_0x55b2('3a7', 'Q68x')] > 0x0) {
                    if (_0x1194c1[_0x55b2('3a8', '9x[3')](_0x1194c1[_0x55b2('3a9', '6qTG')], _0x55b2('3aa', 'hO4W'))) {
                        c_start = document[_0x55b2('3ab', 'wVm6')][_0x55b2('3ac', 'wVm6')](_0x1194c1['HxFpR'](_0xef688c, '='));
                        if (_0x1194c1[_0x55b2('3ad', 'sx3x')](c_start, -0x1)) {
                            var _0x373df6 = _0x1194c1['jBQZu']['split']('|'),
                                _0xd30c82 = 0x0;
                            while (!![]) {
                                switch (_0x373df6[_0xd30c82++]) {
                                    case '0':
                                        c_start = _0x1194c1[_0x55b2('3ae', 'bXlN')](_0x1194c1[_0x55b2('3af', 'SeLh')](c_start, _0xef688c[_0x55b2('3b0', 'DLNY')]), 0x1);
                                        continue;
                                    case '1':
                                        return unescape(document['cookie'][_0x55b2('3b1', 'kBQF')](c_start, c_end));
                                    case '2':
                                        if (_0x1194c1[_0x55b2('3b2', 'hO4W')](c_end, -0x1)) {
                                            c_end = document[_0x55b2('3b3', 'T4#C')]['length']
                                        }
                                        continue;
                                    case '3':
                                        c_end = document[_0x55b2('3b4', 'Q68x')]['indexOf'](';', c_start);
                                        continue;
                                    case '4':
                                        ;
                                        continue
                                }
                                break
                            }
                        }
                    } else {
                        o = $(t)[_0x55b2('3b5', 'h&f3')]();
                        if (_0x1194c1[_0x55b2('3b6', 'dO7c')](o, 0x0)) {
                            _0x1194c1[_0x55b2('3b7', 'h&f3')]($, b)[_0x55b2('3b8', 'HZuu')](_0x1194c1[_0x55b2('3b9', '9aCA')]);
                            su();
                            g = $(t)[_0x55b2('3ba', 'MxJI')]();
                            yzmck['set'](e, g)
                        } else {
                            _0x1194c1[_0x55b2('3bb', 'fS)C')](er)
                        }
                    }
                }
                return ''
            },
            'formatTime': function(_0x2b91b8) {
                var _0x1e94c1 = {
                    'bweds': function(_0x4302aa, _0x2e4b4a) {
                        return _0x4302aa(_0x2e4b4a)
                    },
                    'rtMaC': function(_0x15e6e4, _0x969e0a) {
                        return _0x15e6e4 / _0x969e0a
                    },
                    'eYeqV': function(_0x2e1a4b, _0x1abb97) {
                        return _0x2e1a4b % _0x1abb97
                    }
                };
                return [_0x1e94c1[_0x55b2('3bc', 'fi9R')](parseInt, _0x1e94c1[_0x55b2('3bd', 'FD%[')](_0x2b91b8 / 0x3c, 0x3c)), _0x1e94c1[_0x55b2('3be', 'HmS@')](parseInt, _0x1e94c1[_0x55b2('3bf', 'hO4W')](_0x2b91b8 / 0x3c, 0x3c)), parseInt(_0x1e94c1[_0x55b2('3c0', 'lO]v')](_0x2b91b8, 0x3c))][_0x55b2('3c1', 'EWS[')](':')[_0x55b2('3c2', 'HmS@')](/\b(\d)\b/g, _0x55b2('3c3', 'dO7c'))
            },
            'loadedmetadataHandler': function() {
                var _0xe7b8ce = {
                    'KpVxQ': _0x55b2('3c4', 'q@BX'),
                    'ICxjZ': _0x55b2('3c5', '6qTG'),
                    'VqMts': function(_0xddd343, _0x427980) {
                        return _0xddd343 < _0x427980
                    },
                    'lvTiR': function(_0x3bd7d1, _0x22eb8c, _0x508384) {
                        return _0x3bd7d1(_0x22eb8c, _0x508384)
                    },
                    'Lxsfe': function(_0x3617da, _0x304002) {
                        return _0x3617da * _0x304002
                    },
                    'xEDRt': _0x55b2('3c6', 'sx3x')
                };
                if (aibk['playtime'] > 0x0 && _0xe7b8ce['VqMts'](aibk['dp'][_0x55b2('3c7', '9x[3')][_0x55b2('3c8', 'EUJq')], aibk[_0x55b2('134', 'A9kN')])) {
                    _0xe7b8ce[_0x55b2('3c9', '&weQ')](setTimeout, function() {
                        aibk[_0x55b2('3ca', 'wVm6')][_0x55b2('3cb', 'fi9R')]()
                    }, 0x1 * 0x3e8)
                } else {
                    setTimeout(function() {
                        if (!danmuon) {
                            aibk[_0x55b2('3cc', 'T4#C')]['head']()
                        } else {
                            aibk['dp'][_0x55b2('3cd', 'T4#C')](_0xe7b8ce[_0x55b2('3ce', '@e3Z')]);
                            aibk[_0x55b2('3cf', 'k4Eh')][_0x55b2('3d0', '1iGb')]()
                        }
                    }, _0xe7b8ce[_0x55b2('3d1', '6qTG')](0x1, 0x3e8))
                }
                aibk['dp']['on'](_0xe7b8ce['xEDRt'], function() {
                    var _0x11486f = {
                        'GDCth': _0xe7b8ce[_0x55b2('3d2', 'DLNY')]
                    };
                    if (_0x55b2('3d3', 'DLNY') !== 'ohiPe') {
                        aibk[_0x55b2('163', '1iGb')]()
                    } else {
                        layer[_0x55b2('3d4', 'SeLh')](_0x11486f[_0x55b2('3d5', '1iGb')]);
                        return
                    }
                })
            },
            'timeupdateHandler': function() {
                var _0x31c62a = {
                    'rviFz': function(_0x819206, _0x1ff0cb) {
                        return _0x819206 + _0x1ff0cb
                    }
                };
                aibk[_0x55b2('3d6', 'HO35')](_0x31c62a[_0x55b2('3d7', 'HbCg')]('time_', config[_0x55b2('3d8', 'T4#C')]), aibk['dp'][_0x55b2('197', 'SeLh')]['currentTime'], 0x18)
            },
            'endedHandler': function() {
                var _0x5cdc74 = {
                    'PIlyI': function(_0x6f05a4, _0x4b7b25) {
                        return _0x6f05a4(_0x4b7b25)
                    },
                    'oyFta': _0x55b2('3d9', '@e3Z'),
                    'zXcSZ': _0x55b2('3da', 'EWS['),
                    'bChir': function(_0xa074af, _0x3a7556) {
                        return _0xa074af(_0x3a7556)
                    },
                    'Mwbcj': '.aiblog-setting-speeds  .title',
                    'XqceU': _0x55b2('3db', 'A9kN'),
                    'HvYxh': _0x55b2('3dc', 'A9kN'),
                    'mCMxp': function(_0x48a6c7, _0x12377d) {
                        return _0x48a6c7 + _0x12377d
                    },
                    'qekBU': 'time_',
                    'aCNuO': function(_0x19675f, _0x21f3ba) {
                        return _0x19675f == _0x21f3ba
                    },
                    'XLPIG': function(_0x3a9c72, _0x3d818f, _0x480c26) {
                        return _0x3a9c72(_0x3d818f, _0x480c26)
                    },
                    'UMwjm': function(_0xfd67e, _0x139c4b) {
                        return _0xfd67e * _0x139c4b
                    },
                    'yAMTD': 'Dfcno',
                    'vjwjR': '视频播放已结束',
                    'upKbY': function(_0x4a0b0f, _0x44e51a, _0x113e3c) {
                        return _0x4a0b0f(_0x44e51a, _0x113e3c)
                    }
                };
                aibk['setCookie'](_0x5cdc74[_0x55b2('3dd', 'hO4W')](_0x5cdc74[_0x55b2('3de', 'MxJI')], config['url']), '', -0x1);
                if (_0x5cdc74['aCNuO'](config[_0x55b2('3df', '9aCA')], 'on')) {
                    aibk['dp']['notice']('5s后,将自动为您播放下一集');
                    _0x5cdc74[_0x55b2('3e0', 'fi9R')](setTimeout, function() {
                        aibk[_0x55b2('197', 'SeLh')]['next']()
                    }, _0x5cdc74[_0x55b2('3e1', 'u9K(')](0x5, 0x3e8))
                } else {
                    if (_0x5cdc74[_0x55b2('3e2', 'HZuu')] !== _0x55b2('3e3', 'uGmG')) {
                        _0x5cdc74['bChir']($, _0x55b2('3e4', 'dO7c'))['on'](_0x5cdc74[_0x55b2('3e5', 'bXlN')], function() {
                            _0x5cdc74[_0x55b2('3e6', 'fS)C')]($, _0x5cdc74['oyFta'])[_0x55b2('3e7', 'tpZ^')](_0x5cdc74['zXcSZ'])
                        });
                        $(_0x5cdc74[_0x55b2('3e8', 'HmS@')])['click'](function() {
                            _0x5cdc74[_0x55b2('3e9', 'T4#C')]($, _0x5cdc74['Mwbcj'])[_0x55b2('344', 'ljjg')]($(this)[_0x55b2('3ea', 'Vw#z')]())
                        })
                    } else {
                        aibk['dp'][_0x55b2('3eb', 'DLNY')](_0x5cdc74[_0x55b2('3ec', 'HmS@')]);
                        _0x5cdc74[_0x55b2('3ed', 'zJ7r')](setTimeout, function() {
                            aibk[_0x55b2('3ee', 'T4#C')][_0x55b2('3ef', 'zJ7r')]()
                        }, 0x2 * 0x3e8)
                    }
                }
            },
            'player': {
                'play': function(_0x41c221) {
                    var _0x1afc18 = {
                        'ODHaY': function(_0x49efb7, _0x549ac0) {
                            return _0x49efb7(_0x549ac0)
                        },
                        'bUcki': _0x55b2('3f0', 'I!ON'),
                        'iYcLE': 'danmu-off',
                        'ZjtRN': _0x55b2('3f1', 'kBQF'),
                        'UENHi': _0x55b2('3f2', 'j&!c'),
                        'QXVKH': '<style type="text/css">',
                        'SeUcS': _0x55b2('3f3', 'lO]v')
                    };
                    _0x1afc18['ODHaY']($, _0x1afc18[_0x55b2('3f4', 'M0h5')])[_0x55b2('3f5', 'k4Eh')](_0x1afc18[_0x55b2('3f6', 'Q68x')]);
                    aibk['dp'] = new aiblog({
                        'autoplay': !![],
                        'element': document[_0x55b2('3f7', 'kBQF')](_0x1afc18['ZjtRN']),
                        'theme': config[_0x55b2('3f8', '%nh[')],
                        'logo': config['logo'],
                        'video': {
                            'url': _0x41c221,
                            'pic': config[_0x55b2('3f9', 'HO35')],
                            'type': _0x1afc18[_0x55b2('3fa', 'fi9R')]
                        }
                    });
                    var _0x29a8a2 = _0x1afc18[_0x55b2('3fb', '@e3Z')];
                    _0x29a8a2 += _0x55b2('3fc', 'lO]v');
                    _0x29a8a2 += _0x1afc18[_0x55b2('3fd', 'ljjg')];
                    $('body')['append'](_0x29a8a2)[_0x55b2('3fe', '@e3Z')]('');
                    aibk[_0x55b2('3ff', '9x[3')]()
                },
                'adplay': function(_0x40cf80) {
                    var _0x2e2144 = {
                        'QWpgG': _0x55b2('400', 'HZuu'),
                        'IsKEe': 'auto',
                        'Upbsb': _0x55b2('401', 'hO4W'),
                        'XntQZ': function(_0x87f850, _0x27ad7e) {
                            return _0x87f850 > _0x27ad7e
                        },
                        'fDKCT': function(_0x1bee5d, _0xe7a31c) {
                            return _0x1bee5d(_0xe7a31c)
                        },
                        'vafAW': function(_0x1c07e7, _0x1d86e3) {
                            return _0x1c07e7(_0x1d86e3)
                        },
                        'OrKEh': _0x55b2('402', 'lO]v'),
                        'JbuhO': _0x55b2('403', 'Q68x'),
                        'RzYOw': function(_0x7b49d6, _0x275e05) {
                            return _0x7b49d6(_0x275e05)
                        }
                    };
                    var _0x5a1006 = _0x2e2144[_0x55b2('404', 'k^bl')][_0x55b2('405', 'k4Eh')]('|'),
                        _0x524c0d = 0x0;
                    while (!![]) {
                        switch (_0x5a1006[_0x524c0d++]) {
                            case '0':
                                aibk['ad'] = new aiblog({
                                    'autoplay': !![],
                                    'element': document[_0x55b2('406', 'HZuu')](_0x55b2('407', '@q!Z')),
                                    'theme': config[_0x55b2('408', 'q@BX')],
                                    'logo': config[_0x55b2('409', 'k4Eh')],
                                    'video': {
                                        'url': _0x40cf80,
                                        'pic': config[_0x55b2('3f9', 'HO35')],
                                        'type': _0x2e2144['IsKEe']
                                    }
                                });
                                continue;
                            case '1':
                                aibk['ad']['on'](_0x2e2144[_0x55b2('40a', 'u9K(')], function() {
                                    if (_0x1d1661[_0x55b2('40b', 'M0h5')](aibk['ad'][_0x55b2('40c', 'Vw#z')][_0x55b2('40d', 'Vw#z')], aibk['ad'][_0x55b2('40e', 'Wz)S')][_0x55b2('40f', 'I!ON')] - 0.1)) {
                                        var _0x78660f = '1|0|2|4|3' ['split']('|'),
                                            _0x4d99d8 = 0x0;
                                        while (!![]) {
                                            switch (_0x78660f[_0x4d99d8++]) {
                                                case '0':
                                                    aibk['ad']['destroy']();
                                                    continue;
                                                case '1':
                                                    _0x1d1661['oItZl']($, 'body')['removeClass'](_0x55b2('410', 'EWS['));
                                                    continue;
                                                case '2':
                                                    _0x1d1661[_0x55b2('411', 'P(et')]($, _0x1d1661[_0x55b2('412', 'uGmG')])[_0x55b2('413', '0vlN')]();
                                                    continue;
                                                case '3':
                                                    aibk[_0x55b2('414', 'kBQF')](config['url']);
                                                    continue;
                                                case '4':
                                                    $(_0x55b2('415', '@e3Z'))['remove']();
                                                    continue
                                            }
                                            break
                                        }
                                    }
                                });
                                continue;
                            case '2':
                                var _0x1d1661 = {
                                    'vfGaw': function(_0x42d165, _0x5e5775) {
                                        return _0x2e2144['XntQZ'](_0x42d165, _0x5e5775)
                                    },
                                    'oItZl': function(_0x5e8131, _0x3be844) {
                                        return _0x2e2144['fDKCT'](_0x5e8131, _0x3be844)
                                    },
                                    'iekxE': _0x55b2('416', 'bXlN')
                                };
                                continue;
                            case '3':
                                _0x2e2144['vafAW']($, _0x2e2144[_0x55b2('417', 'ljjg')])[_0x55b2('418', 'MxJI')]();
                                continue;
                            case '4':
                                $(_0x2e2144[_0x55b2('419', 'A9kN')])['addClass']('danmu-off');
                                continue;
                            case '5':
                                _0x2e2144[_0x55b2('41a', '@e3Z')]($, _0x55b2('41b', 'uGmG'))[_0x55b2('41c', '&weQ')]();
                                continue
                        }
                        break
                    }
                },
                'dmplay': function(_0x237681) {
                    var _0x5a7b1b = {
                        'hcAdG': _0x55b2('41d', '0vlN'),
                        'expJV': '?ac=dm'
                    };
                    aibk[_0x55b2('41e', '9x[3')]();
                    aibk['dp'] = new aiblog({
                        'autoplay': ![],
                        'element': document['getElementById'](_0x5a7b1b[_0x55b2('41f', 'fS)C')]),
                        'theme': config[_0x55b2('420', 'fi9R')],
                        'logo': config[_0x55b2('421', 'Q68x')],
                        'video': {
                            'url': _0x237681,
                            'pic': config['pic'],
                            'type': _0x55b2('422', 'Vw#z')
                        },
                        'danmaku': {
                            'id': aibk['id'],
                            'api': config[_0x55b2('423', 'EWS[')] + _0x5a7b1b[_0x55b2('424', 'HZuu')],
                            'user': config[_0x55b2('425', 'ljjg')]
                        }
                    });
                    aibk[_0x55b2('426', 'Vw#z')]()
                },
                'bdplay': function(_0x498875) {
                    var _0x35038c = {
                        'niToW': _0x55b2('427', '9aCA'),
                        'KzzAD': _0x55b2('428', '9E^K'),
                        'GoEPY': _0x55b2('429', '0vlN'),
                        'xZQRo': function(_0x21cf96, _0xb558e0) {
                            return _0x21cf96 + _0xb558e0
                        },
                        'xjhnK': 'bilibili/?av='
                    };
                    aibk[_0x55b2('42a', 'tpZ^')]();
                    aibk['dp'] = new aiblog({
                        'autoplay': ![],
                        'element': document[_0x55b2('42b', 'k^bl')](_0x35038c[_0x55b2('42c', 'k4Eh')]),
                        'theme': config[_0x55b2('42d', 'Wz)S')],
                        'logo': config[_0x55b2('42e', 'SeLh')],
                        'video': {
                            'url': _0x498875,
                            'pic': config[_0x55b2('42f', 'dO7c')],
                            'type': _0x35038c['KzzAD']
                        },
                        'danmaku': {
                            'id': aibk['id'],
                            'api': config[_0x55b2('430', 'fS)C')] + _0x35038c[_0x55b2('431', 'EUJq')],
                            'user': config[_0x55b2('432', 'tpZ^')],
                            'addition': [_0x35038c[_0x55b2('433', 'U3CT')](config[_0x55b2('434', 'Wz)S')], _0x35038c[_0x55b2('435', 'EUJq')]) + config['av']]
                        }
                    });
                    aibk[_0x55b2('436', 'M0h5')]()
                }
            },
            'MYad': {
                'vod': function(_0x51141d, _0x4b79ff) {
                    var _0x2c35ec = {
                        'Dfklb': _0x55b2('437', 'Vw#z'),
                        'lIQWK': function(_0x9b8120, _0x4fcbd3) {
                            return _0x9b8120 === _0x4fcbd3
                        },
                        'WHrye': _0x55b2('438', 'Q68x'),
                        'nBPqx': _0x55b2('439', 'FD%['),
                        'GgUUX': _0x55b2('43a', 'HmS@'),
                        'YNzVS': function(_0xfab4dc, _0x52b247) {
                            return _0xfab4dc(_0x52b247)
                        },
                        'adPXL': _0x55b2('43b', 'lO]v'),
                        'Blbjb': function(_0x89c2b4, _0x3decd3) {
                            return _0x89c2b4 + _0x3decd3
                        },
                        'MtNBq': _0x55b2('43c', 'FD%['),
                        'hAWjR': function(_0x910108, _0x3a1525) {
                            return _0x910108(_0x3a1525)
                        },
                        'WgmKd': '#ADplayer'
                    };
                    _0x2c35ec[_0x55b2('43d', 'A9kN')]($, _0x2c35ec[_0x55b2('43e', 'T4#C')])[_0x55b2('43f', 'wVm6')](_0x2c35ec['Blbjb'](_0x2c35ec[_0x55b2('440', 'u9K(')](_0x55b2('441', 'hO4W'), _0x4b79ff), _0x2c35ec['MtNBq']));
                    _0x2c35ec[_0x55b2('442', 'M0h5')]($, _0x2c35ec[_0x55b2('443', '9x[3')])[_0x55b2('444', '9x[3')](function() {
                        var _0x1ddc52 = {
                            'osTDv': _0x2c35ec[_0x55b2('445', 'zJ7r')]
                        };
                        if (_0x2c35ec[_0x55b2('446', '&weQ')](_0x2c35ec[_0x55b2('447', 'DLNY')], _0x2c35ec['nBPqx'])) {
                            layer[_0x55b2('448', 'fi9R')](_0x1ddc52[_0x55b2('449', 'U3CT')])
                        } else {
                            document[_0x55b2('44a', 'tpZ^')](_0x2c35ec[_0x55b2('44b', 'Wz)S')])['click']()
                        }
                    });
                    aibk[_0x55b2('44c', 'iNik')][_0x55b2('44d', 'Wz)S')](_0x51141d)
                },
                'pic': function(_0x4e4d0a, _0x1bb677, _0x1d72ae) {
                    var _0x5d8e80 = {
                        'mNhoc': function(_0xd4b1d7, _0x2fa6d2) {
                            return _0xd4b1d7(_0x2fa6d2)
                        },
                        'Lsvcu': _0x55b2('44e', 'kBQF'),
                        'WDZIh': function(_0x43097c, _0x168600) {
                            return _0x43097c + _0x168600
                        },
                        'Asrjr': function(_0x14deb3, _0x5734d9) {
                            return _0x14deb3 + _0x5734d9
                        },
                        'ABIZE': _0x55b2('44f', 'fS)C'),
                        'cMMrH': _0x55b2('450', 'MxJI'),
                        'zZPay': function(_0x53163f, _0x23fa95, _0x3f8fac) {
                            return _0x53163f(_0x23fa95, _0x3f8fac)
                        },
                        'Lqsdg': 'time_ad',
                        'jfSJz': function(_0x1c77dc, _0x4a1f31) {
                            return _0x1c77dc(_0x4a1f31)
                        }
                    };
                    var _0x32b520 = _0x55b2('451', 'hO4W')[_0x55b2('452', 'h&f3')]('|'),
                        _0x325e58 = 0x0;
                    while (!![]) {
                        switch (_0x32b520[_0x325e58++]) {
                            case '0':
                                _0x5d8e80[_0x55b2('453', 'EWS[')]($, _0x5d8e80['Lsvcu'])['html'](_0x5d8e80[_0x55b2('454', 'hO4W')](_0x5d8e80['WDZIh'](_0x5d8e80[_0x55b2('455', 'zJ7r')](_0x5d8e80[_0x55b2('456', 'k4Eh')](_0x5d8e80[_0x55b2('457', 'Hnve')], _0x4e4d0a), _0x5d8e80['cMMrH']) + _0x1bb677 + _0x55b2('458', 'sx3x'), _0x1d72ae), '">'));
                                continue;
                            case '1':
                                var _0x92b0c8 = null;
                                continue;
                            case '2':
                                _0x5d8e80[_0x55b2('459', 'DLNY')](setTimeout, function() {
                                    var _0x330fd5 = {
                                        'iUCPq': function(_0xb3a199, _0x207c41) {
                                            return _0x23c7cf[_0x55b2('45a', 'U3CT')](_0xb3a199, _0x207c41)
                                        },
                                        'cIazs': function(_0x4fe890, _0x59a981) {
                                            return _0x23c7cf[_0x55b2('45b', 'ljjg')](_0x4fe890, _0x59a981)
                                        },
                                        'LbtOE': _0x23c7cf[_0x55b2('45c', 'HbCg')]
                                    };
                                    _0x92b0c8 = setInterval(function() {
                                        _0x70a868--;
                                        _0x1479c1[_0x55b2('45d', '&weQ')] = _0x70a868;
                                        if (_0x330fd5[_0x55b2('45e', 'sx3x')](_0x70a868, 0x0)) {
                                            clearInterval(_0x92b0c8);
                                            aibk[_0x55b2('d6', 'h&f3')](config[_0x55b2('45f', 'fi9R')]);
                                            _0x330fd5[_0x55b2('460', 'fS)C')]($, _0x330fd5[_0x55b2('461', 'U3CT')])[_0x55b2('462', '@e3Z')]()
                                        }
                                    }, 0x3e8)
                                }, 0x1);
                                continue;
                            case '3':
                                var _0x70a868 = _0x1479c1[_0x55b2('463', '@q!Z')];
                                continue;
                            case '4':
                                var _0x1479c1 = document[_0x55b2('464', 'hO4W')](_0x5d8e80[_0x55b2('465', 'I!ON')]);
                                continue;
                            case '5':
                                var _0x23c7cf = {
                                    'JMwPy': _0x55b2('466', 'uGmG'),
                                    'aWOYk': function(_0x3a55a0, _0x24b8f2) {
                                        return _0x3a55a0 == _0x24b8f2
                                    },
                                    'UYcPD': function(_0x4f6b26, _0x2b2fe8) {
                                        return _0x5d8e80[_0x55b2('467', 'SeLh')](_0x4f6b26, _0x2b2fe8)
                                    },
                                    'VtLMN': _0x5d8e80['Lsvcu']
                                };
                                continue;
                            case '6':
                                _0x5d8e80[_0x55b2('468', 'FD%[')]($, _0x5d8e80['Lsvcu'])[_0x55b2('469', '6qTG')](function() {
                                    document[_0x55b2('46a', 'Vw#z')](_0x23c7cf[_0x55b2('46b', 'I!ON')])['click']()
                                });
                                continue
                        }
                        break
                    }
                },
                'pause': {
                    'play': function(_0x24ada5, _0x5cfcff) {
                        var _0x50fd01 = {
                            'UEqEJ': function(_0x3f72d8, _0x32e5e7) {
                                return _0x3f72d8 == _0x32e5e7
                            },
                            'fsMmf': function(_0x19a300, _0x3931d8) {
                                return _0x19a300 + _0x3931d8
                            },
                            'wtZHO': _0x55b2('46c', 'MxJI'),
                            'SFrch': function(_0x340857, _0xf701f4) {
                                return _0x340857(_0xf701f4)
                            }
                        };
                        if (_0x50fd01['UEqEJ'](aibk[_0x55b2('46d', '0vlN')]['pause']['state'], 'on')) {
                            var _0xb29839 = _0x50fd01[_0x55b2('46e', 'P(et')](_0x50fd01[_0x55b2('46f', 'Wz)S')](_0x55b2('470', 'fi9R') + _0x24ada5 + _0x55b2('471', 'iNik'), _0x5cfcff), _0x50fd01['wtZHO']);
                            _0x50fd01['SFrch']($, '#player')[_0x55b2('472', 'MxJI')](_0xb29839)
                        }
                    },
                    'out': function() {
                        var _0x486da1 = {
                            'ItGpp': function(_0x297c66, _0x30e9de) {
                                return _0x297c66(_0x30e9de)
                            },
                            'zCavi': _0x55b2('473', 'u9K(')
                        };
                        _0x486da1[_0x55b2('474', 'DLNY')]($, _0x486da1['zCavi'])[_0x55b2('475', 'EUJq')]()
                    }
                }
            }
        };
        _0xod0 = 'jsjiami.com.v6';